# 高维前缀和

一般用来解决这类问题：

>给定长度为 $2^n$ 的序列 $a$，对于所有的 $i,0 \leq i \leq 2^n - 1$，询问 $\sum_{j \subset i}a_j$

## 解法 $1$ ：枚举子集 $O(3^n)$

>* $i\ \& \ j = j$：代表 $j$ 是 $i$ 的子集，即 $i$ 的二进制 $1$ 的位置上 $j$ 可以是 $1$ 也可以是 $0$，$0$ 的话在 $j$ 上必须是 $0$
>* $(j - 1)\ \& \ i$：代表小于 $j$ 的第一个 $i$ 的子集
>* 对于 $i$ 来说，我们定义 $i$ 的二进制中 $1$ 的数量为 $c$，则 $i$ 的子集数量为 $2^c$ 个
>* 时间复杂度：$O(\sum_{i = 1}^{2^n - 1} 2^c) = O(3^n)$
>
>```cpp
>for (int i = 1; i < (1ll << n); ++i) {
>    for (int j = i; j > 0; j = (j - 1) & i) {
>        f[i] += a[j];
>    }
>}
>```
>

## 解法 $2$ ：高维前缀和解决子集和问题 $O(n\times 2^n)$

>我们考虑 $n = 2$ 时的情况，令 $f[S_{(2)}]$ 表示 $S_{(2)}$ 状态下的子集和，则有：
>$$
>\begin{equation}
>	\left\{
>		\begin{array}{lr}
>		f[00] = a_0\\
>		f[01] = a_0 + a_1\\
>		f[10] = a_0 + a_2\\
>		f[11] = a_0 + a_1 + a_2 + a_3 = a_3 + f[01] + f[10] - f[00]
>		\end{array}
>	\right. 
>\end{equation}
>$$
>所以当 $n = 2$ 时子集和本质上是一个二维前缀和，当 $n > 2$ 时我们考虑高维前缀和解决该问题，二进制的每一位对应着一维
>
>* 前置知识1：二维前缀和除了容斥外，还有一种求法，就是一维一维来求，也可以得到二维前缀和：
>
>```cpp
>// 处理第一维
>for (int i = 1; i <= n; ++i)
>    for (int j = 1; j <= n; ++j)
>       a[i][j] += a[i][j - 1];
>// 处理第二维
>for (int i = 1; i <= n; ++i)
>    for (int j = 1; j <= n; ++j)
>       a[i][j] += a[i - 1][j];
>```
>
>* 前置知识2：三维前缀和的求法类似二维前缀和：
>
>```cpp
>// 第一维
>for (int i = 1; i <= n; i++)
>    for (int j = 1; j <= n; j++)
>       for (int k = 1; k <= n; k++)
>           a[i][j][k] += a[i][j][k - 1];
>// 第二维
>for (int i = 1; i <= n; i++)
>    for (int j = 1; j <= n; j++)
>       for (int k = 1; k <= n; k++)
>           a[i][j][k] += a[i][j - 1][k];
>// 第三维
>for (int i = 1; i <= n; i++)
>    for (int j = 1; j <= n; j++)
>       for (int k = 1; k <= n; k++)
>           a[i][j][k] += a[i - 1][j][k];
>```
>
>我们定义 $f[i][j]$ 代表前 $i$ 位二进制（前 $i$ 维度）答案已经处理完，在 $j$ 状态下的子集和。
>
>得到转移方程：
>$$
>\begin{equation}
>	f[i][j] = 
>	\left\{
>		\begin{array}{lr}
>		f[i - 1][j] , (j\ \&\ 2^i = 0)\\
>       f[i - 1][j\  \oplus\ 2^i],(j\ \&\ 2^i = 1)
>		\end{array}
>	\right. 
>\end{equation}
>$$
>利用滚动数组优化掉第一维即可。
>
>```cpp
>for (int j = 0; j < n; ++j) {   // 枚举维数
>	for (int i = 0; i < (1ll << n); ++i) // 对每一维做前缀和
>		if (i >> j & 1)
>			f[i] += f[i ^ (1ll << j)];
>}
>```
>
>* 如果 $S_2$ 是 $S_1$ 的子集，那么 $S_1$ 就是 $S_2$ 的**超集**
>* 如果我们要计算超集的话，二进制中的 $1$ 只能为 $1$ ，而 $0$ 可以为 $0$ 也可以为 $1$ ，然后求出来的就是超集
>
>```cpp
>for (int j = 0; j < n; ++j) {
>	for (int i = 0; i < (1ll << n); ++i) {
>		if (~i >> j & 1)
>			f[i] += f[i ^ (1ll << j)];
>	}
>}
>```
>

## P5495 Dirichlet 前缀和

>![image-20240208105047190](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240208105047190.png)

### 题解

>* 容易发现所有满足 $i = \prod{p_i^{\alpha_i}}, k = \prod{p_i^{\phi_i}},\alpha_i \leq \phi_i$ 的所有 $a_i$ 都对 $b_k$  有贡献
>* 然后简单模拟几个后发现实际上就是对每个质因子的高维前缀和
>* 所以直接欧拉筛筛出 $[1, n]$ 中所有质数，然后对每个质数开一维进行高维前缀和即可

```cpp
void solve() {
	cin >> n >> seed;
	vector<uint> f(n + 10), p(n + 10), vis(n + 10);
	int tot = 0;
	for (int i = 1; i <= n; ++i) f[i] = getnext();
	auto get_primes = [&](int n) -> void {
		for (int i = 2; i <= n; ++i) {
			if (!vis[i]) p[++tot] = i;
			for (int j = 1; j <= tot && p[j] * i <= n; ++j) {
				vis[p[j] * i] = true;
				if (i % p[j] == 0) break;
			}
		}
	};
	get_primes(n);
	/* 本质上是质因子的高维前缀和，所以对每个质因子开一维，然后依次枚举每个质因子 */
	for (int i = 1; i <= tot; ++i) {
		for (ll j = p[i]; j <= n; j += p[i]) {
			f[j] += f[j / p[i]];
		}
	}
	uint ans = 0;
	for (int i = 1; i <= n; ++i) ans ^= f[i];
	cout << ans << endl;
}
```

## CF1903 D2. Maximum And Queries (hard version)

>![image-20231211222505351](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231211222505351.png)

### 题解

>* 我们考虑从高位到低位贪心
>* 假设答案为 $ans$，且当前枚举到第 $i$ 位二进制，我们考虑在 $ans$ 上将第 $i$ 位二进制从 $0$ 变为 $1$ 所需的代价：
> * 假设 $cnt[mask]$ 代表序列 $a$ 中为 $mask$ 的超集个数， $dp[i][mask]$ 代表序列 $a$ 中为 $mask$ 超集和（在第 $i$ 位以下）
> * 如果 $a_i$ 不是 $ans$ 的超集，代表存在一些二进制位置：$a_i$ 在这些位置上为 $0$，$ans$ 为 $1$，所以此时 $a_i$ 实际上从 第 $i$ 位到第 $0$ 位已经都是 $0$ 了，所以代价为 $(n - cnt[ans]) \times 2^i$。
> * 如果 $a_i$ 是 $ans$ 的超集且 $a_i$ 的第 $i$ 位二进制为 $0$，需要花费 $2^i$ 的代价，但是我们还需要减去第 $i$ 位以下（且第 $i$ 位为 $0$）这些位的和，所以代价为 $(cnt[ans] - cnt[ans | 2^i]) \times 2^i - (dp[i][ans] - dp[i][ans | 2^i])$
>* $cnt[mask]$ 和 $dp[i][mask]$ 都可以用 $sosdp$ 预处理，预处理总复杂度 $O(nlog^2n)$

```cpp
int n, q, a[N];
void solve() {
	cin >> n >> q;
    vector<int> cnt(1ll << 20);
    int sum = 0;
	for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        sum += a[i];
        ++cnt[a[i]];
    }
    for (int i = 0; i < 20; ++i)
        for (int j = 0; j < (1ll << 20); ++j)
            if (~j >> i & 1) cnt[j] += cnt[j ^ (1ll << i)];
    vector<vector<int>> dp(25);
    for (int i = 19; i >= 0; --i) {
        dp[i].resize(1ll << 20);
        int val = (1ll << (i + 1)) - 1;
        for (int j = 1; j <= n; ++j) 
            dp[i][a[j]] += (val & a[j]);
        for (int j = 0; j < 20; ++j) 
            for (int k = 0; k < (1ll << 20); ++k)
                if (~k >> j & 1) dp[i][k] += dp[i][k ^ (1ll << j)];
    }
    while (q--) {
        int k;
        cin >> k;
        if ((sum + k) / n > (1ll << 20) - 1) {
            cout << (sum + k) / n << endl;
        } else {
            int ans = 0;
            for (int i = 19; i >= 0 && k; --i) {
                int C1 = cnt[ans];
                int C2 = cnt[ans | (1ll << i)];
                int res = 0;
                res += (n - C1) * (1ll << i);
                res += (C1 - C2) * (1ll << i) - (dp[i][ans] - dp[i][ans | (1ll << i)]);
                if (res <= k) {
                    k -= res;
                    ans |= (1ll << i);
                }
            }
            cout << ans << endl;
        }
    }
}
```

# FMT (快速莫比乌斯变换)

>假设 $f[i]$ 代表 $i$ 的贡献
>
>那么通过 FMT，我们可以使得 $f[i]$ 代表 $i$ 的子集和的贡献

```cpp
for (int j = 0; j < n; ++j) {   // 枚举维数
	for (int i = 0; i < (1ll << n); ++i) // 对每一维做前缀和
		if (i >> j & 1)
			f[i] += f[i ^ (1ll << j)];
}
```

# IFMT (快速莫比乌斯反演)

>假设 $f[i]$ 代表 $i$ 的子集和的贡献
>
>那么通过 IFMT，我们可以使得 $f[i]$ 代表 $i$ 的贡献

```cpp
for (int j = 0; j < n; ++j) {
	for (int i = 0; i < (1ll << n); ++i)
		if (i >> j & 1)
			f[i] -= f[i ^ (1ll << j)];
}
```

## ABC349 F - Subsequence LCM

>![image-20240416225339465](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240416225339465.png)

### 题解

>考虑 $lcm$ 的本质，即每个质因子在所有数中幂次的最大值
>
>考虑先对 $m$ 进行质因子分解，$1e16$ 内最多 $13$ 种质因子，假设 $m$ 有 $k$ 种质因子
>
>对于每个 $a[i]$ 来说，我们将其状态压缩成二进制串，第 $i$ 位代表第 $i$ 种质因子 $p_i$ 幂次是否和 $m$ 中 $p_i$ 的幂次相等，如果相等，则第 $i$ 位二进制为 $1$，否则为 $0$
>
>那么现在问题转化为：有 $n$ 个数，求选一些数使得这些数或的和恰好为 $2^k - 1$ 的方案数
>
>因为恰好不好求，不妨我们先求或的和是 $2^k - 1$ 的子集的方案数
>
>假如我们已知数 $i$ 的子集数量为 $cnt$，则我们可以知道，选一些数或的和是 $i$ 的子集的方案数为 $2^{cnt} - 1$
>
>所以我们现在只需要知道每个数子集的个数即可，考虑 $FMT$
>
>定义 $dp[i]$ 代表数 $i$ 的子集数量
>
>则通过 $FMT$ 后，我们令 $dp[i]:=2^{dp[i]} - 1$，则 $dp[i]$ 代表选一些数或的和是 $i$ 的子集的方案数
>
>然后我们通过 $IFMT$ 后，使得 $dp[i]$ 代表选一些数或的和恰好是 $i$ 的方案数
>
>那么答案显然为 $dp[2^k - 1]$
>
>时间复杂度 $O(2^kk + \sqrt{m})$
