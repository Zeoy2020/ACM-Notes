

##   [CodeForces - 1740E](https://vjudge.net/problem/CodeForces-1740E/origin) 

>给定一个排列，将这个排列以任意顺序放在树上，然后执行这样的操作：
>
>1.每次只能选择叶子节点，2.将当前选择的叶子节点上的值添加到序列$s$后面；3.如果当前选择的叶子节点的值小于父亲节点的值，该叶子节点的值会替换其父亲节点的值；4.将该叶子节点从树上移除
>
>在经过n次这样的操作之后，让你求出序列s中最长单调不递减序列的长度

### 题解： 树形 DP

>我们观察发现对于一个节点来说，他最终会去取到它所有儿子节点中最小的节点；那么对于某一结点u来说，它的答案会存在两种情况：
>
>1.答案为一条以它为根到叶子节点最远的一条链，u节点会存在于单调不递减序列中，例如：1 1 1 1 1；
>
>2.答案由它的子树组成，通过不同的操作顺序，使得答案为子树相加，但是这样的话节点u肯定不会存在在单调不递减序列中，因为节点u的值是它所有儿子节点中的最小值，例如：1 2 3 4 1(节点u的值)
>
>所以对于一个节点u来说，我们可以按照它存不存在于它的单调不递减序列中进行DP
>
>状态表示：$f[u][0/1]$代表u节点存不存在于单调不递减序列中得到的最长单调不递减序列的长度
>
>状态属性：$MAX$
>
>状态转移方程：
>
>1.选择u节点时，保留最长的一条链：$f[u][1] = f[v][1] + 1$
>
>2.不选择u节点时，选择其子树和：$f[u][0] = \sum{max(f[v][1],f[v][0])}$



##  [CodeForces - 1650F Vitaly and Advanced Useless Algorithms](https://vjudge.net/problem/CodeForces-1650F/origin) 

>现在给你$n$个任务，每个任务都有截止时间，你需要将每个任务进程都完成$100\%$，才算成功，又给定$m$种操作，每次操作给定$e,t,p$,代表对于任务$e$，可以利用$t$时间将其进度增加$p$，每种操作只能用一次，求最后能否完成所有任务，如果能完成求出完成所有任务的最短用时，并将选择的操作以任意顺序输出

### 题解：01背包求方案数

>首先这是一个先明显的01背包求方案数的题目，因为存在截止时间，所以我们肯定要从截止时间短的任务开始做起，我们只需要对于每一个任务所对应的操作进行01背包，然后如果该任务完成的最短时间超过其给定的时间，那么说明后面的任务都完成不了了，如果能完成，那么剩余的时间我们可以分配给下一个任务，那么对于每次任务我们在dp时再记录方案即可
>
>我们需要知道背包容量实际上就是任务进度$100\%$,同时我们需要注意它的转移和普通的01背包有点不同，一般的01背包只有在$j>=v[i]$的情况下才会转移，而在本题我们发现如果$j<p$, 那么实际上我们知道存在这样的情况：$j=100,p=110$,那是不是说明也可以转移，也就是从$f[0]$转移给$f[100]$,也就是说转移方程$f[j]=min(f[j],f[max(0,j-p)]+t)$
>
>对于这道题，两个重点我们需要把握：
>
>1. 如何在一维滚动数组中记录方案数，我们可以开个$vector[N]$，对于每次转移我们先将方案数转移，然后再在vector[]后面加上本次操作的id，$pre[j] = pre[max(0ll, j - p)],\ \ \ \ pre[j].push\_back(id);$
>2. 如何对所有操作数按照任务分类，同样可以利用vecrot，借助邻接表的思想进行分类



##  [7-14 至多删三个字符](https://pintia.cn/problem-sets/1630856989821726720/exam/problems/1630856989901418508) 

> 给定一个全部由小写英文字母组成的字符串，允许你至多删掉其中 3 个字符，结果可能有多少种不同的字符串？ 

### 题解：DP+去重

>状态表示：$f[i][j]$：在$[1,i]$中删除$j$个字符
>
>状态属性：数量
>
>状态转移：
>
>1. 选择删除第$j$个字符，那么会在$[1,i-1]$中删除$j-1$个字符：$f[i][j] += f[i-1][j-1]$
>
>2. 不选择删除第$j$个字符，那么会在$[1,i-1]$中删除$j$个字符：$f[i][j]+=f[i-1][j]$
>
>3. 去重：举个例子：$abcdad$,$f[6][2]$由$f[5][2]$和$f[5][1]$转移过来，那么对于$f[5][2]$来说他可以选择 $da$ 删除，对于$f[5][1]$来说，他必须选择删除第6位，然后它可以选择$a$,即删除了$ad$，那儿很显然两者选择这么删除后剩余的字符串$abc$一样，也就是说$abc$字符串的方案重复了，多加了，那么我们如何去重？
>
>对于第$i$个位置，我们从后往前遍历找到其第一个位置$k$，使得$s[i]==s[k]$,那么存在两种情况：
>
>    1. 举个例子$abcdabd,j=2,i=7,k=4$,在这种情况下，我们并不会造成重复，因为我们只有删除$abd$，才会产生重复，也就是说$j=3$的情况下会产生重复，但是现在$j=2$，而第i个位置到第k个位置之间有$i-k=3$个字符，也就是例子中的$abd$, 那么如果说$j<i-k$,是不会造成重复的
>    2. 还是上面的例子，但是现在$j=4 > i-k=3$,也就是说$f[6][3]$可以选择删除$abd$，但是这样还需要删除一个，我们只需要在$[1,k-1]$之间再删除一个字符；对于$f[6][4]$来说它可以选择删除$dab$,同样只需要再$[1,k-1]$中删除一个字符，那么$f[3][1]$的方案数被重复加了，所以我们减去即可，总结以下，也就是说：如果$j>=i-k$，那么$f[i][j]-=f[k-1][j-(i-k)]$
>
>  3. 那么我们对于每个位置$i$，只需要找到其前面第一个相同字符就可以$break$，那为什么不用再往前找呢？我们看个例子:$dacdead$,我们在处理最后一个$d$的时候前面的$d$的位置上的方案数是不是已经去重过了，也就说都是正确的，所以不需要花时间再去对最后一个$d$去重，因为在倒数第2个$d$已经去重过了

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

string s;
int n;
int f[N][4];

void solve()
{
    cin >> s;
    n = s.length();
    s = " " + s;
    f[0][0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 0; j <= 3; ++j)
        {
            f[i][j] = f[i - 1][j];
            if (j - 1 >= 0)
                f[i][j] += f[i - 1][j - 1];
            for (int k = i - 1; k >= 1; --k)
            {
                if (s[k] == s[i])
                {
                    if (i - k <= j)
                        f[i][j] -= f[k - 1][j - (i - k)];
                    break;
                }
            }
        }
    }
    cout << f[n][3] + f[n][2] + f[n][1] + f[n][0] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [Sending a Sequence Over the Network](https://vjudge.net/problem/CodeForces-1741E) 

> 对于数组a，可以将其任意划分成若干段，对于每一段可以选择在其左侧或者右侧添加一个数字，这个数字就是这段长度，新构成的数组称为数组b，现在给出一个长度为n的数组b，问是否存在一个数组a能通过上述操作生成它。

###  题解：线性DP ：好题目

>对于数组$b$的前$i$个元素来说，对于最后结尾的第$i$个元素来说只有两种情况：
>
>1. 代表左边区间的长度
>2. 代表右边区间的长度
>
>状态表示：$f[i]$：代表前$i$个位置是否能够还原出一个数组$a$
>
>状态属性：合法性
>
>状态转移：
>
>1. 代表左边区间的长度：如果$i-a[i]-1>=0\  \&\& \ f[i-a[i]-1]==true$,那么$f[i]=true$,注意$i-a[i]-1$的位置是不属于左边区间左边的第一个元素
>2. 代表右边区间的长度：如果$i+a[i]<=n\ \ \&\& \ \ f[i-1]==true$，那么$f[i+a[i]]==true$,也就是说$i-1$位置是上区间的最后一个元素，只要上个位置是合法的，那么$i$位置代表右边区间的长度，所以我们可以直接预处理出后面某个位置是合法的
>
>状态初始：$f[0] = 1,其余f[i] = 0$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int f[N];
int a[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i], f[i] = 0;
    f[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        if (i - a[i] - 1 >= 0 && f[i - a[i] - 1])
            f[i] = 1;
        if (i + a[i] <= n && f[i - 1])
            f[i + a[i]] = 1;
    }
    if (f[n])
        cout << "YES" << endl;
    else
        cout << "NO" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~





##  [Kirill and Company](https://vjudge.net/problem/CodeForces-1741G) 

>给定n个节点和m条边的无向图，初始有f个人在节点1，他们每个人都要从节点1返回自己的家，且都要走最短路径，其中这f个人中有k（$1<=k<=6$）人没有车，其他人都有车，没有车的人可以搭别人的顺风车回家，通过搭车安排使得k个人中无法搭车只能走回家的人数最少，求出最少的人数

### 题解：分组背包+状压DP+最短路

>首先只有k个人没有车，且$k<=6$，我们可以将所有搭便车的情况利用二进制压缩，例如：1110，说明第一个人不带，然后带第2.3.4个人；那么每一个有车的人要在所有的方案中选择一种合法的带人方案，最多带k个人，即：$11...11$,也就是说我们要在每一个组中任选一种方案，使得在不超过背包容量的情况下价值最大，这里的背包容量为$11...11$（最多带k个人），显然是一个分组背包的问题；
>
>我们知道分组背包的状态转移方程为：$f[i] = f[i-v[i]]+w[i]$,倒序遍历背包
>
>但是这边我们该怎么办？
>
>首先我们先解决几个简单的问题：
>
>1. 假设某个带人方案为$1110$,那我们如何确定带的人具体是谁？实际上我们只要将没有车的人按照距离节点1的最短距离排序即可，因为我们肯定带的人肯定是从距离最近开始，我们不可能先把距离远的送回家然后再回来送距离近的，我们应该是送距离远的人的半路上将距离短的人送到家
>2. 我们如何确定对于任意一个有车的人来说，某个带人方案是一个合法方案，即能把该方案中的所有搭便车的人送回家，我们只需要求出每个没有车的人的家距离其他节点的最短距离，加上在节点1求的最短距离，我们最多求7次$bfs$，可以接受，那么在我们知道距离后，假设有车的人的家为$v$，只要从起点开始到每个搭便车人的家的所有距离加起来等于从起点到v的距离，就说明这几个人都能搭便车被送到家
>
>现在我们来解决$dp$的问题：
>
>状态表示：$f[i]=0/1$:表示把二进制为$i$状态下的所有二进制位为1的人搭便车送回家的可行性
>
>状态属性：可行性
>
>状态转移：每个有车的人对其所有合法的带人方案进行分组背包，那么$f[i-v[i]]$怎么实现呢？实际上原本的意思是将背包空出来$v[i]$部分用来装新的物品，那么我们这边只需要将背包中的人放下来几个，用来装新的人即可,那实际上异或就能使得双方都有1的部分为0，即$f[i] |= f[i\bigoplus  j]$，滚动数组实现，注意倒序遍历背包
>
>状态初始：$f[0]=true,其余false$
>
>如何得出答案：
>
>我们只需要在所有合法的二进制状态下（$f[i]=true$）找到二进制中1最多的方案即可，可以使用$\_\_builtin\_popcount()$函数

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e4 + 10, M = 4e5 + 10;

int n, m, k, num;
vector<int> g[N];
int h[N];
int f[N];
int dis[10][N];

void bfs(int st, int k)
{
    for (int i = 1; i <= n; ++i)
        dis[k][i] = 0;
    vector<bool> vis(n + 10, 0);
    queue<int> q;
    q.push(st);
    dis[k][st] = 0;
    vis[st] = 1;
    while (q.size())
    {
        int u = q.front();
        q.pop();
        for (auto v : g[u])
        {
            if (!vis[v])
            {
                vis[v] = 1;
                dis[k][v] = dis[k][u] + 1;
                q.push(v);
            }
        }
    }
}

bool cmp(int x, int y)
{
    return dis[0][x] < dis[0][y];
}

void solve()
{
    cin >> n >> m;
    memset(f, 0, sizeof f);
    for (int i = 1; i <= n; ++i)
        g[i].clear();
    for (int i = 1, u, v; i <= m; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    bfs(1, 0);
    cin >> num;
    vector<bool> car(num + 10, 1); // 代表这个人有没有车
    for (int i = 1; i <= num; ++i)
        cin >> h[i];
    cin >> k;
    vector<int> vec;
    for (int i = 1; i <= k; ++i)
    {
        int p;
        cin >> p;
        car[p] = false;
        vec.push_back(h[p]);
    }
    sort(all(vec), cmp);	//规定状态压缩中的每一1代表谁
    int idx = 1;
    for (auto v : vec)		//最多6次的bfs
    {
        bfs(v, idx);
        idx++;
    }
    f[0] = 1;
    for (int i = 1; i <= num; ++i) // 遍历每个有车的人
    {
        if (car[i] == false)	//没车跳过
            continue;
        vector<int> goods;		//存放合法的方案
        for (int j = 1; j <= (1 << k) - 1; ++j)
        {
            vector<int> a;
            for (int pos = 0; pos <= k; ++pos)
            {
                if ((j >> pos) & 1)		//找到1的位置，从而知道每个1代表谁
                    a.push_back(pos);
            }
            int sum = dis[0][h[i]];		//模拟是否为合法方案的过程
            int sz = a.size();
            sum -= dis[0][vec[a[0]]];
            for (int pos = 1; pos < sz; ++pos)
            {
                sum -= dis[a[pos - 1] + 1][vec[a[pos]]];
            }
            sum -= dis[a.back() + 1][h[i]];
            if (sum == 0)	//合法
                goods.push_back(j);
        }
        for (int j = (1 << k) - 1; j >= 1; --j)	//倒序遍历背包
            for (auto it : goods)
                if (it <= j)
                    f[j] |= f[j ^ it];	//分组背包
    }
    int ans = 0;
    for (int i = 1; i <= (1 << k) - 1; ++i)	
    {
        if (f[i])
            ans = max(ans, 1ll * __builtin_popcount(i));
    }
    cout << k - ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~





##  J - Mex Tree 

>给定一颗编号为1-n的树，所有点的权值为0,1,2...n-1的一个排列，现在定义$mex(S)$表示不属于S的最小非负数，
>
>当$mex(S)=k$时，询问点数最多的非空连通子图有多少个点？

### 题解：思维+换根+树形DP 

>首先乍一看贼像树的重心，我们仔细分析以下：
>
>首先如果一个连通图中包含了所有比$k$小的数，那么这个连通图就是合法的
>
>1. 当k=0时，它的点数最多的非空连通子图就是树的重心
>2. 当k=n时，它的点数就是整一颗树的所有点
>3. 当$0<k<n$时，因为是一颗无根树，我们可以将权值为0的点作为根，如果节点u的子树中出现了比$a[u]$还要小的数时，就说明节点u的子树外和子树内都没有，答案为0，否则合法的连通图一定在$u$的子树外$n-sz[u]$,所以我们只需要树上维护最小值和维护子树内的点数即可

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int n;
int a[N];
vector<int> g[N];
int ans[N];
int sz[N], minn[N];

void dfs(int u, int par)
{
    sz[u] = 1;
    minn[u] = min(minn[u], a[u]);
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        if (a[u] == 0)
            ans[0] = max(ans[0], sz[v]);
        sz[u] += sz[v];
        minn[u] = min(minn[u], minn[v]);
    }
    if (minn[u] == a[u] && a[u] != 0)
        ans[a[u]] = n - sz[u];
}

void solve()
{
    cin >> n;
    int rt = -1;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        if (a[i] == 0)
            rt = i;
        minn[i] = INF;
    }
    for (int i = 2, u; i <= n; ++i)
    {
        cin >> u;
        g[u].push_back(i);
        g[i].push_back(u);
    }
    dfs(rt, 0);
    ans[n] = n;
    for (int i = 0; i <= n; ++i)
        cout << ans[i] << " ";
    cout << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  Problem B. 广告投放

>n集节目按顺序播出，节目组决定在某些节目中投放广告，节目最初播出时有m名观众，若$i$集投放广告，若此时还剩$c$名观众，那么产生$c*p_i$的收益，但播出后会使得观众人数$c'=\lfloor c/d_i \rfloor$,即$i+1$集只会剩下$c'$名观众观看，如果在第$i$集没有投放广告，则不会产生收益，观众人数也不会减少
>
>$n<=1e5$

### 题解：数论分块 + 线性$DP$: $O(n\sqrt{n}$) 

>首先引入重要引理：
>
>1. $\lfloor \lfloor n/i \rfloor /j \rfloor = \lfloor n/(i*j) \rfloor$
>2. $\lfloor n/i\rfloor$的取值只有$O(\sqrt{n})$种取值
>
>显然是线性$dp$，根据题意我们得到：
>
>状态表示：$f[i][j]$：代表在第$i$集人数为$j$时能够获得的最大收益
>
>状态属性：$MAX$
>
>状态转移：
>
>1. 第$i$集投放广告,那么第$i+1$集的人数会减少，但会得到收益：$f[i+1][j/d[i]] = max(f[i+1][j/d[i]],f[i][j]+c*p[i])$
>
>2. 第$i$集不投放广告，那么第$i+1$集的人数和收益都不变：
>
>   $f[i+1][j] = max(f[i+1][j],f[i][j])$
>
>状态优化：
>
>1. 显然二维数组开不下，会$MLE$，我们利用滚动数组实现，我们发现第$i$层由第$i-1$层转移得到，且我们发现转移的方向为$j->j/d[i]$和$j->j$，即
>
>2. ![1678851264969](D:\MD图片\1678851264969.png)
>
>那么这就说明我们可以从前往后遍历人数，所以优化后的转移方程为：$f[j/d[i]] = max(f[j/d[i],f[j]+c*p[i]])$
>
>3. 那么我们解决了空间问题，还需要解决$TLE$，因为现在时间复杂度为$O(n^2)$,我们发现第二维在转移的时候存在这样的情况$j->\lfloor j/d[i]\rfloor -> \lfloor \lfloor j/d[i] \rfloor /d[i+1] \rfloor$,通过引理1得到$j->\lfloor j/d[i]\rfloor -> \lfloor  j/(d[i]*d[i+1]) \rfloor$,通过引理2得到第二维$j$的取值只有$O(\sqrt{n})$种取值，我们只需要预处理出第二维的所有取值，然后从前往后遍历即可
>
>状态初始：$f[i] = 0$
>
>答案呈现：遍历一遍第$m$集的每个人数时的最大收益，取$max$即可得到答案

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n, m;
int p[N];
int d[N];
int f[N];
int a[N];
map<int, int> mp;

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> p[i];
    for (int i = 1; i <= n; ++i)
        cin >> d[i];
    int idx = 0;
    a[++idx] = 0;					 //注意别漏掉0了
    for (int i = m; i >= 1; --i)	//为了使人数升序，方便从前往后遍历
    {
        if (!mp[m / i])
        {
            mp[m / i]++;
            a[++idx] = m / i;
        }
    }
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= idx; ++j)
        {
            f[a[j] / d[i]] = max(f[a[j]] + a[j] * p[i], f[a[j] / d[i]]);
        }
    }
    int ans = -INF;
    for (int i = 0; i <= m; ++i)
    {
        ans = max(f[i], ans);
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##   [XOR Tree](https://vjudge.net/problem/CodeForces-1709E) 

>给定一颗树，每个节点都有点权，现在你需要让树上任意两点之间的简单路径上的点权异或和不为0，你可以改变任意一点的点权，问最少改变几次使得所有简单路径点权异或和不为0？

### 题解：树形DP+异或+最近公共祖先

>首先假设$dis[u]$代表从根节点出发到u节点简单路径上的异或和，类似u和v之间的简单路径的长度，肯定经过他们的最近公共祖先，所以我们根据异或的性质和类比u和v之间的路径长度，我们得出u和v之间简单路径的异或和：$dis[u]\bigoplus dis[v]\bigoplus a[lca(u,v)]$
>
>那么我们对每个点开一个$set$（集合），集合中存放它的子树中到根节点路径的异或和，那么我们只要做个自下而上树形dp就好了
>
>也就是说我只要在以u节点为根的两个子树的集合内发现异或和为0，那么我们就必须修改$a[u]$,只要改成无穷大即可，那么如果我们改成无穷大后，也就意味着u节点的存放的集合，也就是存放其子树中到根节点的路径异或和的集合，这里面的数永远不会和其他节点的子树中的路径异或和变为0，也就是说我们可以直接清空$st[u]$
>
>注意两点：
>
>1. 该题卡常，我们在树形dp时必须优先遍历小的集合，否则$TLE$
>2. 我们必须及时清空子树中的集合，否则$MLE$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];
set<int> st[N];
vector<int> g[N];
int dis[N];
int ans;

void dfs(int u, int par)
{
    dis[u] = dis[par] ^ a[u];
    st[u].insert(dis[u]);
    bool ok = false;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        if (st[v].size() > st[u].size())	//优先小的
            st[u].swap(st[v]);
        for (auto x : st[v])
        {
            if (st[u].count(x ^ a[u]))
            {
                ok = true;
                break;
            }
        }
        for (auto x : st[v])
            st[u].insert(x);
        st[v].clear();		//及时清空子树中的集合
    }
    if (ok == true)
    {
        st[u].clear();		//无后效性，直接不用管u的子树了
        ans++;
    }
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



## [Gym - 102832A](https://vjudge.csgrandeur.cn/problem/Gym-102832A/origin) 

### 题解：混合背包

>01背包和完全背包的混合
>
>一开始首次额外赠送是01背包，后面是完全背包
>
>我们只需要每次先做一次01背包:$dp[i][j] = max(dp[i-1][j],dp[i-1][j-v[i]]+w[i])$
>
>再做完全背包：$dp[i][j]=max(dp[i-1][j],dp[i][j-v[i]]+w[i])$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e3 + 10;

int n;
int dp[N];
int a[8] = {0, 1, 6, 28, 88, 198, 328, 648};
int b[8] = {0, 8, 18, 28, 58, 128, 198, 388};

void solve()
{
    cin >> n;
    int ans = 0;
    for (int i = 1; i <= 7; ++i)
    {
        for (int j = n; j >= a[i]; --j)
            dp[j] = max(dp[j], dp[j - a[i]] + a[i] * 10 + b[i]);

        for (int j = a[i]; j <= n; ++j)
            dp[j] = max(dp[j], dp[j - a[i]] + a[i] * 10);
    }
    cout << dp[n] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~





## [洛谷 - P1270](https://vjudge.csgrandeur.cn/problem/洛谷-P1270/origin) 

### 题解：树上背包

>读入部分二叉树递归读入
>
>状态表示：$dp[u][i]$:以$u$节点为根的子树中$i$秒能偷到的画的数量
>
>状态属性：$MAX$
>
>首先只能在叶子节点才能偷到画，并且每幅画的时间为$5s$，所以在叶子节点的状态转移方程：$dp[u][i]=dp[u][i-5]+1$
>
>如果不是在叶子节点，那么我们只要把$i$秒时间分给其左儿子和右儿子即可
>
>$dp[u][i]=max(dp[u][i],dp[lson][j]+dp[rson][i-j])$
>
>那么时间这里的$i$指的是剩余的时间，我们要记得路程时间花费是两倍，然后m需要-1，因为我们需要在警察到来之前离开	

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e3 + 10, M = 4e5 + 10;

struct node
{
    int w, num;
} seg[N << 2];
int m;
int dp[N][N];

void build(int id)
{
    int a, b;
    cin >> a >> b;
    seg[id].w = 2 * a, seg[id].num = b;
    if (!b)
    {
        build(id << 1);
        build(id << 1 | 1);
    }
}

void dfs(int id, int w)
{
    int lson = id << 1, rson = id << 1 | 1;
    if (seg[id].num == 0)
    {
        dfs(lson, w + seg[lson].w);
        dfs(rson, w + seg[rson].w);
        for (int i = 1; i <= m - w; ++i)		//m-w是现在剩余的总时间，i代表左儿子分配的时间
            for (int j = 1; j <= m - w - i; ++j)//j代表右儿子分配的时间
                dp[id][w + i + j] = max(dp[id][w + i + j], dp[lson][w + i] + dp[rson][w + j]);
    }
    else
    {
        for (int i = 1; i <= seg[id].num; ++i)
        {
            int now = w + (i * 5);
            if (now > m)
                break;
            dp[id][now] = dp[id][now - 5] + 1;
        }
    }
}

void solve()
{
    cin >> m;
    m--;
    build(1);
    dfs(1, seg[1].w);
    cout << dp[1][m] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  A. TreeScript 

> 给你一个根，让你构造一棵树，每个节点被创造的时候必须知道它的父节点的地址和需要寄存器存放当前节点的地址，现在给定你每个节点之间的关系，并且现在根节点已经被创建，且有一个寄存器存放着根节点的地址，请问最少需要几个寄存器才能构造出这颗完整的树

### 题解：树形$DP$

>我们先来分析一下样例：
>
>1. 0 1 2，ans = 1，代表:$1->2->3$,一开始1号根节点处有一个寄存器，那么创建节点2的时候，我们需要可以不需要多余的寄存器，我们只要将节点2的地址覆盖根节点处寄存器中存放的节点1的地址即可，也就是说节点2继承了节点1的寄存器，对于节点3同理，继承了节点2的寄存器
>
>2. 0 1 2 2 1 4 1，ans = 2
>
>   <img src="D:\MD图片\1679411730311.png" alt="1679411730311" style="zoom: 33%;" />
>
>   我们贪心的先创建小子树，发现我们在创建节点7的时候我们不能覆盖节点1的地址，也就是说我们不能继承节点1的寄存器，因为创建节点5和节点2的时候我们需要知道节点1的地址，所以我们创建节点7的时候需要新创建1个寄存器来存放节点7的地址；在创建节点5的时候我们可以继承节点7的寄存器，同理节点2也可以继承节点5的寄存器，所以我们发现我们贪心的创建从小子树到大子树的过程，大子树可以继承小子树的寄存器；对于节点2来说它还有子节点没有建立，所以我们需要建立2的子树，这个时候根节点1处的寄存器就没有用处了，可以用于创建节点3，然后创建节点4，再然后继承给节点6，这样一颗树就建完了，所以只用到了两个寄存器
>
>   通过模拟上述两个样例我们得知：
>
>   1. 我们贪心从小子树的建立开始，到大子树结束，并且最后一颗最大的子树还能继承根节点的寄存器
>   2. 如果根节点的子节点没有建立完，那么根节点处的寄存器不能被继承
>   3. 以$u$节点为根，它需要的寄存器数量是建立次大子树$v_2$需要的寄存器加上根节点上的寄存器（因为最后最大子树会继承两者之和）和建立最大子树$v_1$需要的寄存器两者之间取$max$
>
>   状态表示：$f[u]$:以$u$为根节点的子树被创建所需的寄存器数量
>
>   状态属性：数量
>
>   状态转移：$f[u] = max(f[v_1],f[v_2]+1),v_1>=v_2>=v_3..$
>
>   状态初始：$f[u] = 1$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
vector<int> g[N];
int f[N];

void dfs(int u, int par)
{
    f[u] = 1;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        f[u] = max(f[u], f[v]);
    }
    int cnt = 0;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        if (f[u] == f[v])
            cnt++;
    }
    if (cnt > 1)
        f[u]++;
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        g[i].clear();
    for (int i = 1, u; i <= n; ++i)
    {
        cin >> u;
        g[u].push_back(i);
        g[i].push_back(u);
    }
    dfs(1, 0);
    cout << f[1] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  **7-13 凑零钱** 

> 一个人手里有$10^4$枚硬币，每种硬币只能用$1$次，需要请你帮她盘算一下，是否可能精确凑出要付的款额$m$，输出字典序最小的方案

### 题解：贪心 + 变种$01$背包求方案 / $DFS$回溯

>方法1：$dp$
>
>1. 状态表示：$f[i]$:***精准***凑出金额$i$的钱最多需要几个硬币
>2. 状态属性：$MAX$
>3. 状态转移：转移的前提是前一个状态必须是合法的（也就是说前一个状态代表的金额能被硬币凑出）$f[j] = max(f[j],f[j-a[i]]+1)\  \&\& \ (f[j-a[i]]>0\  ||\ j-a[i]==0)$
>4. 状态初始：$f[i]=0$
>5. 答案呈现：如果$f[m]>0$，代表金额$m$能被精准凑出，我们利用$vector$记录方案即可
>6. 如何求字典序最小的方案：贪心，将硬币升序排列即可，这样记录的方案一定是字典序最小的
>
>方法2：$dfs$搜索
>
>​	贪心升序排序后$dfs$爆搜即可

~~~cpp
//dp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n, m;
int a[N];
int f[N];
vector<int> pre[N];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    sort(a + 1, a + n + 1);
    for (int i = 1; i <= n; ++i)
    {
        for (int j = m; j >= a[i]; --j)
        {
            if (f[j] <= f[j - a[i]] + 1 && (f[j - a[i]] || j - a[i] == 0))
            {
                f[j] = f[j - a[i]] + 1;
                pre[j] = pre[j - a[i]];
                pre[j].push_back(a[i]);
            }
        }
    }
    if (f[m])
    {
        for (int i = 0; i < pre[m].size(); ++i)
            cout << pre[m][i] << "\n "[i < pre[m].size() - 1];
    }
    else
        cout << "No Solution" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

~~~cpp
//dfs回溯
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n, m;
int a[N];
bool vis[N];
vector<int> ans;
bool flag;

void dfs(int idx, int sum)
{
    if (sum > m)
        return;
    if (sum == m)
    {
        flag = true;
        for (int i = 0; i < ans.size(); ++i)
            cout << ans[i] << "\n "[i < ans.size() - 1];
        return;
    }
    for (int i = idx; i <= n; ++i)
    {
        if (!vis[i])
        {
            vis[i] = true;
            ans.push_back(a[i]);
            dfs(i + 1, sum + a[i]);
            ans.pop_back();
            vis[i] = false;
            if (flag)
                return;
        }
    }
}

void solve()
{
    cin >> n >> m;
    int sum = 0;
    for (int i = 1; i <= n; ++i)
        cin >> a[i], sum += a[i];
    if (sum < m)
    {
        cout << "No Solution" << endl;
        return;
    }
    sort(a + 1, a + n + 1);
    dfs(1, 0);
    if (!flag)
        cout << "No Solution" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



## 篠塚真佑実的树

>给定$n$个节点的树，其中$m$个节点存在传送门，当飞船经过存在传送门的节点的时候，可以选择无消耗地传送至其他存在传送门的节点，现在有$q$次询问，每次询问给出起点$st$和终点$ed$，若每艘飞船在飞行中最多只能进行一次传送，请你输出每次询问从起点到终点的最短路径长度
>
>$1<=m<=n<=2e5,1<=q<=2e5$

### 题解：树上倍增 + $LCA$ + 最短路

>我们可以将情况分为两类：
>
>1. 不进行传送：那么我们只要利用树上倍增求出起点和终点的$lca$即可，然后维护点到根节点距离即可快速求出起点和终点之间的最短距离
>2. 进行1次传送：我们可以把所有存在传送门的节点看成一个源点（有点类似缩点），然后利用$dij$求出其他点到传送门的最短距离$dis$，那么利用一次传送后起点和终点之间的最短距离为：$dis[st]+dis[ed]$
>
>我们对于这两种情况取$min$即可

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n, m;
vector<pii> g[N];
int a[N];
int fa[N][22], dep[N];
int dis[N];
int dis1[N];
int vis[N];
int st[N];

void dfs(int u, int par, int w)
{
    dep[u] = dep[par] + 1;
    fa[u][0] = par;
    dis[u] = dis[par] + w;
    for (int i = 1; i <= 20; ++i)
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    for (auto &[v, w] : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u, w);
    }
}

int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);
    for (int i = 20; i >= 0; i--)
    {
        if (dep[fa[u][i]] >= dep[v])
            u = fa[u][i];
    }
    if (u == v)
        return u;
    for (int i = 20; i >= 0; i--)
    {
        if (fa[u][i] != fa[v][i])
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0];
}

void dij()
{
    for (int i = 1; i <= n; ++i)
        dis1[i] = INF, vis[i] = 0;
    priority_queue<pii, vector<pii>, greater<pii>> q;
    for (int i = 1; i <= m; ++i)
    {
        int v = a[i];
        dis1[v] = 0;
        q.push({dis1[v], v});
    }
    while (q.size())
    {
        int u = q.top().second;
        q.pop();
        if (vis[u])
            continue;
        vis[u] = 1;
        for (auto [v, w] : g[u])
        {
            if (dis1[v] > dis1[u] + w)
            {
                dis1[v] = dis1[u] + w;
                q.push({dis1[v], v});
            }
        }
    }
}

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= m; ++i)
        cin >> a[i];
    for (int i = 1, u, v, w; i < n; ++i)
    {
        cin >> u >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
    }
    dij();
    dfs(1, 0, 0);
    int q;
    cin >> q;
    while (q--)
    {
        int s, ed;
        cin >> s >> ed;
        int ans = INF;
        int rt = lca(s, ed);
        ans = min(ans, dis[s] + dis[ed] - 2 * dis[rt]);
        int d = dis1[s] + dis1[ed];
        ans = min(ans, d);
        cout << ans << endl;
    }
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



## 树上Minmax

> 给定一棵树，其包含 $n$ 个结点和 $n − 1$ 条边，每条边连接两个结点，且任意两个结点间有且仅有一条简单路径互相可达，每个点存在点权$a_i$
>每次操作可以断一条边，随后选择分裂出的两棵树中的一棵树删除，请最小化操作次数使得最后剩下的树的点权和最大。 
>
> $1<=n<=4*10^5$ 
>
> $-10^9<=a_i<=10^9$

### 题解：树形$dp$

>不妨令根为$1$，我们维护每个节点子树中的最大点权和以及得到该最大点权和所需的最小操作次数，对于任意节点$u$来说，存在$3$种情况：
>
>1. 子树$v$中的最大点权和$<0$,显然我们要维护的是$u$子树内最大的点权和，所以如果我们不断开$u$和$v$之间的边，那么最大点权和会变小，所以我们贪心的将其断开，操作次数加$1$
>2. 子树$v$的最大点权和$>0$，那么我们贪心的将其收入囊中，我们不选择断开，所以$u$节点需要加上$v$节点的最大点权和以及将$v$节点变成最大点权和的操作次数
>3. 子树$v$的最大点权和$=0$，显然对于$u$的最大点权和来说我要不要都行，但是我们需要最小化操作次数，所以如果我们删去$u$和$v$之间的边，操作次数加$1$，如果说子树$v$中的最小操作次数$<1$,我们可以选择不删除这条边，否则我们为了维护最小操作次数选择删除$u$和$v$之间的边
>
>那么最大我们遍历所有节点子树中最大的点权和，如果节点$u$中存在最大点权和，但是$u$不是根节点，我们需要断开其和根节点的一条边，使其成为连通块；如果$u$本身就是根节点，那么不受影响
>
>状态表示：$f[u][0/1]$：$0$代表$u$节点子树中的最大点权和，1代表最小操作次数
>
>状态转移：按照上面分析的情况转移即可
>
>```cpp
>if (f[v][0] < 0)
>    f[u][1]++;
>else if (f[v][0] > 0)
>{
>    f[u][0] += f[v][0];
>    f[u][1] += f[v][1];
>}
>else if (f[v][0] == 0)
>{
>    if (f[v][1] < 1)
>    {
>        f[u][0] += f[v][0];
>    	f[u][1] += f[v][1];
>    }
>    else
>        f[u][1]++;
>}
>```
>
>状态初始：$f[u][0] = a_u,f[u][1] = 0$

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 4e5 + 10, M = 4e5 + 10;

int n;
int a[N];
int f[N][2];
vector<int> g[N];

void dfs(int u, int par)
{
    f[u][0] = a[u];
    f[u][1] = 0;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        if (f[v][0] < 0)
            f[u][1]++;
        else if (f[v][0] > 0)
        {
            f[u][0] += f[v][0];
            f[u][1] += f[v][1];
        }
        else if (f[v][0] == 0)
        {
            if (f[v][1] > 1)
                f[u][1]++;
            else
            {
                f[u][0] += f[v][0];
                f[u][1] += f[v][1];
            }
        }
    }
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);
    int maxx = -INF;
    for (int i = 1; i <= n; ++i)
    {
        maxx = max(f[i][0], maxx);
    }
    int cnt = INF;
    for (int i = 1; i <= n; ++i)
    {
        if (f[i][0] == maxx)
        {
            if (i != 1)
                cnt = min(cnt, f[i][1] + 1);
            else
                cnt = min(cnt, f[i][1]);
        }
    }
    cout << maxx << " " << cnt << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



## 树上MinmaxⅡ

 >给定一棵根为 $1$ 的树，其包含 $n$ 个结点和 $n − 1$ 条边，每条边连接两个结点，且任意两个结点间有且仅有一条简单路径互相可达。在这里，我们认为当 $n=1$ 时，根节点也是叶节点。
 >我们定义一个子节点都是叶节点且子树都被打上标记的节点为 “枝” ，被标记的叶节点都是 “花” 。在任何时刻你都可以选择一个 “枝” ，把它的所有子节点，也即 “花” 折下来。操作过后，会删除选定的 “枝” 和它的 “花” 间的连边， 选定的 “枝” 会变成新的 “花” 。 
 >在每个时间点你都可以选取一个没有被标记过的节点来打上标记，最开始没有节点被标记。
 >你的目标是将树变为一枝 “花” 并最小化任何时间点树上被标记点数量的最大值，并求出该最小化后的最大值

###  题解：树形$dp$ + 贪心 $O(nlogn)$

>首先如果要将任意节点$u$变为花节点，我们必须将其所有子节点$v$变为花节点，即叶子节点，然后将$u$节点打上标记后$u$就变成了枝节点，然后我们就可以将花节点$v$折下使得$u$变为花节点；我们发现我们在将$u$的子节点$v$变为花的过程中，假设$u$有$k$个子节点，我们不妨先将子节点$v_1$变为花，那么在将$v_2$变为花的时候$v_1$一直处于标记状态，对于$v_3$来说，将其变为花的时候，$v_1,v_2$处于标记状态，令$f[u]$为将$u$节点变为花的所需的被标记点的数量，那么我们可以得到规律：将$v_i$变为花的时刻树上被标记的节点数位$f[v_i]+i-1$,那儿我们是要最小化树上任意时刻被标记点的最大值，我们只需贪心地先将最大的子树变为花，然后次大.....最后选择最小的子树变为花即可，对于贪心我们只需对子节点的$dp$值进行排序即可
>
>注意最后将$u$的所有子节点变为花后，我们还需要标记$u$，那么此时场上被标记的节点数为$sz[u]+1$，$sz[u]$代表$u$的子节点数
>
>状态表示：$f[u]$:将$u$节点变为花的所需的被标记点的最大数量
>
>状态属性：$MAX$
>
>状态转移：
>$$
>f[u] = max(f[v_1],f[v_2]+1...f[v_i]+i-1,sz[u]+1)\\f[v_1]>=f[v_2]>=...f[v_i]
>$$
>状态初始：$f[u] = 1$
>
>答案呈现：遍历$f[u]$后找到最大值即可

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 4e5 + 10, M = 4e5 + 10;

int n;
int f[N];
vector<int> g[N];

void dfs(int u, int par)
{
    f[u] = 1;
    vector<int> a;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        a.push_back(f[v]);
    }
    sort(all(a), greater<int>());
    for (int i = 0; i < a.size(); ++i)
        f[u] = max(f[u], a[i] + i);
    f[u] = max(f[u], (long long)(a.size() + 1));
    a.clear();
}

void solve()
{
    cin >> n;
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, f[i]);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



##  [Maximum Sum on Even Positions](https://vjudge.net/problem/CodeForces-1373D) 

>给定长度为$n$的数组$a$，数组下标从$0$开始，我们最多可以反转一次区间$[l,r]$中的所有元素，使得数组$a$中偶数位上的元素和最大，请你求出该最大值

### 题解：$dp$：最大子段和  + 思维

>我们经过模拟后发现，如果$[l,r]$区间长度为偶数长度，那我们反转$[l,r]$中的元素,实际上就是交换了该区间中的奇数位和偶数位元素，所以题目变成交换一段连续偶数长度的区间中的奇数位和偶数位，使得数组$a$中偶数位上的元素和最大，那么我们是不是只要求出奇数位减去偶数位的差值，对于该差值形成的一段序列，我们找到这段序列中最大子段和$sum$，看会不会使得答案变大即可，但是因为一个奇数位置可以和两个偶数位置交换，所以存在两种情况：
>
>1. `a[0],a[1]  a[2],a[3]  a[4],a[5]...`
>2. `a[1],a[2]  a[3],a[4]  a[5],a[6]...`
>
>我们只需对两种情况分别求出最大子段和$sum$即可
>
>* 我们来讲一下最大字段和的$dp$做法：
>
>  状态表示：$f[i]$：以$a_i$作为末尾元素的连续序列的最大和
>
>  状态属性：$MAX$
>
>  状态转移：
>
>1. 该序列中只有$a_i$自己： $f[i] = max(f[i],a[i])$
>2. 序列中有多个元素，连接上一个序列，并以$a_i$结尾：$f[i] = max(f[i],f[i-1]+a[i])$
>
>* 我们再来说说贪心的做法：
>  1. 如果$sum < 0$,我们直接舍弃前面的连续序列
>  2. 如果$sum>=0$,说明$a_i$加上$sum$后会变大，我们保留前面的序列 

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];

void solve()
{
    cin >> n;
    int ans = 0;
    for (int i = 0; i < n; ++i)
    {
        cin >> a[i];
        if (i % 2 == 0)
            ans += a[i];
    }
    int sum = 0;
    vector<int> v;
    for (int i = 1; i < n; i += 2)
        v.push_back(a[i] - a[i - 1]);
    int res = -INF;
    for (auto x : v)
    {
        if (sum >= 0)
            sum += x;
        else
            sum = x;
        res = max(res, sum);
    }
    v.clear();
    sum = 0;
    for (int i = 2; i < n; i += 2)
        v.push_back(a[i - 1] - a[i]);
    for (auto x : v)
    {
        if (sum >= 0)
            sum += x;
        else
            sum = x;
        res = max(res, sum);
    }
    ans = max(ans, ans + res);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



##  [K-periodic Garland](https://vjudge.net/problem/CodeForces-1353E) 

>给定一个长度位$n$的$01$串，每次操作可以将$1$变为$0$或者将$0$变为$1$，现在你需要通过操作使得所有$1$之间的距离为$k$，求最少的操作次数，注意全为$0$也算
>
>$1<=n<=1e6,1<=k<=n$

### 题解：$dp$ / 贪心 : 最大子段和思想

>方法一：$dp$ $O(n)$
>
>状态表示：$f[i][0/1]$：代表将区间$[1,i]$变为合法串的最小操作次数，且第$i$位为$0/1$
>
>状态转移：
>
>1. 贪心考虑只有两种情况的时候我们可以将第$i$位变成$1$：
>
>   - 若第$i-k$位也是$1$，我们可以考虑将第$i$位变为$1$,那么我们需要将$[i-k+1,i-1]$中的所有1变为0
>   - 我们同样可以考虑使第$i$位前面所有的1变为0，从第$i$位的$1$重新当作起始位置，那么我们需要将前面所有的1变为0
>   - 同时如果该位本身不是$1$，我们需要将其变为$1$
>
>   $f[i][1]=min(f[i][1]+pre[i-1]-pre[i-k],pre[i-1]) + (s[i]=='0')$ 
>
>2. 同样只有两种情况我们可以将第$i$位变为$0$：
>
>   - 第$i-1$位是1的情况
>   - 第$i-1$位是0的情况
>   - 如果第$i$位不是0，我们需要将其变为0
>
>   $f[i][0]=min(f[i-1][1],f[i-1][0])+(s[i]=='1')$
>
>状态初始：$f[i]=0$ 
>
>方法二：贪心 + 枚举对$k$余数 $复杂度：调和级数O(nlogn)$
>
>由题意可知这些$1$一定是连续的且距离间隔$k$，这说明1所处的位置对$k$取模的模数是相同的，且这些1连续，所以我们可以考虑根据对$k$的余数来枚举$1$的起始位置，所以我们不妨先将所有的1变为0
>
>我们设$cnt$：可以减免的答案贡献，或者说从起始位置到现在1的前缀和数量与0的前缀和数量之差；
>
>1. 对于某一位来说，我们需要其为1，并且其本身已经为1，说明我们原本不用将其变为0，所以这部分答案可以减免，$cnt$++，
>2. 对于某一位来说，我们需要其为1，但是其本身为0，说明我们这部分答案不能减免，$cnt$--，
>3. 如果$cnt<0$，说明从起始位置开始0的数量已经比1的数量多了，也就是说我们将这些前面位置都变成1就比全部变为0吃亏，倒不如全部变为0，借用最大子段和的思想我们直接舍弃前面的部分，将该位置重新当成起始位置，$cnt=0$
>4. 我们在枚举过程中始终维护$cnt$的最大值即可
>
>时间复杂度为调和级数：$O(nlogn)$

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int n, k;
int f[N][2];
int pre[N];

void solve()
{
    cin >> n >> k;
    string s;
    cin >> s;
    s = " " + s;
    for (int i = 1; i <= n; ++i)
        pre[i] = pre[i - 1] + (s[i] == '1');
    for (int i = 1; i <= n; ++i)
    {
        f[i][1] = min(f[max(0ll, i - k)][1] + pre[i - 1] - pre[max(0ll, i - k)], pre[i - 1]) + (s[i] == '0');
        f[i][0] = min(f[i - 1][1], f[i - 1][0]) + (s[i] == '1');
    }
    cout << min(f[n][0], f[n][1]) << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int n, k;

void solve()
{
    cin >> n >> k;
    string s;
    cin >> s;
    s = " " + s;
    int ans = 0;
    for (int i = 1; i <= n; ++i)
        if (s[i] == '1')
            ans++;
    int maxx = -INF;
    for (int i = 1; i <= k; ++i)
    {
        int cnt = 0;
        for (int j = i; j <= n; j += k)
        {
            if (s[j] == '1')
                cnt++;
            else
                cnt--;
            if (cnt < 0)
                cnt = 0;
            maxx = max(cnt, maxx);
        }
    }
    cout << ans - maxx << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



##  [Decreasing Heights](https://vjudge.net/problem/CodeForces-1353F) 

>给出一个 $n \times m$ 的矩阵，每个矩阵的权值代表该点的初始高度。
>
>现在需要从点 $( 1 , 1 )$ 走到点 $( n , m )$ ，每一步需要满足以下条件：
>
>- 只能向右或向下
>- 设当前格子的高度为 $x$ ，只能移动到高度为 $x + 1$ 的格子上去
>
>
>初始时可以进行操作，使得某个格子的高度减少一个单位。
>
>问最少需要进行多少次操作，可以存在至少一条从点 $( 1 , 1 )$ 到点 $( n , m )$ 的路线
>
>$1≤n,m≤100$

### 题解：$dp$ + 枚举

>我们发现只要确定起点$(1,1)$的高度，那么对于任意位置$(i,j)$的高度我们都是确定的：$i+j-2$，所以我们只需要枚举起点的高度即可，但是我们怎么枚举？
>
>我们贪心的进行枚举，每次枚举的起点高度能够保证使得位置$(i,j)$上的高度不需要降低，即起码保证有一个位置我们不需要改变其高度，如果这个位置原有的高度$h$，且$h<a[1][1]+i+j-2$,说明我们不能通过降低起点的高度使得到达$(i,j)$时不需要降低$(i,j)$的高度，否则我们可以利用$dp$求出从起点到终点的最小操作次数
>
>设起点高度为$h$
>
>状态表示：$f[i][j]$：从起点$(1,1)$到达$(i,j)$所需的最小操作次数
>
>状态转移：
>
>1. 该位置是从上面过来的，即$(i-1,j)->(i,j)$
>
>   $f[i][j] = min(f[i][j],f[i-1][j]+a[i][j]-(h+i+j-2)),a[i][j]>=h+i+j-2$
>
>2. 该位置是从右边过来的，即$(i,j-1)->(i,j)$
>
>   $f[i][j] = min(f[i][j],f[i][j-1]+a[i][j]-(h+i+j-2)),a[i][j]>=h+i+j-2$
>
>3. 如果$ a[i][j]<h+i+j-2 $，说明位置$(i,j)$无法到达，我们直接跳过即可

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e2 + 10, M = 4e5 + 10;

int n, m;
int a[N][N];

int calc(int x, int y)
{
    vector<vector<int>> f(n + 10, vector<int>(m + 10, INF));
    int h = a[x][y] - x - y + 2;
    f[1][1] = a[1][1] + x + y - 2 - a[x][y];
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            int cur = h + i + j - 2;
            if (cur > a[i][j])
                continue;
            f[i][j] = min(f[i][j], f[i - 1][j] + a[i][j] - cur);
            f[i][j] = min(f[i][j], f[i][j - 1] + a[i][j] - cur);
        }
    }
    return f[n][m];
}

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            cin >> a[i][j];
    int ans = INF;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            if (a[1][1] + i + j - 2 < a[i][j])
                continue;
            ans = min(ans, calc(i, j));
        }
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



## 接龙序列

>我们称序列中$a_i$的首位数字恰好是$a_{i-1}$的末尾数字，这样的序列叫做接龙序列，比如`12 23 35 57`,所有长度为1的整数序列都是接龙序列，现在给定一个长度为$n$的序列$a$，请你计算最少从中删除多少个数，可以使得剩下的序列是接龙序列

### 题解：$DP$

>根据题目我们可以转化题意为：求出最长的接龙序列，那么答案就是$n-$最长接龙序列的长度
>
>这道题显然和最长上升子序列问题比较像，所以我们按照最长上升子序列的思路走；
>
>状态表示：$f[i]$：以第$i$个数结尾的最长接龙序列的长度
>
>状态属性：$MAX$
>
>状态计算：我们只要找到前面所有末尾数字和第$i$个数的首位数字相同的数$a_j$，接在它的后面即可
>$$
>f[i] = max(f[i],f[j]+1),j<i\ \wedge r[j] = l[i]
>$$
>​						显然复杂度是$O(n^2)$的，我们考虑进行优化
>
>状态优化：因为第$i$个数只能接在末尾数字$x$和第$i$个数首位数字相等的数后面，所以我们实际上可以开一个辅助						数组$g$来存放前$i-1$个数中以$x$结尾的$f[j]$的最大值，即
>$$
>g[x] = max(g[x],f[j]),j<i,r[j]=x\\
>f[i] = max(f[i],g[x]+1)
>$$
>​						那么复杂度被优化到了$O(n)$
>
>状态初始：$f[i] = 1$

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int g[N], f[N];
int l[N], r[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        string s;
        cin >> s;
        l[i] = s[0] - '0';
        r[i] = s[s.size() - 1] - '0';
    }
    int ans = 0;
    for (int i = 1; i <= n; ++i)
    {
        f[i] = 1;
        f[i] = max(f[i], g[l[i]] + 1);
        g[r[i]] = max(g[r[i]], f[i]);
        ans = max(ans, f[i]);
    }
    cout << n - ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



##  [Counting Factorizations](https://vjudge.net/problem/CodeForces-1794D)

>任何一个正整数 $m$ 都可以被唯一的分解为 $p_1^{e_1} \cdot p_2^{e_2} \ldots p_k^{e_k}$ 的形式。将正整数 $m$ 的唯一质数分解转化为一个长度为 $2k$ 的 **可重集合** 记为 $f(m)$。
>$$ f(m)=\{p_1,e_1,p_2,e_2,p_3,e_3, \ldots ,p_k,e_k \}$$
>
>给定正整数 $n$ 和一个长度为 $2n$ 的可重集 $A$。求出满足 $f(m) = A$ 的正整数 $m$ 的个数。答案对 $998\ 244\ 353$ 取模。
>
>$1≤n≤2022$
>
>$1≤a_i≤10^6$

### 题解：欧拉筛 + 组合计数 + $DP$

>只有质数才能作为底数，也就是说我们要在$2n$个数中选择$n$个的不同的质数作为底数，多余$n$个的质数和非质数作为指数，设有$s_1$个非质数，每个非质数数量为$b_i$,有$s_2$个质数，每个质数的数量为$c_i$ ，我们在$s_2$个质数中选择n个质数作为底数也就是使对应的数量减$1$，$c_i':=c_i-1$,根据组合计数的原理我们得到答案为
>$$
>\sum\frac{n!}{b_1!b_2!...b_{s_1!}c_1'c_2'...c_{s_2}'}
>$$
>实际上左半部分贡献是固定的$\frac{n!}{b_1!b_2!...b_{s_1!}}$,我们只需求出$\sum\frac{1}{c_1'c_2'...c_{s_2}'}$即可，那么对于这部分贡献我们可以通过$DP$求出
>
>状态表示：$f[i][j]$：在前$i$个质数中选择$j$个作为底数的方案数 $O(n^2)$
>
>状态属性：数量
>
>状态计算：
>
>* 不选择第$i$个质数作为底数
>
>$$
>f[i][j] = f[i][j] + f[i-1][j]*c[i]!,j<=i
>$$
>
>* 选择第$i$个质数作为底数
>
>$$
>f[i][j] = f[i][j] + f[i-1][j-1]*(c[i] - 1)!,j<=i
>$$
>
>状态初始：$f[0][0]=1$
>
>答案呈现：从$s_2$个质数中选$n$个质数作为底数的方案数，$f[s_2][n]$
>
>我们应该提前利用快速幂来预处理阶乘的逆元$O(nlogn)$，同时利用欧拉筛提前预处理出$1e6$范围内的质数

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 998244353;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 5e3 + 10;

int n;
int p[N], vis[N], idx;
int fact[M], inv[M], c[M];
int f[M][M];
unordered_map<int, int> uprime, prime;

int qpow(int a, int b, int p)
{
    int res = 1;
    while (b)
    {
        if (b & 1)
            res = res * a % p;
        b >>= 1;
        a = a * a % p;
    }
    return res % p;
}

void get_primes(int n)
{
    vis[1] = 1;
    for (int i = 2; i <= n; ++i)
    {
        if (!vis[i])
            p[++idx] = i;
        for (int j = 1; j <= idx && p[j] * i <= n; ++j)
        {
            vis[p[j] * i] = 1;
            if (i % p[j] == 0)
                break;
        }
    }
}

void solve()
{
    cin >> n;
    get_primes(1e6);
    int tot = 0;
    for (int i = 1; i <= 2 * n; ++i)
    {
        int x;
        cin >> x;
        if (!vis[x])
            prime[x]++;
        else
            uprime[x]++;
    }
    fact[0] = inv[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        fact[i] = fact[i - 1] * i % mod;
        inv[i] = inv[i - 1] * qpow(i, mod - 2, mod) % mod;
    }
    int ans = fact[n];
    for (auto [x, y] : uprime)
        ans = ans * inv[y] % mod;
    int cnt = 0;
    for (auto [x, y] : prime)
        c[++cnt] = y;
    f[0][0] = 1;
    for (int i = 1; i <= cnt; ++i)
    {
        for (int j = 0; j <= i; ++j)
            f[i][j] = (f[i][j] % mod + f[i - 1][j] * inv[c[i]] % mod) % mod;
        for (int j = 1; j <= i; ++j)
            f[i][j] = (f[i][j] % mod + f[i - 1][j - 1] * inv[c[i] - 1] % mod) % mod;
    }
    cout << (ans % mod * f[cnt][n] % mod) % mod << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



## [Number of Subsequences](https://vjudge.net/problem/CodeForces-1426F)

>给定一个长度为$n$的含有`abc?`的字符串,`?`可能是`abc`中的任意一个,求所有可能的无`?`字符串中,子序列`abc`出现的次数.
>
>$3 \leq n \leq 2e5$

### 题解：计数DP

>经典计数$DP$
>
>状态表示：$f[i][0/1/2]$代表前$i$个字符能够构成以$a/ab/abc$结尾的子序列的个数
>
>状态属性：数量
>
>状态计算：
>
>1. 第$i$个字符为$a$，如果第$i$个字符前面有$k$个$？$号，那么前面会产生$3^k$个序列，因为每个问号有$3$种选择，所以
>
>     以$a$结尾的子序列的个数应该加上$3^k$
>
>     $f[i][0] = f[i-1][0] + 3 ^ k$
>
>2. 第$i$个字符为$b$，那么只能接在以$a$结尾的子序列后面
>
>   $f[i][1] = f[i-1][1] + f[i-1][0]$
>
>3. 第$i$个字符为$c$，那么只能接在以$ab$结尾的子序列后面
>
>     $f[i][2] = f[i-1][2] + f[i-1][1]$
>
>4. 第$i$个字符为$？$，对于以$a/ab/abc$结尾的子序列来说，他们的数量都会变为原来的三倍，对于以$a$结尾的子序列来说，应该加上$3^k$，对于以$ab$结尾的子序列来说，要加上以$a$结尾的子序列的数量，对于$abc$结尾的子序列来说，要加上以$ab$结尾的子序列的数量
>
>$$
>  \begin{cases} f[i][0] = f[i-1][0] * 3 + 3 ^ k\\
>  f[i][1] = f[i-1][1] * 3 + f[i-1][0]\\
>  f[i][2] = f[i-1][2] * 3 + f[i-1][1]
>  \end{cases}
>$$

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
string s;
int f[N][3];

void solve()
{
    cin >> n >> s;
    s = " " + s;
    int base = 1;
    for (int i = 1; i <= n; ++i)
    {
        if (s[i] == 'a')
        {
            f[i][0] = (f[i - 1][0] + base) % mod;
            f[i][1] = f[i - 1][1];
            f[i][2] = f[i - 1][2];
        }
        else if (s[i] == 'b')
        {
            f[i][0] = f[i - 1][0];
            f[i][1] = (f[i - 1][1] + f[i - 1][0]) % mod;
            f[i][2] = f[i - 1][2];
        }
        else if (s[i] == 'c')
        {
            f[i][0] = f[i - 1][0];
            f[i][1] = f[i - 1][1];
            f[i][2] = (f[i - 1][2] + f[i - 1][1]) % mod;
        }
        else
        {
            f[i][0] = (f[i - 1][0] * 3 + base) % mod;
            f[i][1] = (f[i - 1][1] * 3 + f[i - 1][0]) % mod;
            f[i][2] = (f[i - 1][2] * 3 + f[i - 1][1]) % mod;
            base = base * 3 % mod;
        }
    }
    cout << f[n][2] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```





## [Optimal Biking Strategy](https://vjudge.csgrandeur.cn/problem/Gym-103736H)

>一个人需要从起点到达距离其`p`距离远的终点，他可以选择步行或者骑车，路上有`n`个自行车停靠站，他**只能在自行车停靠站上车或者下车**
>
>骑车需要花钱，`1`元允许骑行最多`s`米，也就是说如果两个自行车站距离为`x`，那么需要花费$\lceil \frac{x}{s} \rceil$元
>
>现在他有`k`元，他到终点**最少的步行距离**
>
>$1≤n≤10_6,1≤p≤10_9,1≤s≤10_9,1≤k≤5$
>
>$a_i<a_j$

### 题解：线性DP + 贪心 $O(n*k^2 + nk*logn)$

>* 状态表示：$O(nk)$
>
>  $f[i][j]$代表从起点到第$i$个自行车站，花了$j$元后的最小步行距离
>
>* 状态属性：$MIN$
>
>* 状态计算：按照从上一个站点到第$i$个站点花费了多少钱对集合进行划分 $O(k)$
>
>  1. 不花钱，即从第$i-1$个站点步行到第$i$个站点：$f[i-1][j] + a[i] - a[i-1]$
>  2. 花`1`元，从距离站点$i$最远的可以用`1`元骑行到站点$i$的站点$k$骑行到站点$i$：$f[k][j-1]$
>  3. 花`2`元，从距离站点$i$最远的可以用`2`元骑行到站点$i$的站点$k$骑行到站点$i$：$f[k][j-2]$
>  4. ......
>
>  注意我们需要提前预处理$L[i][j]$：代表距离站点$i$最远的可以用$j$元骑行到站点$i$的站点，因为站点序列a递增，我们直接二分即可，预处理复杂度：$O(nk*logn)$
>
>* 状态初始：$f[i][0] = a[i]$
>
>* 答案呈现：$min\sum(f[i][k] + p - a[n])$

~~~cpp
const int N = 1e6 + 10, M = 8;

int n, p, s, k;
int a[N];
int f[N][M];
int L[N][M];

void solve()
{
    cin >> n >> p >> s;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    cin >> k;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= k; ++j)
            f[i][j] = INF;
    for (int i = 1; i <= n; ++i)
        f[i][0] = a[i];
    for (int i = 1; i <= n; ++i)		//二分预处理
        for (int j = 1; j <= k; ++j)
            L[i][j] = lower_bound(a + 1, a + n + 1, a[i] - j * s) - a;
    for (int i = 1; i <= n; ++i)		//DP
            for (int j = 1; j <= k; ++j)
        {
            f[i][j] = min(f[i][j], f[i - 1][j] + a[i] - a[i - 1]);
            for (int m = 1; m <= j; ++m)
                f[i][j] = min(f[i][j], f[L[i][m]][j - m]);
        }
    int ans = p;
    for (int i = 1; i <= n; ++i)
        ans = min(ans, f[i][k] + p - a[i]);
    cout << ans << endl;
}

~~~



## Palindromic characteristics

>给你一个串，让你求出$k$阶回文子串有多少个。$k$从$1$到$n$。$k$阶子串的定义是：子串本身是回文串，而且它的左半部分也是回文串。
>首先明确：
>1、如果一个字串是$k$阶回文，那他一定还是$k-1$阶回文。
>2、如果一个串是$k$阶回文，那么这个串需要满足：
>1.它本是是回文的。
>2.他的左半部分是$k-1$回文的。
>
>$1 \leq |s| \leq 5000$

### 题解：dp + 字符串哈希 + 后缀和

>* 根据题意容易发现一个$k$阶回文串其本身一定回文且它同样也是$1,2...k-1$阶回文串
>* 所以我们只要利用$dp$求出每阶回文串有多少个，然后后缀和即可
>* 判断回文串我们可以利用字符串哈希$O(1)$实现
>* 我们设计$f[i][j]$为字符串$s$区间$[i,j]$是几阶回文串
>* 我们$O(n ^ 2)$枚举所有区间，设$mid = l + r >> 1$，那么如果$[i,j]$本身回文且$[i,mid]$也是回文串，则状态转移方程为$f[i][j] = f[i][mid] + 1$，否则$f[i][j] = 0$，如果$[i,j]$本身回文且$[i,mid]$不是回文串，那么$f[i][j] = 1$
>* 最后做一个后缀和即可

```cpp
const int N = 5e3 + 10, M = 4e5 + 10;

int f[N][N];
int base = 131;
int p[N];
int h[N];
int rh[N];
int ans[N];

int get_hash(int l, int r)
{
    return ((h[r] - h[l - 1] * p[r - l + 1] % mod) % mod + mod) % mod;
}

int get_rhash(int l, int r)
{
    return ((rh[l] - rh[r + 1] * p[r - l + 1] % mod) % mod + mod) % mod;
}

bool check(int l, int r)
{
    return get_hash(l, r) == get_rhash(l, r);
}

void solve()
{
    string s;
    cin >> s;
    int n = s.length();
    s = " " + s;
    p[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        p[i] = p[i - 1] * base % mod;
        h[i] = (h[i - 1] * base % mod + s[i]) % mod;
    }
    for (int i = n; i >= 1; --i)
        rh[i] = (rh[i + 1] * base % mod + s[i]) % mod;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = i; j <= n; ++j)
        {
            if (check(i, j))
            {
                int mid = (i + j - 1) >> 1;
                if (check(i, mid))
                    f[i][j] = f[i][mid] + 1;
                else
                    f[i][j] = 1;
            }
            ans[f[i][j]]++;
        }
    }
    for (int i = n; i >= 1; i--)
        ans[i] = ans[i + 1] + ans[i];
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << "\n "[i < n];
}
```



## Infected Tree



>给定一棵以$1$ 号节点为根的二叉树，总节点个数为 $n$。
>
>现在 $1$ 号节点感染了病毒，病毒每一回合都会去感染与该节点直接相连的节点，而你在这一回合里可以选择删除任意一个没有被病毒感染（尚未被删除）的点，这样就断开了它与其直接相连的点得关系.
>
>询问最多可以有多少不被病毒感染的点，被删除的点不算做不被病毒感染的点
>
>![](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/1f479df0f6df9637a1dfee43da055c650bdae647.png)

### 题解：树形$dp$ + 思维

>* 容易发现病毒传染的路径一定是一条链，我们只要求出链长和被删除点的数量之和的最小值即可
>* 一种情况病毒传染到叶子节点时结束，设节点的深度为$dep$，链长为$dep$，被删除的点数量为$dep - 1$
>* 另一种情况病毒传染到只有一个儿子的节点结束，链长为$dep$，被删除的点的数量为$dep$

```cpp
const int N = 3e5 + 10, M = 4e5 + 10;

int n;
vector<int> g[N];
int dep[N];
int mi = INF;

void dfs(int u, int par)
{
    dep[u] = dep[par] + 1;
    int cnt = 0;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        cnt++;
        dfs(v, u);
    }
    if (cnt == 0)
        mi = min(mi, 2 * dep[u] - 1);
    else if (cnt == 1)
        mi = min(mi, 2 * dep[u]);
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        dep[i] = 0;
        g[i].clear();
    }
    for (int i = 1, u, v; i <= n - 1; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    mi = INF;
    dfs(1, 0);
    cout << n - mi << endl;
}
```

## PermuTree (easy version)

>![image-20230806170457839](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230806170457839.png)
>
>$1 \leq n \leq 5000$

### 题解：树形$DP$ + $bitset$优化

>* 显然对于$u$来说，它的子节点的子树中的所有节点的点权一定$>a_u$或者$< a_u$
>
>* 所以我们需要将这些子树分成两个集合$S,T$，集合$S$中的子树全部$>a_u$，集合$T$中的子树全部$<a_u$
>
>* 那么$u$能够对答案做出的最大贡献为
> $$
>  \sum_{v \in S}sz[v] \times \sum_{w \in T} sz[w]
> $$
>
>* 显然我们可以考虑枚举哪颗子节点的子树在集合$S$中，但是显然复杂度过高
>
>* 我们可以考虑类似硬币问题进行$dp$，定义$dp_i = true / false$为集合$S$中存在$i$个节点是否合法
> $$
>  dp[i]\ \ |= dp[i - sz_v],sz_v代表子树v中节点数
> $$
>
>* 如果$dp_i = true$，那么对答案的贡献为$i \times (sz_u - 1 - i)$
>
>* 那么$u$能够对答案做出的最大贡献为
> $$
>  max\sum_{i = 1}^{sz_u - 1}i \times (sz_u - 1 - i), dp_i = true
> $$
>
>* 当前复杂度为$O(n ^ 2)$，已经可以通过
>
>* 我们还可以通过$bitset$优化至$O(\frac{n^2}{w}),w = 64$

```cpp
const int N = 5e3 + 10, M = 4e5 + 10;

int n;
int sz[N], ans;
vector<int> g[N];

void dfs(int u, int par)
{
    sz[u] = 1;
    bitset<N> dp;
    dp.set(0); // f[0] = 1
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        sz[u] += sz[v];
        dp |= (dp << sz[v]);
    }
    int mx = 0;
    for (int i = 1; i <= sz[u] - 1; ++i)
    {
        if (dp.test(i)) //  f[i] = 1 
            mx = max(mx, i * (sz[u] - 1 - i));
    }
    ans += mx;
}

void solve()
{
    cin >> n;
    for (int i = 2; i <= n; ++i)
    {
        int u;
        cin >> u;
        g[i].push_back(u);
        g[u].push_back(i);
    }
    dfs(1, 0);
    cout << ans << endl;
}
```



