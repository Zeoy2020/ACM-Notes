## H. SBC's Hangar

>给定$n,k$，给定每个商品的重量$w[i]$，要求从$n$个商品中挑选$k$个商品，使得重量范围在$[L,R]$内的方案数
>
>$1 \leq n,k \leq 50$

### 题解：数位$DP$

>* 考虑到$n \leq 50$
>* 考虑将所有商品排序后进行状态压缩，状态$i$代表$n$个商品选择的二进制状态
>* 然后求出第一个大于等于$L$的二进制$l$，最大的小于等于$R$的二进制$r$
>* 然后现在将问题转化为：在二进制$[l,r]$的范围内存在多少个二进制中的$1$的个数为$k$
>* 考虑差分后数位$dp$即可

```cpp
int n, k, a[N], L, R, dp[N][N][2][2], num[N];

int dfs(int pos, int sum, bool lead, bool limit)
{
    if (pos == 0)
        return (sum == k ? 1 : 0);
    if (dp[pos][sum][lead][limit] != -1)
        return dp[pos][sum][lead][limit];
    int res = 0;
    int up = (limit ? num[pos] : 1);
    for (int i = 0; i <= up; ++i)
    {
        if (i == 0 && lead)
            res += dfs(pos - 1, sum, true, limit && i == up);
        else if (i == 0)
            res += dfs(pos - 1, sum, false, limit && i == up);
        else
            res += dfs(pos - 1, sum + 1, false, limit && i == up);
    }
    return dp[pos][sum][lead][limit] = res;
}

int cal(int x)
{
    int len = 0;
    while (x)
    {
        num[++len] = x % 2;
        x /= 2;
    }
    memset(dp, -1, sizeof dp);
    return dfs(len, 0, true, true);
}

int check(int mid)
{
    int res = 0;
    for (int i = 0; i < n; ++i)
    {
        if (mid >> i & 1)
            res += a[i];
    }
    return res;
}

void solve()
{
    cin >> n >> k;
    for (int i = 0; i < n; ++i)
        cin >> a[i];
    sort(a, a + n);
    cin >> L >> R;
    int l = 0, r = (1ll << n) - 1;
    while (l <= r)
    {
        int mid = l + r >> 1;
        if (check(mid) >= L)
            r = mid - 1;
        else
            l = mid + 1;
    }
    int x = l;
    l = 0, r = (1ll << n) - 1;
    while (l <= r)
    {
        int mid = l + r >> 1;
        if (check(mid) <= R)
            l = mid + 1;
        else
            r = mid - 1;
    }
    int y = r;
    cout << cal(y) - cal(x - 1) << endl;
}
```

## ABC336 **E - Digit Sum Divisible**

>![image-20240206211031614](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240206211031614.png)

### 题解：数位 $DP$

>如果我们定义 $dp[pos][sum][lead][limit]$ 的话，每个状态对应的数是不唯一的，会存在重复贡献，所以显然不能这么定义
>
>所以我们考虑枚举数位和，定义 $dp[pos][rsum][p][lead][limit]$ ，这样每个状态对应的数就是唯一的，具体含义见代码

```cpp
int num[N], dp[16][150][150][2][2], cur;
/* 
    cur: 当前枚举的数位和
	pos：当前枚举到的数位
	rsum: 剩下可以使用数位和
    p：当前数对枚举到的数位和 cur 取模的结果
	lead：当前位前面是否全为 0
	limit：最高位是否有限制
*/
int dfs(int pos, int rsum, int p, bool lead, bool limit) {
    if (rsum < 0) return 0;
	if (pos == 0 && rsum == 0 && p == 0 && !lead) return 1;
    else if (pos == 0) return 0;
	if (dp[pos][rsum][p][lead][limit] != -1) return dp[pos][rsum][p][lead][limit];
	int res = 0;
	/* 如果最高位有限制，只能取 [0, num[pos]], 否则可以取 [0, 9] */
	int up = (limit ? num[pos] : 9);
	for (int i = 0; i <= up; ++i) {
        if (i == 0 && lead) res += dfs(pos - 1, rsum, p, true, limit && i == up);
        else res += dfs(pos - 1, rsum - i, (p * 10 + i) % cur, false, limit && i == up);
	}
	return dp[pos][rsum][p][lead][limit] = res;
}
int calc(int x) {
	int len = 0;
	while (x > 0) {
		num[++len] = x % 10;
		x /= 10;
	}
    int ans = 0;
    /* 枚举数位和 cur */
    for (int i = 1; i <= 126; ++i) {
        /* 注意每次需要清空 */
	    memset(dp, -1, sizeof dp);
        cur = i;
        ans += dfs(len, cur, 0, true, true);
    }
    return ans;
}

void solve() {
    int n; cin >> n;
    cout << calc(n) << endl;
}
```

