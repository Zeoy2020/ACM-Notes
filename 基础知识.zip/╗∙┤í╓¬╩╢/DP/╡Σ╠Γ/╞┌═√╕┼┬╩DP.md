## A. Sticker Album

>你想要得到$n$张贴纸，每包礼物中等概率出现 $[A,B]$ 范围内数量的贴纸，求需要买多少包礼物才能至少获得$n$张贴纸的期望次数
>
>$1 \leq n \leq 10^6,0\leq A,B\leq 10^6$

### 题解：期望DP

>* 我们考虑从后往前进行$dp$
>
>* 设计状态为$dp[i]$代表手上有$i$张贴纸时，至少获得$n$张贴纸的期望次数
>
>* 显然初始状态：$dp[n]=dp[n + 1]...dp[∞] = 0$
>
>* 容易得到状态转移方程：
> $$
>  dp[i] = \sum_{j = i + a}^{j = i+b}(dp[j] + 1) \times \frac{1}{b - a + 1} , A \neq 0
> $$
>
>* 但是该题存在$A = 0$的情况，即自己转移到自己，这是一个经典的问题，我们不妨通过**移项**来解决该问题
> $$
> dp[i] =(dp[i]+1)\times \frac{1}{b - a + 1} +  \sum_{j = i + a + 1}^{j = i+b}(dp[j] + 1) \times \frac{1}{b - a + 1}, A = 0 \\
>  dp[i] = \frac{b - a + 1}{b - a} +  \sum_{j = i + a + 1}^{j = i+b}(dp[j] \times \frac{1}{b - a}), A = 0
> $$

```cpp
const int N = 2e6 + 10, M = 4e5 + 10;

int n, a, b;
double dp[N];
// dp[i] 代表手上有 i 张牌时，拿牌到 n 张牌的期望次数
// dp[n-∞] = 0

void solve()
{
    cin >> n >> a >> b;
    double sum = 0;
    if (a == 0)
    {
        for (int i = n - 1; i >= 0; --i)
        {
            sum += dp[i + a + 1];
            dp[i] += 1.0 / (b - a) * sum + 1.0 * (b - a + 1) / (b - a);
            sum -= dp[i + b];
        }
    }
    else
    {
        for (int i = n - 1; i >= 0; --i)
        {
            sum += dp[i + a];
            dp[i] += 1.0 / (b - a + 1) * sum + 1;
            sum -= dp[i + b];
        }
    }
    cout << fixed << setprecision(5) << dp[0] << endl;
}
```

## 牛客周赛29 F. 小红又战小紫

>![image-20240314011506539](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240314011506539.png)
>
>$1 \leq n \leq 1000, 1 \leq a_i \leq 2$

### 题解：概率 DP + 博弈

>手玩得出结论：
>
>* 如果存在石子数量为 $2$ 的堆，一定不会使用技能 $2$
>* 如果不存在石子数量为 $2$ 的堆，那么先手必赢
>
>考虑概率 DP，定义 $dp[i][j]$ 代表总共有 $i$ 堆石子，其中有 $j$ 堆石子数量为 $2$ 时先手必胜的概率
>
>考虑转移：
>
>已知 $dp[i][0] = 1$，若 $j > 0$ 时： 
>
>* 如果选到石子数量为 $1$ 的堆，$dp[i][j] += \frac{i - j}{i} \times (1 - dp[i - 1][j])$
>* 如果选到石子数量为 $2$ 的堆：$dp[i][j] += \frac{j}{i} \times (1 - dp[i][j - 1])$
>
>为什么要 $(1 - dp[i - 1][j])$ 呢，因为 $dp[i][j]$ 的时候我们是先手， 从 $dp[i - 1][j]$ 转移过来时，我们是后手，所以我们要乘上对手先手必输的概率

## 牛客周赛29 F. 小红叒战小紫

>![image-20240314213234467](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240314213234467.png)
>
>$1 \leq n, m \leq 50, 1\leq a_i, b_i \leq 2$

### 题解：期望 DP

>显然期望的性质无法解决该问题，考虑期望 DP
>
>定义 $dp[i][j][x][y]$ 代表小红共有 $i$ 只怪兽，其中 $x$ 只怪兽战斗力为 $1$，小紫有 $j$ 只怪兽，其中 $y$ 只怪兽战斗力为 $1$ 时，回合数的期望
>
>考虑转移：共有四种情况
>
>* 两个人都选到战斗力为 $1$ 的怪兽：$p1 \times (dp[i][j][x][y] + 1)$
>* 两个人都选到战斗力为 $2$ 的怪兽：$p2 \times (dp[i][j][x][y] + 1)$
>* 小红选到战斗力为 $1$ 的怪兽，小紫选到战斗力为 $2$ 的怪兽：$p3 \times (dp[i - 1][j][x - 1][y] + 1), x \geq 1$
>* 小红选到战斗力为 $2$ 的怪兽，小紫选到战斗力为 $1$ 的怪兽：$p4 \times (dp[i][j - 1][x][y - 1] + 1), y \geq 1$
>
>显然 $p1 + p2 + p3 + p4 = 1$
>$$
>dp[i][j][x][y] = p1 \times (dp[i][j][x][y] + 1) +p2 \times (dp[i][j][x][y] + 1) + p3 \times (dp[i - 1][j][x - 1][y] + 1) + p4 \times (dp[i][j - 1][x][y - 1] + 1) \\
>(1 - p1 - p2)\times dp[i][j][x][y] = p3 \times dp[i - 1][j][x - 1][y] + p4 \times dp[i][j - 1][x][y - 1] + 1 \\
>dp[i][j][x][y] = \frac{p3 \times dp[i - 1][j][x - 1][y] + p4 \times dp[i][j - 1][x][y - 1] + 1 \\}{p3 + p4}
>$$
>不过我们发现状态还能再优化，定义 $dp[i][j]$ 代表小红共有 $i$ 只战斗力为 $1$ 的怪兽，小紫共有 $j$ 只战斗力为 $1$ 的怪兽时的回合数的期望，转移是类似的，此时复杂度被优化到了 $O(n^2)$

## 上海省赛 I - It Takes Two of Two

>![image-20240428090844110](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240428090844110.png)

### 题解：几何分布 + 记忆化搜索

>图内连通块的形态可以分为这两种：环、链：
>
>* 如果将节点数量 > 2 的长链首尾连接，将变链为环；
>* 但如果将节点数量 = 2 的短链首尾连接，将产生重边。
>* 因此我们只关心某一种状态下
>  * 未选择过的点的数量
>  * 图中短链的数量
>  * 图中长链的数量
>* 每随机生成一个 $u,v$，它有可能是
>
>![image-20240428091213033](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240428091213033.png)
>
>令 $P = \sum_{情况 1-7}p_i$ 代表情况 $1-7$ 所有情况出现的概率之和，我们随机一次不一定会选中情况 $1-7$ 中的某一个，如果选到情况 $8$ 需要重新来，所以显然是一个几何分布，即期望 $\frac{1}{P}$ 次选中 $1-7$ 中的某一个
>
>所以 $dp(a, b, c) = \sum (dp(next) + \frac{1}{P}) \times \frac{p_i}{P}$

