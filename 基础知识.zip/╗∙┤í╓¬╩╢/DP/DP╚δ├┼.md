# 线性DP

##  [数字三角形](https://www.acwing.com/activity/content/problem/content/1002/) 

>给定一个如下图所示的数字三角形，从顶部出发，在每一结点可以选择移动至其左下方的结点或移动至其右下方的结点，一直走到底层，要求找出一条路径，使路径上的数字的和最大。
>
>![image-20230417190129709](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230417190129709.png)

>状态表示：$dp[i][j]$代表从$(1,1)$到$(i,j)$的路径和最大值
>
>状态属性：$MAX$
>
>状态计算：$(i,j)$可以由$(i-1,j-1)和(i-1,j)$转移
>$$
>dp[i][j]=max(dp[i-1][j],dp[i-1][j-1])+a[i][j]
>$$
>状态初始：初始化为$-INF$，  $dp[1][1] = a[1][1]$
>
>答案呈现：$\sum max(dp[n][i])$

~~~cpp

const int N = 5e2 + 10;

int dp[N][N];
int a[N][N];

void slove()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= i; ++j)
            cin >> a[i][j];	
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= i + 1; ++j)
            dp[i][j] = -INF;
    dp[1][1] = a[1][1];
    for (int i = 2; i <= n; ++i)
        for (int j = 1; j <= i; ++j)
            dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - 1]) + a[i][j];
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, dp[n][i]);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~

## 最长上升子序列 ($LIS$) $O(n^2)$

>状态表示：$dp[i]$代表以第$i$个数字结尾的最长上升子序列的长度
>
>状态属性：$MAX$
>
>状态计算：以$a[i]$结尾的所有子序列可以由所有以$a[j],j<i,a[j]<a[i]$结尾的子序列转移
>$$
>dp[i] = max(dp[i],dp[j]+1),j<i\  \wedge\ a[j]<a[i]
>$$
>状态初始：$dp[i]=1$
>
>答案呈现：$max(\sum dp[i])$

~~~cpp
const int N = 2e5 + 10;

int dp[N], a[N];
int n;

void slove()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        dp[i] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j < i; ++j)
        {
            if (a[j] < a[i])
                dp[i] = max(dp[i], dp[j] + 1);
        }
    int ans = 0;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, dp[i]);
    cout << ans << endl;
}
~~~

## 最长上升子序列  $O(nlogn)$

>* 利用贪心的思想实现
>* 维护一个单调递增的且最长的子序列$ans$
>* 如果当前元素$x$比序列末尾元素大，直接添加到序列尾部
>* 如果当前元素$x$比序列末尾元素小，贪心的替换掉序列$ans$中第一个大于等于$x$的元素，因为这样的序列至少不会比原来序列来的更差

~~~cpp
const int N = 1e5 + 10;

int n;
int a[N];
int ans[N];

void slove()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];

    int len = 1;
    ans[1] = a[1];
    for (int i = 2; i <= n; ++i)
    {
        if (a[i] > ans[len])
        {
            len++;
            ans[len] = a[i];
        }
        else
        {
            int pos = lower_bound(ans + 1, ans + 1 + len, a[i]) - ans;
            ans[pos] = a[i];
        }
    }
    cout << len << endl;
}
~~~

## 最长公共子序列 ($LCS$)

>状态表示：$dp[i][j]$代表$[1,i]和[1,j]$中的最长公共子序列
>
>状态属性：$MAX$
>
>状态计算：$dp[i][j]$可以划分为4个集合：
>
>1. 既不选$i$，也不选$j$ ：$dp[i-1][j-1]$
>2. 选$i$，不选$j$：$dp[i][j-1]$
>3. 不选$i$，选$j$：$dp[i-1][j]$
>4. $i，j$都选：$dp[i-1][j-1] + 1,s1[i]=s2[j]$
>
>$$
>dp[i][j]=max(dp[i][j-1],dp[i-1][j])\\
>dp[i][j]=max(dp[i][j],dp[i-1][j-1]+1),s1[i]=s2[j]
>$$
>
>状态初始：$dp[0][0]=0$

~~~cpp
const int N = 1e3 + 10;

int n, m;
string a, b;
int dp[N][N];

void slove()
{
    cin >> n >> m;
    cin >> a >> b;
    a = " " + a;
    b = " " + b;

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
        {
            dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            if (a[i] == b[j])
                dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + 1);
        }

    cout << dp[n][m] << endl;
}
~~~

## 最长公共子串($LCP$)

>状态表示：$dp[i][j]$代表$[1,i]和[1,j]$中的最长公共子串长度
>
>状态属性：$MAX$
>
>状态计算：$dp[i][j]$可以划分为4个集合：
>
>1.既不选$i$，也不选$j$ : $0$
>
>2.选$i$，不选$j$ ：$0$
>
>3.不选$i$，选$j$：$0$
>
>4.$i，j$都选：$dp[i-1][j-1]+1,s_1[i]=s_2[j]$
>
>状态转移方程：$dp[i][j]=\begin{cases} dp[i-1][j-1]+1，s_1[i]=s_2[j] \\ 0， s_1[i]\neq s_2[j]\end{cases}$
>
>初始化：$dp[0][0]=0$

## 最短编辑距离

>给定两个字符串 A 和 B，现在要将 A 经过若干操作变为B，可进行的操作有：
>
>1. 删除–将字符串 A 中的某个字符删除。
>2. 插入–在字符串 A 的某个位置插入某个字符。
>3. 替换–将字符串 A 中的某个字符替换为另一个字符。
>
>现在请你求出，将 A 变为 B 至少需要进行多少次操作

>状态表示：$dp[i][j]$代表从字符串$s1[1,i]$变成$s2[1,j]$的最小操作次数
>
>状态属性：$MIN$
>
>状态计算：$dp[i][j]$可以划分为$3$个集合：
>
>1. $[1,i]$最后一步通过删除$s1[i]$变成$[1,j]$，即$s1[1,i-1]$和$s2[1,j]$是一样的
>
>$$
>dp[i][j] = min(dp[i][j],dp[i-1][j] + 1)
>$$
>
>2. $[1,i]$最后一步通过插入$s2[j]$变成$[1,j]$，即$s1[1,i]$和$s2[1,j-1]$是一样的
>
>$$
>dp[i][j] = min(dp[i][j],dp[i][j-1] + 1)
>$$
>
>3. $[1,i]$最后一步通过替换$s1[i]$为$s2[j]$变成$[1,j]$，如果说$s1[1,i-1]=s2[1,j-1]$,那么不需要替换
>
>$$
>dp[i][j]=min\begin{cases} dp[i-1][j-1]+1，s_1[i]\neq_2[j] \\ 
>dp[i-1][j-1]， s_1[i]= s_2[j]\end{cases}
>$$
>
>状态初始：$dp[i][0]=i,dp[0][i]=i,其余初始化为INF$

~~~cpp
const int N = 1e3 + 10;

int n, m;
int dp[N][N];
string s1, s2;

void slove()
{
    cin >> n >> s1 >> m >> s2;
    s1 = " " + s1;
    s2 = " " + s2;

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            dp[i][j] = INF;
    for (int i = 1; i <= n; ++i)
        dp[i][0] = i;
    for (int i = 1; i <= m; ++i)
        dp[0][i] = i;

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
        {
            if (s1[i] == s2[j])
                dp[i][j] = min({dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1]});
            else
                dp[i][j] = min({dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + 1});
        }

    cout << dp[n][m] << endl;
}
~~~

## 编辑距离

>给定 $n$ 个长度不超过 $10$ 的字符串以及 $m$ 次询问，每次询问给出一个字符串和一个操作次数上限。
>
>对于每次询问，请你求出给定的 $n$ 个字符串中有多少个字符串可以在上限操作次数内经过操作变成询问给出的字符串
>
>每个对字符串进行的单个字符的插入、删除或替换算作一次操作
>
>$1\leq n,m \leq 1000$

>对于每次询问，暴力跑$n$遍最短编辑距离，时间复杂度为$O(10^2nm)$

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n, q;
string s[N];
int f[N][N];

void solve()
{
    cin >> n >> q;
    for (int i = 1; i <= n; ++i)
    {
        cin >> s[i];
        s[i] = " " + s[i];
    }
    while (q--)
    {
        string t;
        int k;
        cin >> t >> k;
        int m = t.length();
        t = " " + t;
        int ans = 0;
        for (int i = 1; i <= n; ++i)
        {
            for (int j = 0; j <= m; ++j)
                f[0][j] = j;
            for (int j = 0; j <= s[i].size() - 1; ++j)
                f[j][0] = j;
            for (int ii = 1; ii <= s[i].size() - 1; ++ii)
                for (int j = 1; j <= m; ++j)
                {
                    f[ii][j] = min(f[ii - 1][j] + 1, f[ii][j - 1] + 1);
                    if (s[i][ii] != t[j])
                        f[ii][j] = min(f[ii][j], f[ii - 1][j - 1] + 1);
                    else
                        f[ii][j] = min(f[ii][j], f[ii - 1][j - 1]);
                }
            if (f[s[i].size() - 1][m] <= k)
                ans++;
        }
        cout << ans << endl;
    }
}
```



#  计数DP

##  [整数划分](https://www.acwing.com/problem/content/902/)

>一个正整数 $n$ 可以表示成若干个正整数之和，形如：$n=n_1+n_2+…+n_k$，其中 $n_1≥n_2≥…≥n_k,k≥1$
>
>我们将这样的一种表示称为正整数 $n$ 的一种划分。
>
>现在给定一个正整数 $n$，请你求出 $n$ 共有多少种不同的划分方法，答案对$1e9+7$取模
>
>$1 \leq n \leq 1000$

>利用***完全背包***的思想
>
>状态表示：$dp[i][j]$代表只从前$i(1,2,..,i)$个数字中选，总和**恰好等于**$j$的方案数量
>
>状态属性：数量
>
>状态计算：$dp[i][j]$可以划分为以下几个集合：
>
>1. 不取$i$，$dp[i-1][j]$
>
>2. 取一个$i$，$dp[i-1][j-i]$
>
>3. 取两个$i$，$dp[i-1][j-2*i]$
>
>   ......
>
>
>$$
>dp[i][j]=dp[i-1][j]+dp[i-1][j-i]+dp[i-1][j-2*i]+....+dp[i-1][j-k*i],j-k*i\geq 0
>$$
>
>状态优化：(按照**完全背包**进行优化)
>$$
>\because dp[i][j]=dp[i-1][j]+dp[i-1][j-i]+dp[i-1][j-2*i]+....+dp[i-1][j-k*i]\\
>\because dp[i][j-i]=dp[i-1][j-i]+dp[i-1][j-2*i]+...+dp[i-1][j-k*i]\\
>\therefore dp[i][j] = dp[i-1][j]+dp[i][j-i]
>$$
>空间复杂度优化：一维滚动数组实现，正序遍历
>$$
>dp[j] = dp[j] + dp[j-i]
>$$
>状态初始：$dp[0][0]=1,dp[1][0]=1,dp[2][0]=1....dp[n][0]=1$,从前$i$个数字中选，总和恰好等于0的方案数量，那么我们对于每一个$i$，我们只能选择不选$i$，所以只有一种方案

~~~cpp
const int N = 1e3 + 10;

int n;
int f[N];

void solve()
{
    cin >> n;
    f[0] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = i; j <= n; ++j)
            f[j] = ((f[j] % mod) + (f[j - i] % mod)) % mod;
    cout << f[n] << endl;
}
~~~

## 硬币问题

~~~cpp
// 硬币问题：1.最小硬币数量问题；2.打印最小硬币方案；3.所有硬币组合数量问题
const int N = 2e5 + 10;
int dp[260][110]; // dp[i][j]代表用j个硬币实现金额总数i可行的方案数量
int ans[260];
int n;
void slove()
{
    int w[6] = {0, 1, 5, 10, 25, 50};
    n = 250;
    dp[0][0] = 1;
    for (int k = 1; k <= 5; ++k)         // 先遍历物品
        for (int j = 1; j <= 100; ++j)   // 再遍历限制条件，最多可以使用100个硬币，题目已经给出限制
            for (int i = 1; i <= n; ++i) // 最后遍历金额数
                if (i - w[k] >= 0)
                    dp[i][j] = dp[i][j] + dp[i - w[k]][j - 1];
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= 100; ++j)
            ans[i] += dp[i][j];
}

~~~

## 化妆品问题

>一个实验室有 $n$ 个放化学品的试管，排列在一条直线上。如果连续 $m$ 个试管中放入药品，则会发生爆炸，于是，在某些试管中可能不放药品。
>求不发生爆炸的放置药品的方案总数。

>定义 $dp[i]$ 代表只在前 $i$ 个试管中放药品且不会发生爆炸的方案数
>
>考虑转移：
>
>$dp[0] = 1$
>
>* 如果 $i < m$：$dp[i] = 2 \times dp[i - 1]$
>
>* 如果 $i = m$：$dp[i] = 2 \times dp[i - 1] - 1$
>
>* 如果 $i > m$：如果 $i$ 不放药剂一定合法，如果 $i$ 放药剂，可能会发生爆炸，即第 $i - m$ 个试管没放药剂，前 $m - 1$ 个试管都放了药剂，那么我们需要减去 $dp[i - m - 1]$ 个不合法方案
>
>  $dp[i] = 2 \times dp[i - 1] - dp[i - m - 1]$

# 状压DP

 ## 例题一：蒙德里安的梦想

>把 $n \times m$ 的棋盘分割成若干个$1 \times 2$ 的长方形，有多少种方案
>
>$1 \leq n,m \leq 11$

### 题解：$O(2^n*2^nm)$

>我们考虑先放横着的长方形，再放竖着的长方形，对于每一种合法的横着的长方形放的方案，竖着的长方形只能插入空位，不会有更多的选择，所以也就是说**总方案数等于所有合法的横着的长方形放的方案**
>
>什么情况下横着的长方形放的方案是合法的？
>
>对于每一列来说，**所有连续的空的棋盘的长度必须为偶数**
>
>* 状态表示：$O(2^n\times m)$
>
>   $f[i][j]$代表前$i$列已经摆好，从第$i-1$列伸出到第$i$列的状态为$j$（**二进制状态下**）的方案数
>
>   $j$在二进制状态下$1$的位置表示该行存在从第$i-1$列伸出到第$i$列的长方形
>
>   $j$在二进制状态下$0$的位置表示该行不存在从第$i-1$列伸出到第$i$列的长方形
>
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230425001233702.png" alt="image-20230425001233702" style="zoom:50%;" />
>
>* 状态属性：数量
>
>* 状态计算：$O(2^n)$
>
>   从所有合法的第$i-2$列伸出到第$i-1$列的状态$k$转移过来
>
>   满足转移的条件：
>
>  1. 所有从第$i-2$列伸出到第$i-1$列的长方形不能和从第$i-1$列伸出到第$i$列的长方形产生覆盖冲突
>
> $$
>  j\  \& \ k\ = \ 0
> $$
>
> <img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230425001634462.png" alt="image-20230425001634462" style="zoom:33%;" />
>
>​			2. 在从第$i-2$列伸出到第$i-1$列的长方形和从第$i-1$列伸出到第$i$列的长方形不产生冲突且伸出后的前提					下，第$i-1$列连续的空的棋盘的长度必须为偶数，因为我们需要合法填入竖着的长方形
>$$
>st[j \  |\ k ] = true
>$$
>​				$st[i]$代表状态$i$下连续的空的棋盘的长度为偶数
>$$
> f[i][j] = f[i][j] + f[i-1][k],(j\  \& \ k\ = \ 0) \wedge st[j \  |\ k ] = true
>$$
>
>* 状态初始：$f[0][0] = 1$
>
>* 答案呈现：$f[m][0]$，前$m$列已经摆好，且没有从第$m-1$列伸出长方形到第$m$列的方案数
>
>* 预处理**去除无效状态**进行优化 $O(2^n * 2 ^n)$

```cpp
//优化后200ms
const int N = 11 + 10;

int n, m;
int f[N][1 << N];
vector<int> g[1 << N];
bool st[1 << N];

void solve()
{
    while (cin >> n >> m, n || m)
    {
        for (int i = 0; i <= m; ++i)
            for (int j = 0; j < 1 << n; ++j)
                f[i][j] = 0;
        for (int i = 0; i < 1 << n; ++i)
        {
            bool is_valid = true;
            int cnt = 0;
            for (int j = 0; j < n; ++j)
            {
                if (i >> j & 1)
                {
                    if (cnt % 2 == 1)
                    {
                        is_valid = false;
                        break;
                        cnt = 0;
                    }
                }
                else
                    cnt++;
            }
            if (cnt % 2 == 1)
                is_valid = false;
            st[i] = is_valid;
        }
        for (int j = 0; j < 1 << n; ++j)
        {
            g[j].clear();
            for (int k = 0; k < 1 << n; ++k)
            {
                if (!(j & k) && st[j | k])
                    g[j].push_back(k);
            }
        }
        f[0][0] = 1;
        for (int i = 1; i <= m; ++i)
            for (int j = 0; j < 1 << n; ++j)
                for (auto k : g[j])
                    f[i][j] += f[i - 1][k]; 
        cout << f[m][0] << endl;
    }
}
```

## 例题二：最短 $Hamilton$ 路径(旅行商问题)

>给定一张 $n$ 个点的带权无向图(不存在负边权)，点从 $0∼n−1$ 标号，求起点 $0$ 到终点 $n−1$ 的最短 $Hamilton$ 路径
>
>$Hamilton$ 路径的定义是从 $0$ 到 $n−1$ 不重不漏地经过每个点恰好一次
>
>$1 \leq n \leq 20$

### 题解：$O(2^nn^2)$

>我们发现我们只要确定了**当前走到的点**$u$和**已经走过的点**，就能确定从起点到$u$的最短路径，因为我们可以任意**调整已经走过的点中的遍历顺序**，总能从这些排列方案中选出最短方案使得我们从起点经过这些点以最短路径到达终点$u$
>
>我们将**已经走过的点**利用二进制进行**状态压缩**，状态数$O(2^n)$
>
>其次当前走到的点是另一个状态，状态数$O(n)$
>
>* 状态表示：
>  $f[i][j]$：代表已经走过的点的状态为$i$（在二进制形式下）时，且当前位于点$j$（$j$也算已经被走过了）时的最短路径长度
>
>* 状态属性：$MIN$
>
>* 状态计算：$O(n)$
>
>  最后一步我们可以从所有合法的状态且位于点$k$进行转移（$k \neq j$）
>
>  符合转移的条件：
>
>  1. 状态 $i$ 中必须包含点$j$
>
> $$
>  i >> j\  \& \ 1=1
> $$
>
>  2. 状态$i$中必须包含点$k$
>
> $$
>  i >> k \ \&\  1 = 1
> $$
>
>  我们只需从将状态$i$中的点$j$去除后变成的状态$state$转移即可：
> $$
>  f[i][j] = min(f[i][j],f[i-(1 << j)][k] + w[k][j])
> $$
>
>* 状态初始：$f[1][0] = 0$代表已经走过起点，且当前在起点的状态下最短路径长度为$0$
>
>* 答案呈现： $f[(1 << n) - 1][n-1]$

```cpp
const int N = 20 + 3, M = 4e5 + 10;

int n;
int f[1 << N][N];
int w[N][N];

void solve()
{
    cin >> n;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            cin >> w[i][j];
    for (int i = 0; i < 1 << n; ++i)
        for (int j = 0; j < n; ++j)
            f[i][j] = INF;
    f[1][0] = 0;
    for (int i = 0; i < 1 << n; ++i)
        for (int j = 0; j < n; ++j)
            if (i >> j & 1)
            {
                for (int k = 0; k < n; ++k)
                    if ((i >> k & 1) && k != j)
                        f[i][j] = min(f[i][j], f[i - (1 << j)][k] + w[k][j]);
            }
    cout << f[(1 << n) - 1][n - 1] << endl;
}
```



# 记忆化搜索

## 例题：滑雪

>给定一个 $n$ 行 $m$ 列的矩阵，表示一个矩形网格滑雪场。
>
>矩阵中第 $i$ 行第 $j$ 列的点表示滑雪场的第 $i$ 行第 $j$ 列区域的高度。
>
>一个人从滑雪场中的某个区域内出发，每次可以向上下左右任意一个方向滑动一个单位距离
>
>当然，一个人能够滑动到某相邻区域的前提是**该区域的高度低于自己目前所在区域的高度**
>
>$1 \leq n,m \leq 30$

### 题解：$O(nm)$

>首先如果想利用记忆化搜索，必须保证状态转移时的图是一个**拓扑图**，也就是**没有环**的图，（为了防止某个状态通过自身转移）我们发现我们转移的前提是该区域的高度低于自己目前所在区域的高度，所以一定是个拓扑图，我们可以利用记忆化搜索
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230425212630275.png" alt="image-20230425212630275" style="zoom:33%;" />
>
>像这种情况我们**无法使用记忆化搜索**
>
>* 状态表示：$O(nm)$
>
>  $f[x][y]$：代表从坐标$(x,y)$出发的能够滑行的最长距离
>
>* 状态属性：$MAX$
>
>* 状态计算：$O(1)$
>
>  我们按照第一步出发的方向进行转移：
>
>  1. 第一步向右滑行：
>     $$
>     f[x][y] = f[x][y+1] + 1,g[x][y]>g[x][y+1]
>     $$
>
>  2. 第一步向左滑行：
>     $$
>     f[x][y] = f[x][y-1] + 1,g[x][y]>g[x][y-1]
>     $$
>
>  3. 第一步向上滑行：
>     $$
>     f[x][y] = f[x-1][y] + 1,g[x][y]>g[x-1][y]
>     $$
>
>  4. 第一步向下滑行：
>     $$
>     f[x][y] = f[x+1][y] + 1,g[x][y]>g[x+1][y]
>     $$
>
>* 状态初始：$f[x][y] = 1$
>
>* 答案呈现：$max\sum f[x][y]$

```cpp
const int N = 3e2 + 10, M = 4e5 + 10;

int n, m;
int g[N][N];
int f[N][N];
int dir[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

int dfs(int x, int y)
{
    if (f[x][y])
        return f[x][y];
    f[x][y] = 1;
    for (int i = 0; i < 4; ++i)
    {
        int nx = x + dir[i][0];
        int ny = y + dir[i][1];
        if (nx >= 1 && nx <= n && ny >= 1 && ny <= m && g[nx][ny] < g[x][y])
            f[x][y] = max(f[x][y], dfs(nx, ny) + 1);
    }
    return f[x][y];
}

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            cin >> g[i][j];
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            ans = max(ans, dfs(i, j));
    cout << ans << endl;
}
```



