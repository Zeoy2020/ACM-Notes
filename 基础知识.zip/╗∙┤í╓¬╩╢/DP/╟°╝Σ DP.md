## 模板

```cpp
for (int l = n; l >= 1; --l) {
    for (int r = l; r <= n; ++r) {
          for (int k = l; k < r; ++k) {
          }
        }
}
/* 枚举长度  */
for (int len = 1; len <= n; ++len) {
    /* 枚举左端点 i */
    for (int i = 1; i + len - 1 <= n; ++i) {
       /* 右端点 j */
       int j = i + len - 1;
          /* 枚举分界线 k */
          for (int k = i; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + w);
            }
        }
}
```

## 括号序列

>![image-20240312205749250](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240312205749250.png)

### 题解

>定义 $dp[i][j]$ 代表 $[i, j]$ 中最长的合法子序列长度
>
>考虑转移：
>
>* 如果 $s[i] = s[j]$，则 $dp[i][j] = \max(dp[i][j], dp[i + 1][j - 1] + 2)$
>* 枚举分界线 $k$，$dp[i][j] = \max(dp[i][j], dp[i][k] + dp[k + 1][j])$
>
>状态初始化：$dp[i][j] = 0$

