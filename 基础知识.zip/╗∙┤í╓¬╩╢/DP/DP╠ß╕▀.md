# 数字三角形模型

>给定一个如下图所示的数字三角形，从顶部出发，在每一结点可以选择移动至其左下方的结点或移动至其右下方的结点，一直走到底层，要求找出一条路径，使路径上的数字的和最大
>
>![image-20230417190129709](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230417190129709.png)

>状态表示：$f[i][j]$代表从$(1,1)$到$(i,j)$的路径和最大值
>
>状态属性：$MAX$
>
>状态计算：$(i,j)$可以由$(i-1,j-1)和(i-1,j)$转移
>$$
>f[i][j]=max(f[i-1][j],f[i-1][j-1])+a[i][j]
>$$
>状态初始：初始化为$-INF$，  $f[1][1] = a[1][1]$
>
>答案呈现：$\sum max(f[n][i])$

~~~cpp
const int N = 5e2 + 10;

int dp[N][N];
int a[N][N];

void slove()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= i; ++j)
            cin >> a[i][j];	
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= i + 1; ++j)
            dp[i][j] = -INF;
    dp[1][1] = a[1][1];
    for (int i = 2; i <= n; ++i)
        for (int j = 1; j <= i; ++j)
            dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - 1]) + a[i][j];
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, dp[n][i]);
    cout << ans << endl;
}
~~~



## 摘花生

>给定一个 $n \times m$ 的矩阵，矩阵中每个元素的值非负，现在你需要从矩阵的左上角$(1,1)$到右下角$(n,m)$,每一步只能向右或向下走，请你找到一条路径使得该路径上经过的元素的和最大，请你求出最大的和
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230502150842785.png" alt="image-20230502150842785" style="zoom:67%;" />
>
>$1 \le n,m \le 100$

### 题解：线性DP $O(n^2)$

>* 状态表示：
>
>  $f[i][j]$代表从起点$(1,1)$到$(i,j)$的所有路径中的元素之和最大值
>
>* 状态属性：$MAX$
>
>* 状态计算：按照最后一步从上面或者左边过来进行划分
>
>  1. 最后一步从上面过来：$f[i-1][j]$
>  2. 最后一步从左边过来：$f[i][j-1]$
>
> $$
>  f[i][j] = max(f[i-1][j],f[i][j-1])+a[i][j]
> $$
>
>* 状态初始：$f[1][1] = a[1][1],f[i][j] = 0$
>
>* 答案呈现：$f[n][m]$

```cpp
const int N = 1e2 + 10;

int n, m;
int a[N][N];
int f[N][N];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
        {
            cin >> a[i][j];
            f[i][j] = 0;
        }
    f[1][1] = a[1][1];
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            f[i][j] = max(f[i - 1][j] + a[i][j], f[i][j - 1] + a[i][j]);
    cout << f[n][m] << endl;
}
```



## 最低通行费

>一个商人穿过一个 $N×N$ 的正方形的网格，去参加一个非常重要的商务活动。
>
>他要从网格的左上角进，右下角出。
>
>每穿越中间 $1$ 个小方格，都要花费 $1$ 个单位时间。
>
>商人必须在 $(2N−1)$ 个单位时间穿越出去。
>
>而在经过中间的每个小方格时，都需要缴纳一定的费用。
>
>这个商人期望在规定时间内用最少费用穿越出去
>
>$1 \le n \le 100$

### 题解：线性DP $O(n^2)$

>我们发现这名商人最少从这个正方形网格中穿出去的时间都需要$2N-1$个单位，说明他不能走回头路，**只能往下或者往右走**，那么这道题又等价于上面那题摘花生了，$dp$过程不再赘述

```cpp
const int N = 1e2 + 10;

int n;
int a[N][N];
int f[N][N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            cin >> a[i][j];
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= n; ++j)
            f[i][j] = INF;
    f[1][1] = a[1][1];
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            f[i][j] = min({f[i][j], f[i - 1][j] + a[i][j], f[i][j - 1] + a[i][j]});
    cout << f[n][n] << endl;
}
```



## 方格取数

>设有 $n×n$ 的方格图，我们在其中的某些方格中填入正整数，而其它的方格中则放入数字$0$。如下图所示：
>
>![2.gif](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/19_764ece6ed5-2.gif)
>
>某人从图中的左上角 $A$ 出发，可以**向下**行走，也可以**向右**行走，直到到达右下角的 $B$ 点
>
>在走过的路上，他可以取走方格中的数（**取走后的方格中将变为数字**$0$）
>
>此人从 $A$ 点到 $B$ 点共走了**两次**，试找出两条这样的路径，**两条路径上的点可以重复**，使得取得的数字和为最大
>
>$1 \le n \le 10$

### 题解：线性DP $O(n^3)$

>* 状态表示：$O(n^4)$
>
>  $f[i_1][j_1][i_2][j_2]$代表所有从$(1,1)$到$(i_1,j_1)$和从$(1,1)$到$(i_2,j_2)$的两条路线中数字之和的最大值
>
>* 状态属性：$MAX$
>
>* 状态计算：可以从上或者从左到$(i_1,j_1)$，可以从上或者从左到$(i_2,j_2)$，那么一共有$2 \times  2 = 4$种选择 $O(1)$
>
>  1. 从左边到$(i_1,j_1)$，从左边到$(i_2,j_2)$：$f[i_1][j_1-1][i_2][j_2-1]$
>  2. 从左边到$(i_1,j_1)$，从上边到$(i_2,j_2)$：$f[i_1][j_1-1][i_2-1][j_2]$
>  3. 从上边到$(i_1,j_1)$，从左边到$(i_2,j_2)$：$f[i_1-1][j_1][i_2][j_2-1]$
>  4. 从上边到$(i_1,j_1)$，从上边到$(i_2,j_2)$：$f[i_1-1][j_1][i_2-1][j_2]$
>
>  注意：如果$(i_1,j_1)$ = $(i_2,j_2)$，那么我们只能取一次该位置上的数字
> $$
>  f[i_1][j_1][i_2][j_2] = max({f[i_1 - 1][j_1][i_2 - 1][j_], f[i_1 - 1][j_1][i_2][j_2 - 1], f[i_1][j_1 - 1][i_2 - 1][j_2], f[i_1][j_1 - 1][i_2][j_2 - 1]}) + g[i_1][j_1] \\
>  (i_1,j_1) ==(i_2,j_2)
> $$
>
> $$
>  f[i_1][j_1][i_2][j_2] = max({f[i_1 - 1][j_1][i_2 - 1][j_], f[i_1 - 1][j_1][i_2][j_2 - 1], f[i_1][j_1 - 1][i_2 - 1][j_2], f[i_1][j_1 - 1][i_2][j_2 - 1]}) + g[i_1][j_1]+g[i_2][j_2] \\
>  (i_1,j_1)\neq(i_2,j_2)
> $$
>
>  
>
>* 状态优化：$O(n^3)$
>
>  我们发现只有步数一样的时候两条路线才有可能重合，设走过的步数为$k$，那么如果$i_1=i_2$，就说明两条路线在这个点重合了，该点坐标为$(i_1,k-i_1)$，所以我们可以将状态合并为：
>
>  $f[k][i_1][i_2]$代表经过$k$步后，一条路线现在经过的点的横坐标为 $i_1$，另一条路线现在经过的点的横坐标为$i_2$，两条路线中数字之和的最大值
>
>  状态计算和上面一样，不再赘述
>
>  状态初始：$f[2][1][1] = g[1][1]$
>
>  答案呈现：$f[2 * n][n][n]$

```cpp
const int N = 12, M = 4e5 + 10;

int n;
int g[N][N];
int f[N << 1][N][N];

void solve()
{
    cin >> n;
    int a, b, c;
    while (cin >> a >> b >> c, a || b || c)
    {
        g[a][b] = c;
    }
    f[2][1][1] = g[1][1];
    for (int k = 3; k <= 2 * n; ++k)
        for (int i1 = 1; i1 <= n; ++i1)
            for (int i2 = 1; i2 <= n; ++i2)
            {
                int j1 = k - i1, j2 = k - i2;
                if (j1 >= 1 && j1 <= n && j2 >= 1 && j2 <= n)
                {
                    if (i1 == i2)
                        f[k][i1][i2] = max({f[k - 1][i1 - 1][i2 - 1], f[k - 1][i1][i2 - 1], f[k - 1][i1 - 1][i2], f[k - 1][i1][i2]}) + g[i1][j1];
                    else
                        f[k][i1][i2] = max({f[k - 1][i1 - 1][i2 - 1], f[k - 1][i1][i2 - 1], f[k - 1][i1 - 1][i2], f[k - 1][i1][i2]}) + g[i1][j1] + g[i2][j2];
                }
            }
    cout << f[2 * n][n][n] << endl;
}
```



## 传纸条

>给定一个 $n \times m$ 的矩阵，矩阵中每个元素的值非负，现在你需要从矩阵的左上角$(1,1)$到右下角$(n,m)$,每一步只能向右或向下走，然后再从矩阵的右下角$(n,m)$到左上角$(1,1)$,每一步只能向左或向上走，且**之前经过的点不能再经过**，请你找到一条路径使得该路径上经过的元素的和最大，请你求出最大的和

### 题解：线性$DP$   $O(n^3)$

>不难发现任意一条从矩阵的右下角$(n,m)$到左上角$(1,1)$的路线都能将其方向反转后变成从矩阵的左上角$(1,1)$到右下角$(n,m)$的一条路线，且经过的点不变
>
>所以我们可以将题目转化为**从矩阵的左上角$(1,1)$到右下角$(n,m)$走两次,每一步只能向右或向下走，且第二次走的路线中的点不能和第一次经过的点有交集**
>
>那么实际上已经和**方格取数**的$dp$模型非常接近了，我们只要解决两次经过的点不存在交集的问题即可，那么实际上我们可以证明**方格取数**的$dp$模型在这道题同样适用于解决两次经过的点不存在交集的问题，下面请看证明：
>
>如果两条最优线路是交叉的
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230502155849518.png" alt="image-20230502155849518" style="zoom: 33%;" />
>
>我们可以将其交叉的部分进行交换变成：
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230502155955590.png" alt="image-20230502155955590" style="zoom: 67%;" />
>
>所以所有存在交叉的最优线路都能转化为存在交点的两条路线，我们只需要考虑**如何解决两条路线不交叉，但是存在交点的情况**
>
>![image-20230502160213954](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230502160213954.png)
>
>根据最优路线我们知道$w_A=w_B=0$，所以我们可以微调其中一条路线，使得两条路径不经过重合点，且不影响路线的最优性

```cpp
const int N = 55, M = 4e5 + 10;

int n, m;
int g[N][N];
int f[N << 1][N][N];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            cin >> g[i][j];
    f[2][1][1] = g[1][1];
    for (int k = 3; k <= n + m; ++k)
        for (int i1 = 1; i1 <= n; ++i1)
            for (int i2 = 1; i2 <= n; ++i2)
            {
                int j1 = k - i1, j2 = k - i2;
                if (j1 >= 1 && j1 <= m && j2 >= 1 && j2 <= m)
                {
                    if (i1 == i2)
                        f[k][i1][i2] = max({f[k - 1][i1 - 1][i2 - 1], f[k - 1][i1][i2 - 1], f[k - 1][i1 - 1][i2], f[k - 1][i1][i2]}) + g[i1][j1];
                    else
                        f[k][i1][i2] = max({f[k - 1][i1 - 1][i2 - 1], f[k - 1][i1][i2 - 1], f[k - 1][i1 - 1][i2], f[k - 1][i1][i2]}) + g[i1][j1] + g[i2][j2];
                }
            }
    cout << f[n + m][n][n] << endl;
}
```



# 最长上升子序列模型

## 怪盗基德的滑翔翼

>假设城市中一共有$n$幢建筑排成一条线，每幢建筑的高度各不相同
>
>初始时，怪盗基德可以在**任何一幢建筑的顶端**。
>
>他可以选择一个方向逃跑，但是**不能中途改变方向**
>
>怪盗基德只能从**较高的建筑滑翔到较低**的建筑
>
>他希望尽可能多地经过不同建筑的顶部，这样可以减缓下降时的冲击力，减少受伤的可能性。
>
>请问，他最多可以经过多少幢不同建筑的顶部(包含初始时的建筑)？
>
>$1 \le n  \le 100$

### 题解：最长上升子序列 $O(n^2)$ : 可以利用贪心优化至$O(nlogn)$

>我们发现其从较高建筑滑翔至较低建筑的过程，并求其最多可以经过多少建筑，这个过程本质上和最长上升子序列问题是一样的，所以实际上我们只需要正序做一次最长上升子序列，倒序做一次最长上升子序列，然后枚举从每一个建筑出发即可

```cpp
const int N = 1e2 + 10, M = 4e5 + 10;

int n;
int a[N];
int pre_f[N];
int suf_f[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        pre_f[i] = suf_f[i] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j < i; ++j)
            if (a[i] > a[j])
                pre_f[i] = max(pre_f[i], pre_f[j] + 1);
    for (int i = n; i >= 1; i--)
        for (int j = n; j > i; j--)
            if (a[i] > a[j])
                suf_f[i] = max(suf_f[i], suf_f[j] + 1);
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max({ans, pre_f[i], suf_f[i]});
    cout << ans << endl;
}
```



## 合唱队形

>$n$ 位同学站成一排，音乐老师要请其中的$n-k$位同学出列，使得剩下的 $k$ 位同学排成合唱队形。     
>
>合唱队形是指这样的一种队形：设 $k$ 位同学从左到右依次编号为 $1，2…，k$ 他们的身高分别为 $T_1，T_2，…，T_k$ 则他们的身高满足 $T_1<…<T_i>T_{i+1}>…>T_k(1≤i≤k)$     
>
>你的任务是，已知所有 $n$ 位同学的身高，计算最少需要几位同学出列，可以使得剩下的同学排成合唱队形。

### 题解：最长上升子序列

>题目中让我们计算最少需要多少个同学出列，我们可以将题目转化为**最多有多少位同学可以拍成合唱队形**，那么多余的人数就是最少需要出列的同学人数
>
>我们发现最高的同学$i$左侧是最长上升子序列，右侧是最长下降子序列，那么我们只需要枚举将每一位同学作为合唱队形中最高的同学即可，注意最后两个长度加起来时需要减去1，因为根据容斥，中间最高的那名同学多算了1次

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n;
int a[N];
int pre_f[N];
int suf_f[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        pre_f[i] = suf_f[i] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j < i; ++j)
            if (a[i] > a[j])
                pre_f[i] = max(pre_f[i], pre_f[j] + 1);
    for (int i = n; i >= 1; i--)
        for (int j = n; j > i; j--)
            if (a[i] > a[j])
                suf_f[i] = max(suf_f[i], suf_f[j] + 1);
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max({ans, pre_f[i] + suf_f[i] - 1});
    cout << n - ans << endl;
}
```



## 最大上升子序列和

>给你一个子序列，让你求出该序列中的最大上升子序列和

### 题解：线性$DP$

>* 状态表示：$f[i]$代表以第$i$个数结尾的最长上升子序列和
>
>* 状态属性：$MAX$
>
>* 状态计算：
>
>$$
>f[i] = max(f[i],f[j] + a[i]),a[i] > a[j] \wedge j < i
>$$
>
>* 状态初始：$f[i] = a[i]$
>
>* 答案呈现：$max\sum f[i]$

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n;
int a[N];
int f[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        f[i] = a[i];
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j < i; ++j)
            if (a[j] < a[i])
                f[i] = max(f[i], f[j] + a[i]);
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, f[i]);
    cout << ans << endl;
}
```



## 拦截导弹

>某国为了防御敌国的导弹袭击，发展出一种导弹拦截系统。
>
>但是这种导弹拦截系统有一个缺陷：虽然**它的第一发炮弹能够到达任意的高度，但是以后每一发炮弹都不能高于前一发的高度**
>
>某天，雷达捕捉到敌国的导弹来袭。
>
>由于该系统还在试用阶段，所以**只有一套系统**，因此有可能不能拦截所有的导弹。
>
>输入导弹依次飞来的高度（雷达给出的高度数据是不大于$30000$的正整数，导弹数不超过$1000$），计算这套系统**最多能拦截多少导弹**，如果要拦截所有导弹**最少要配备多少套这种导弹拦截系统**

### 题解：贪心 + $DP$: $O(nlogn)$ / $Dilworth$定理

>显然第一个问题是一个非常明显的最长不上升子序列问题，做法两种：一种是$dp:O(n^2)$，另一种是贪心:$O(nlongn)$，我们这里选择的是贪心的方法，不再赘述
>
>我们来想一想第二个问题：
>
>我们将第二个问题转化为：**一个序列最少需要用多少个不上升子序列能够将其覆盖掉**
>
>也就是说我们需要将每个数分配到一个不上升子序列中，我们考虑贪心解决，类似最长不上升子序列的贪心方法：
>
>1. 我们利用数组$g$维护所有不上升子序列的**结尾数字**
>2. 对于每一个需要分配的数字$x$，我们贪心的将其分配进入所有结尾数字中**第一个比$x$大的不上升序列中**
>3. 如果数字$x$比每一个结尾数字都要大的话，说明$x$需要自己作为一个不上升子序列，即新建一个不上升子序列
>
>我们发现数组$g$中的结尾数字单调递增，所以每次分配的位置我们可以利用二分找到，那么最终复杂度为$O(nlogn)$
>
>我们惊奇的发现其贪心的过程不就是求最长子序列长度的贪心过程嘛，实际上这里存在一个定理：
>
>**$Dilworth$定理：一个序列最少用多少个不上升子序列将其覆盖掉的数量等于该序列最长上升子序列的长度**

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n;
int a[N];
int f[N];
multiset<int> st;

void solve()
{
    int x;
    while (cin >> x)
        a[++n] = x;
    int len = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (len == 0 || (len > 0 && a[i] <= f[len]))
            f[++len] = a[i];
        else if (len > 0 && a[i] > f[len])
        {
            int p = upper_bound(f + 1, f + len + 1, a[i], greater<int>()) - f;
            f[p] = a[i];
        }
    }
    int ans2 = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (st.empty() || (st.size() && *(prev(st.end())) < a[i]))
        {
            ans2++;
            st.insert(a[i]);
        }
        else if (st.size() && *(prev(st.end())) >= a[i])
        {
            st.erase(st.lower_bound(a[i]));
            st.insert(a[i]);
        }
    }
    cout << len << endl;
    cout << ans2 << endl;
}
```



## 导弹防御系统

>为了对抗附近恶意国家的威胁，$R$ 国更新了他们的导弹防御系统。
>
>一套防御系统的导弹拦截高度要么一直 **严格单调** 上升要么一直 **严格单调** 下降。
>
>例如，一套系统先后拦截了高度为 $3$ 和高度为 $4$ 的两发导弹，那么接下来该系统就只能拦截高度大于 $4$ 的导弹
>
>给定即将袭来的一系列$n$个导弹的高度，请你求出至少需要多少套防御系统，就可以将它们全部击落
>
>$1 \le n \le 50$

### 题解：$DFS$求最优解(迭代加深 / 全局最优解) + 贪心  $O(n2^{50})$

 >我们将题目转化为：**一个序列最少需要用多少个上升子序列和下降子序列能够将其覆盖掉**
 >
 >如果说只用一种序列，我们完全可以用**拦截导弹**的贪心方法解决，但是这里既可以用上升子序列，又可以用下降序列，并且数据范围比较小，所以我们完全可以使用$dfs$**爆搜 + 剪枝**解决
 >
 >* 首先我们需要明确搜索的顺序，怎样才能枚举完所有的方案？
 >
 >  1. 对于每一个数，我们枚举该数放在上升序列还是放在下降序列中
 >
 >  2. 如果该数放在上升序列，那么我们枚举该数放在哪个上升序列中
 >
 >     如果该数放在下降序列，那么我们枚举该数放在哪个下降序列中
 >
 >  对于上述的搜索顺序，一定能够枚举完所有的合法方案
 >
 >  但是复杂度太高了，我们需要对其剪枝，我们发现我们维护一个所有上升序列结尾数字数组$up[]$和一个所有下降序列结尾数字数组$down[]$，这样的话我们借用拦截导弹的贪心思想：
 >
 >* 如果我们将一个数放在某个上升序列的末尾，那么根据贪心的思想，这个数一定是放在第一个末尾数字比这个数小的上升序列后面，如果我们找不到任何一个上升序列放该数字，说明该数字单独作为一个新的上升序列
 >
 >* 如果我们将一个数放在某个下降序列的末尾，那么根据贪心的思想，这个数一定是放在第一个末尾数字比这个数大的下降序列后面，如果我们找不到任何一个下降序列放该数字，说明该数字单独作为一个新的下降序列
 >
 >* 那么此时我们发现我们维护的$up$数组一定是单调递减的，$down$数组一定是单调递增的，所以我们在搜索时枚举该数放在哪个上升或者下降序列时，只要枚举到$up$数组中第一个比这个数小的序列末尾或者枚举到$down$数组中第一个比这个数大的序列末尾即可，这是一个很不错的剪枝
 >
 >* 但是我们还需要考虑一个问题，如何在$dfs$爆搜的过程中得到最小值：
 >
 >  有两种方法：
 >
 >  1. **迭代加深**：一般用于**平均答案比较小**的情况下，比如说本题，在本题中我们**迭代的深度$depth$代表现在上升序列和下降序列的个数之和**，所以说**如果我们在某一次迭代过程中上升序列和下降序列之和超过了$depth$，我们可以直接退出迭代**，进行下一次迭代，直到迭代成功
 >  2. **全局最优解**：在枚举的所有可行方案中找到全局最优解，但是需要注意剪枝：**如果现在的上升序列和下降序列之和已经大于等于了当前最优解，直接退出即可**，说明当前解不可能产生全局最优解
 >
 >

```cpp
//方法一：迭代加深
const int N = 55, M = 4e5 + 10;

int n;
int a[N];
int up[N];
int down[N];

bool dfs(int depth, int u, int num_up, int num_down)
{
    if (num_up + num_down > depth) 
        return false;
    if (u == n + 1)
        return true;

    // 枚举放入单调上升序列中
    bool flag = false;
    for (int i = 1; i <= num_up; ++i) // up数组单调递减
    {
        if (up[i] < a[u])
        {
            int t = up[i];
            up[i] = a[u];
            if (dfs(depth, u + 1, num_up, num_down))
                return true;
            up[i] = t;		//还原现场
            flag = true;
            break;			//贪心剪枝，直接可以退出
        }
    }
    if (!flag) //如果任何一个上升序列都放不进
    {
        up[num_up + 1] = a[u];
        if (dfs(depth, u + 1, num_up + 1, num_down))
            return true;
        down[num_down + 1] = 0;
    }

    // 枚举放入单调下降序列中
    flag = false;
    for (int i = 1; i <= num_down; ++i) // down数组单调递增
    {
        if (down[i] > a[u])
        {
            int t = down[i];
            down[i] = a[u];
            if (dfs(depth, u + 1, num_up, num_down))
                return true;
            down[i] = t;	//还原现场
            flag = true;
            break;			//贪心剪枝
        }
    }
    if (!flag)  //如果任何一个下降序列都放不进
    {
        down[num_down + 1] = a[u];
        if (dfs(depth, u + 1, num_up, num_down + 1))
            return true;
        down[num_down + 1] = 0;
    }
    return false;
}

void solve()
{
    while (cin >> n, n)
    {
        for (int i = 1; i <= n; ++i)
            cin >> a[i];
        int depth = 0;
        while (!dfs(depth, 1, 0, 0))	//迭代加深，直到迭代成功
            depth++;
        cout << depth << endl;
    }
}
```

```cpp
//方法二：全局最优解
const int N = 55, M = 4e5 + 10;

int n;
int a[N];
int up[N];
int down[N];
int ans;

void dfs(int u, int num_up, int num_down)
{
    if (num_up + num_down >= ans)		//如果大于当前最优解，直接退出
        return;
    if (u == n + 1)
    {
        ans = min(ans, num_up + num_down);
        return;
    }

    // 枚举放入单调上升序列中
    bool flag = false;
    for (int i = 1; i <= num_up; ++i) // up数组单调递减
    {
        if (up[i] < a[u])
        {
            int t = up[i];
            up[i] = a[u];
            dfs(u + 1, num_up, num_down);
            up[i] = t;
            flag = true;
            break;
        }
    }
    if (!flag)
    {
        up[num_up + 1] = a[u];
        dfs(u + 1, num_up + 1, num_down);
        up[num_up + 1] = 0;
    }

    // 枚举放入单调下降序列中
    flag = false;
    for (int i = 1; i <= num_down; ++i) // down数组单调递增
    {
        if (down[i] > a[u])
        {
            int t = down[i];
            down[i] = a[u];
            dfs(u + 1, num_up, num_down);
            down[i] = t;
            flag = true;
            break;
        }
    }
    if (!flag)
    {
        down[num_down + 1] = a[u];
        dfs(u + 1, num_up, num_down + 1);
        down[num_down + 1] = 0;
    }
}

void solve()
{
    while (cin >> n, n)
    {
        for (int i = 1; i <= n; ++i)
            cin >> a[i];
        ans = 100;
        dfs(1, 0, 0);
        cout << ans << endl;
    }
}
```



## 最长公共上升子序列

>给定长度都为$n$的序列$a，b$，求其最长公共上升子序列的长度

### 题解：线性$DP$ :$O(n^2)$

>* 状态表示：
>
>  $f[i][j]$代表在$[1,i]$和$[1,j]$中的，且以$b_j$结尾的公共上升子序列的最大长度
>
>* 状态属性：$MAX$
>
>* 状态计算：按照公共上升子序列中$a_i$是否存在分为两个集合：
>
>  1. $a_i$不在公共上升子序列中：$f[i-1][j]$
>  2. 如果$a_i$在公共上升子序列中，必须满足$a_i = b_j$，那么这一集合可以按照$b_j$接在哪个上升序列的末尾后面继续划分：
>     * $b_j$不接在任何一个上升序列后面：$1$
>     * $b_j$接在$b_1$后面$(b_1 < b_j)$：$f[i-1][1] + 1$
>     * $b_j$接在$b_2$后面$(b_2 < b_j)$：$f[i-1][2] + 1$
>     * ......
>     * $b_j$接在$b_{j-1}$后面$(b_{j-1} < b_j)$：$f[i-1][j-1] + 1$
>
> $$
>  f[i][j] = f[i-1][j]\\
>  f[i][j] = max(f[i][j],f[i-1][k] + 1),k < j\ \  \wedge \ \ b_k<b_j \ \ \wedge \ \ a_i = b_j
> $$
>
>* 状态初始： $f[i][j] = 0$
>
>* 答案呈现：$max\sum f[n][i]$
>
>* 时间复杂度： $O(n^3)$
>
>* 状态优化：我们发现只有$a_i = b_j$时，我们才会讨论$b_j$接在哪个上升序列的末尾后面，假设$b_j$接在末尾为$b_k$的子序列后面，则$b_k < b_j$，即$b_k < a_i$，所以我们不妨在寻找$a_i = b_j$的同时顺便维护$b_k < a_i$中的$f[i-1][k] + 1$的最大值，优化后时间复杂度为$O(n^2)$

```cpp
const int N = 3e3 + 10, M = 4e5 + 10;

int n;
int f[N][N]; // f[i][j]代表所有[1,i]和[1,j]中的，且以b[j]结尾的公共上升子序列的最大长度
int a[N], b[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        cin >> b[i];
    for (int i = 1; i <= n; ++i)
    {
        int mx = 1;
        for (int j = 1; j <= n; ++j)
        {
            f[i][j] = f[i - 1][j];
            if (a[i] == b[j])
                f[i][j] = max(f[i][j], mx);
            else if (a[i] > b[j])
                mx = max(mx, f[i - 1][j] + 1);
        }
    }
    int ans = -INF;
    for (int i = 1; i <= n; ++i)
        ans = max(ans, f[n][i]);
    cout << ans << endl;
}
```

# 背包模型

## 潜水员

>潜水员为了潜水要使用特殊的装备。
>
>他有一个带2种气体的气缸：一个为氧气，一个为氮气。
>
>让潜水员下潜的深度需要各种数量的氧和氮。
>
>潜水员有一定数量的气缸。
>
>每个气缸都有重量和气体容量。
>
>潜水员为了完成他的工作需要特定数量的氧和氮。
>
>他完成工作所需气缸的总重的最低限度的是多少？

### 题解：二维费用的背包问题

>* 状态表示：$f[i][j][k]$:代表只从前i个气缸中选，使得选出的气缸氧气容量不少于$j$升，且氮气容量不少于$k$升的最小气缸重量
>
>* 状态属性：$MIN$
>
>* 状态计算：
>
>  1. 不选第$i$个气缸：$f[i-1][j][k]$
>
>  2. 选第$i$个气缸：$f[i][max(0,j - v_{1i})][max(0,k-v_{2i})]$

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n, m, q;
int v1[N], v2[N], w[N];
int f[N][N];

void solve()
{
    cin >> n >> m >> q;
    for (int i = 1; i <= q; ++i)
        cin >> v1[i] >> v2[i] >> w[i];
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= m; ++j)
            f[i][j] = INF;
    f[0][0] = 0;
    for (int i = 1; i <= q; ++i)
        for (int j = n; j >= 0; --j)
            for (int k = m; k >= 0; --k)
                f[j][k] = min(f[j][k], f[max(j - v1[i], 0LL)][max(k - v2[i], 0LL)] + w[i]);
    cout << f[n][m] << endl;
}
```



## 数字组合（硬币问题）

>给定 $N$ 个正整数 $A_1,A_2,…,A_N$，从中选出若干个数，使它们的和为 $M$，求有多少种选择方案。

### 题解：

>状态表示：$f[i][j]$:只从前$i$个数中选择数，使得这些选出的数之和为$j$的方案数
>
>状态属性：数量
>
>状态计算：
>
>1. 不选第i个数：$f[i-1][j]$
>2. 选第i个数： $f[i-1][j-a[i]]$
>
>状态优化 ： 滚动数组优化： $f[j] += f[j - a[i]]$
>状态初始：$f[0] = 1$

```cpp
const int N = 1e2 + 10, M = 1e4 + 10;

int n, m;
int a[N];
int f[M];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    f[0] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = m; j >= 1; --j)
            if (j - a[i] >= 0)
                f[j] += f[j - a[i]];
    cout << f[m] << endl;
}
```

## [NOIP2018 提高组] 货币系统

>在网友的国度中共有 $n$ 种不同面额的货币，第 $i$ 种货币的面额为 $a[i]$，你可以假设每一种货币都有无穷多张。为了方便，我们把货币种数为 $n$、面额数组为 $a[1..n]$ 的货币系统记作 $(n,a)$。 
>
>在一个完善的货币系统中，每一个非负整数的金额 $x$ 都应该可以被表示出，即对每一个非负整数 $x$，都存在 $n$ 个非负整数 $t[i]$ 满足 $a[i] \times t[i]$ 的和为 $x$。然而， 在网友的国度中，货币系统可能是不完善的，即可能存在金额 $x$ 不能被该货币系统表示出。例如在货币系统 $n=3$, $a=[2,5,9]$ 中，金额 $1,3$ 就无法被表示出来。 
>
>两个货币系统 $(n,a)$ 和 $(m,b)$ 是等价的，当且仅当对于任意非负整数 $x$，它要么均可以被两个货币系统表出，要么不能被其中任何一个表出。 
>
>现在网友们打算简化一下货币系统。他们希望找到一个货币系统 $(m,b)$，满足 $(m,b)$ 与原来的货币系统 $(n,a)$ 等价，且 $m$ 尽可能的小。他们希望你来协助完成这个艰巨的任务：找到最小的 $m$。

### 题解：完全背包解决极大线性无关组问题

>* 容易发现我们需要找到一个最小的货币系统，且这个货币系统能够线性表示原来货币系统中所有的面值，所以实际上就是让我们求原来货币系统的极大线性无关组的大小
>* 所以我们利用完全背包求出每种金额的货币的方案数，方案数为$1$的一定是极大线性无关组中的一员
>* 即求出多少个货币的方案数为$1$即可

```cpp
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];
int f[N];

void solve()
{
    cin >> n;
    int mx = -INF;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        mx = max(mx, a[i]);
    }
    for (int i = 0; i <= mx; ++i)
        f[i] = 0;
    f[0] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = a[i]; j <= mx; ++j)
            f[j] += f[j - a[i]];
    int ans = 0;
    for (int i = 1; i <= n; ++i)
        if (f[a[i]] == 1)
            ans++;
    cout << ans << endl;
}
```

## 多重背包问题——单调队列优化

### 题解：$O(n^2)$

><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230617212201879.png" alt="image-20230617212201879" style="zoom:50%;" />
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230617212229592.png" alt="image-20230617212229592" style="zoom:50%;" />
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230617212246328.png" alt="image-20230617212246328" style="zoom:50%;" />
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230617212312959.png" alt="image-20230617212312959" style="zoom:50%;" />

```cpp
const int N = 1e3 + 10, M = 2e4 + 10;

int n, m;
int f[2][M];
int v[N], w[N], s[N];
int q[M], hh, tt;

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> v[i] >> w[i] >> s[i];
    for (int i = 1; i <= n; ++i)
    {
        for (int r = 0; r < v[i]; ++r)
        {
            hh = 0, tt = -1;
            for (int j = r; j <= m; j += v[i])
            {
                while (hh <= tt && j - s[i] * v[i] > q[hh])
                    hh++;
                while (hh <= tt && f[i & 1 ^ 1][q[tt]] + (j - q[tt]) / v[i] * w[i] < f[i & 1 ^ 1][j])
                    tt--;
                q[++tt] = j;
                f[i & 1][j] = f[i & 1 ^ 1][q[hh]] + (j - q[hh]) / v[i] * w[i];
            }
        }
    }
    cout << f[n & 1][m] << endl;
}
```

## [NOIP2006 提高组] 金明的预算方案

>金明今天很开心，家里购置的新房就要领钥匙了，新房里有一间金明自己专用的很宽敞的房间。更让他高兴的是，妈妈昨天对他说：“你的房间需要购买哪些物品，怎么布置，你说了算，只要不超过 $n$ 元钱就行”。今天一早，金明就开始做预算了，他把想买的物品分为两类：主件与附件，附件是从属于某个主件的，下表就是一些主件与附件的例子：
>
>|  主件  |      附件      |
>| :----: | :------------: |
>|  电脑  | 打印机，扫描仪 |
>|  书柜  |      图书      |
>|  书桌  |   台灯，文具   |
>| 工作椅 |       无       |
>
>如果要买归类为附件的物品，必须先买该附件所属的主件。每个主件可以有 $0$ 个、$1$ 个或 $2$ 个附件。每个附件对应一个主件，附件不再有从属于自己的附件。金明想买的东西很多，肯定会超过妈妈限定的 $n$ 元。于是，他把每件物品规定了一个重要度，分为 $5$ 等：用整数 $1 \sim 5$ 表示，第 $5$ 等最重要。他还从因特网上查到了每件物品的价格（都是 $10$ 元的整数倍）。他希望在不超过 $n$ 元的前提下，使每件物品的价格与重要度的乘积的总和最大。
>
>设第 $j$ 件物品的价格为 $v_j$，重要度为$w_j$，共选中了 $k$ 件物品，编号依次为 $j_1,j_2,\dots,j_k$，则所求的总和为：
>
>$v_{j_1} \times w_{j_1}+v_{j_2} \times w_{j_2}+ \dots +v_{j_k} \times w_{j_k}$。
>
>请你帮助金明设计一个满足要求的购物单。

### 题解：有依赖的背包问题——利用分组背包求解

>* 因为每个主件的附件比较少，且附件没有附件，所以我们不妨将选择一个主件和其某些附件当成某组的一个方案，利用分组背包求解即可
>* 状态表示：$f[i][j]$代表只在前$i$个组中选择决策，使得选出的物品的价格不超过$j$的最大价值
>* 状态属性：$MAX$
>* 状态转移：
>  显然我们不能按照分配给附件多少体积来划分，因为体积太大了，$N*V*V$显然会超时，但是我们发现每个主件最多只有2个附件，那么如果我们将每个主件及其附件看成一个物品组的话，最多只有4种情况，所以我们可以利用二进制枚举这四种组合，那么一个物品组中最多只会有4个物品，时间复杂度为$O(4*N*V)$

```cpp
const int N = 60 + 10, M = 4e4 + 10;

int n, m;
int f[M];
int idx;
int V[N], W[N];
vector<pii> g[N];

void solve()
{
    cin >> m >> n;
    for (int i = 1; i <= n; ++i)
    {
        int a, b, c;
        cin >> a >> b >> c;
        if (c == 0)
            V[i] = a, W[i] = b;
        else
            g[c].push_back({a, b});
    }
    for (int i = 1; i <= n; ++i) // 遍历物品组
    {
        if (!V[i]) // 如果不是主件直接continue，因为有了主件才有物品组
            continue;
        for (int j = m; j >= 0; j--) // 枚举体积
        {
            for (int k = 0; k < (1 << g[i].size()); ++k) // 枚举物品组中的物品（决策）
            {
                int v = V[i], w = V[i] * W[i];        // 主件必须选，因为依赖关系
                for (int q = 0; q < g[i].size(); ++q) // 二进制枚举所有组合
                {
                    if (k >> q & 1)
                    {
                        v += g[i][q].first;
                        w += g[i][q].first * g[i][q].second;
                    }
                }
                if (j - v >= 0)
                    f[j] = max(f[j], f[j - v] + w);
            }
        }
    }
    cout << f[m] << endl;
}
```

## 有依赖的背包问题

>![image-20230618001917697](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230618001917697.png)

### 题解：树上背包 $O(n\times v^2)$

>* 状态表示：$f[u][i][j]$代表只从以$u$为根的前$i$个子树中选，且选出的物品体积不超过$j$的最大价值
>
>* 状态属性：$MAX$
>
>* 状态计算：$O(v ^ 2)$
>  首先因为从$u$的子树中选，由于依赖关系，$u$必须选，所以剩余的可用体积为$j-v[u]$，所以我们**按照每个子树用了多少体积来划分**；
>   我们可以将每个子树$v$看成一个物品组，每一个物品（决策）就是分配$k$个体积给该子树，那么每个物品的体积为$k$，价值为$f[v][v_{son}][k],v_{son}$是节点$v$的子节点个数
> $$
>  f[u][i][j] = max(f[u][i][j],f[u][i-1][j-k] + f[v][v_{son}][k])
> $$
>
>* 状态优化：我们发现状态只和上一层状态有关，我们优化掉第二维，倒序遍历体积
>  $f[u][j] = max(f[u][j],f[u][j-k] + f[v][k])$
>
>* 状态初始：
>  $f[u][j] = f[u][j - v[u]] + w[u]; j > v[u]$
>   $f[u][j] = 0,j < v[u]$

```cpp
const int N = 1e2 + 10, M = 4e5 + 10;

int n, m;
int f[N][N];
int v[N], w[N];
vector<int> g[N];

void dfs(int u, int par)
{
    for (auto V : g[u]) // 遍历物品组，即遍历子节点
    {
        if (V == par)
            continue;
        dfs(V, u);
        for (int j = m - v[u]; j >= 0; j--) // 遍历预留好u后的体积
            for (int k = 0; k <= j; ++k)    // 遍历决策
                f[u][j] = max(f[u][j], f[u][j - k] + f[V][k]);
    }
    for (int j = m; j >= v[u]; j--) // 将预留好的u放入
        f[u][j] = f[u][j - v[u]] + w[u];
    for (int j = 0; j < v[u]; ++j) // 清空无法选u的所有状态
        f[u][j] = 0;
}

void solve()
{
    int rt = 1;
    cin >> n >> m;
    for (int i = 1, u; i <= n; ++i)
    {
        cin >> v[i] >> w[i] >> u;
        if (u == -1)
        {
            rt = i;
            continue;
        }
        g[u].push_back(i);
        g[i].push_back(u);
    }
    dfs(rt, -1);
    cout << f[rt][m] << endl;
}
```

## 背包问题求最优解方案数

>![image-20230618124142473](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230618124142473.png)

### 题解：

>* 我们不妨在状态转移的时候进行计数$dp$
>* 状态表示：$g[i][j]$代表只从前$i$个物品中选，且选出的物品的总体积恰好为$j$的最大价值的方案数
>* 状态属性：数量
>* 状态转移：
>  1. $f[i-1][j] > f[i-1][j-v_i]+w_i$，$g[i][j] += g[i-1][j]$
>  2. $f[i-1][j] < f[i-1][j-v_i]+w_i$，$g[i][j] += g[i-1][j-v_i]$
>  3. $f[i-1][j] = f[i-1][j-v_i]+w_i$，$g[i][j] += g[i-1][j-v_i] + g[i-1][j]$
>* 状态初始：$g[0][0] =1$
>* 答案呈现：$\sum g[n][i]\ \ 且 \ \ f[n][i] = f[n][m]$

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n, m;
int f[N][N];
int g[N][N];
int v[N], w[N];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> v[i] >> w[i];
    g[0][0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 0; j <= m; ++j)
        {
            if (j - v[i] < 0)
            {
                f[i][j] = f[i - 1][j];
                g[i][j] = (g[i][j] + g[i - 1][j]) % mod;
            }
            else
            {
                if (f[i - 1][j] > f[i - 1][j - v[i]] + w[i])
                {
                    f[i][j] = f[i - 1][j];
                    g[i][j] = (g[i][j] + g[i - 1][j]) % mod;
                }
                else if (f[i - 1][j] < f[i - 1][j - v[i]] + w[i])
                {
                    f[i][j] = f[i - 1][j - v[i]] + w[i];
                    g[i][j] = (g[i][j] + g[i - 1][j - v[i]]) % mod;
                }
                else
                {
                    f[i][j] = f[i - 1][j];
                    g[i][j] = (g[i][j] + g[i - 1][j] + g[i - 1][j - v[i]]) % mod;
                }
            }
        }
    }
    int ans = 0;
    for (int i = 0; i <= m; ++i)
    {
        if (f[n][i] == f[n][m])
            ans = (ans + g[n][i]) % mod;
    }
    cout << ans << endl;
}
```

## 背包问题求字典序最小的具体方案

>![image-20230618131357914](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230618131357914.png)

### 题解：

>* 我们求字典序最小的方案需要从前往后递推，但是一般我们$dp$输出方案的时候都是从后往前根据转移找的
>* 所以在本题我们需要先从后往前$dp$，也就是说我们倒序遍历物品的顺序，这样的话我们就可以从第一个物品开始正序求字典序最小的方案
>* 观察倒序遍历物品后的01背包的状态转移方程：
>  $f[i][j] = max(f[i+1][j],f[i+1][j-v[i]] + w[i])$
>* 我们贪心的思考，如果我们能选第$i$个物品，那我们一定要选，因为这样字典序一定是最小的
>  如果我们不能选第$i$个物品 ，那么我们就不选

```cpp
const int N = 1e3 + 10, M = 4e5 + 10;

int n, m;
int f[N][N];
int v[N], w[N];

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> v[i] >> w[i];
    for (int i = n; i >= 1; --i)
        for (int j = 0; j <= m; ++j)
            if (j - v[i] < 0)
                f[i][j] = f[i + 1][j];
            else
                f[i][j] = max(f[i + 1][j], f[i + 1][j - v[i]] + w[i]);
    vector<int> ans;
    int pre = f[1][m];
    int j = m;
    for (int i = 1; i <= n; ++i)
    {
        if (j - v[i] >= 0 && pre == f[i + 1][j - v[i]] + w[i])
        {
            pre = f[i + 1][j - v[i]];
            j = j - v[i];
            ans.push_back(i);
        }
        else
            pre = f[i + 1][j];
    }
    for (auto it : ans)
        cout << it << " ";
    cout << endl;
}
```



# 状态机模型

>状态机代表一系列有序的事件，我们通过状态机能够将一个复杂的状态**拓展**为几个简单过程
>
>状态机是一种另类的状态表示方式，实际上是我们将每一个状态拓展成一个过程
>
>任何一个方案都能唯一对应一个状态机
>
>简单的说，我们可以通过状态机将一个复杂、混沌的状态**细分**成几个清晰的状态
>
>状态机在任意时刻的状态大多为`0`或`1`
>
>状态机需要考虑**入口**和**出口**

## 大盗阿福

>阿福是一名经验丰富的大盗。趁着月黑风高，阿福打算今晚洗劫一条街上的店铺。
>
>这条街上一共有 $n$ 家店铺，每家店中都有一些现金。
>
>阿福事先调查得知，只有当他同时洗劫了两家相邻的店铺时，街上的报警系统才会启动，然后警察就会蜂拥而至。
>
>作为一向谨慎作案的大盗，阿福不愿意冒着被警察追捕的风险行窃。
>
>他想知道，在不惊动警察的情况下，他今晚最多可以得到多少现金？
>
>$1≤T≤50,$
>$1≤n≤10^5$

### 题解：线性DP——状态机模型

>* 第一种非线性$dp$：
>
> * 状态表示：$f[i]$代表只从前$i$个店铺中偷窃，能够获得的最大价值
>
> * 状态属性：$MAX$
>
> * 状态计算：
>
>   1. 选择不偷窃第$i$个店铺：$f[i-1]$
>   2. 选择偷窃第$i$个店铺，那我们一定无法偷窃第$i-1$个店铺：$f[i-2] + w[i]$
>
>   $$
>   f[i] = max(f[i-1],f[i-2] + w[i])
>   $$
>
> * 状态初始：$f[0] = 0,f[1] = w[1]$
>
> * 答案呈现：$f[n]$
>
>
>
>* 第二种线性$dp$（状态机模型）：
>
> * 状态表示：
>
>   $f[i][0/1]$代表只从前$i$个店铺中选，且$0$代表选择第$i$家店铺，$1$代表不选第$i$家店铺所能获得的最大价值
>
> * 状态属性： $MAX$
>
> * 状态计算：按照路径来划分集合，若选择某店铺，将其状态表示为$1$，若不选某个店铺，将其状态表示为$0$
>
>   <img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230517002639953.png" alt="image-20230517002639953" style="zoom: 33%;" />
>
>   1. 选择第$i$个店铺，那么我们肯定不选择第$i-1$家店铺，即只有一条边从状态$0$通向状态$1$，即$f[i-1][0]+w[i]$
>   2. 不选择第$i$个店铺，那么第$i-1$家店铺可以选择也可以不选择，即有两条路径可以从其他状态到状态$0$，即$max(f[i-1][0],f[i-1][1])$
>
>   $$
>   f[i][1] = f[i-1][0] + w[i] \\
>   f[i][0] = max(f[i-1][0],f[i-1][1])
>   $$
>
> * 状态初始：$f[1][0] = 0,f[1][1] = w[1]$
>
> * 状态机入口：$1$，状态机出口：$0$ 或 $1$
>
> * 答案呈现：$max(f[n][0],f[n][1])$

```cpp
//第一种dp
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int f[N];
int w[N];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> w[i];
    for (int i = 0; i <= n; ++i)
        f[i] = 0;
    f[0] = 0;
    f[1] = w[1];
    for (int i = 2; i <= n; ++i)
        f[i] = max(f[i - 1], f[i - 2] + w[i]);
    cout << f[n] << endl;
}
```

```cpp
//第二种dp
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int w[N];
int f[N][2];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> w[i], f[i][1] = f[i][0] = 0;
    for (int i = 1; i <= n; ++i)
    {
        f[i][1] = max(f[i][1], f[i - 1][0] + w[i]);
        f[i][0] = max(f[i - 1][1], f[i - 1][0]);
    }
    cout << max(f[n][0], f[n][1]) << endl;
}
```



## 股票买卖 IV

>给定一个长度为 $n$ 的数组，数组中的第 $i$ 个数字表示一个给定股票在第 $i$ 天的价格。
>
>设计一个算法来计算你所能获取的最大利润，你最多可以完成 $k$ 笔交易。
>
>注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
>
>一次买入卖出合为一笔交易
>
>$1≤n≤10^5$
>
>$1≤k≤100$

### 题解：线性$dp$——状态机模型 $O(nk)$

>* 状态表示
>
>  $f[i][j][0/1]$代表只在前$i$天中选择,且已经完成$j$笔交易，且$1$代表在第$i$天手中有股票，$0$代表第$i$天手中没有股票的最大收益
>
>* 状态属性：$MAX$
>
>* 状态计算：
>
>  <img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230522210348655.png" alt="image-20230522210348655" style="zoom:50%;" />
>
>  1. 如果第$i$天手中有股票:$f[i][j][1] = max(f[i-1][j][1],f[i-1][j][0] - w[i])$
>  2. 如果第$i$天手中无股票:$f[i][j][0] = max(f[i-1][j][0],f[i-1][j-1][1] + w[i])$
>
>* 状态优化：
>
>  因为是线性的，所以容易发现第一维可以优化掉，倒序遍历交易数量（第二维）
>
>* 状态初始：$f[i][0][0] = 0 / f[0][0] = 0$
>
>* 答案呈现：$max\sum (f[n][j][0],f[n][j][1])$

```cpp
const int N = 2e5 + 10, M = 1e2 + 10;

int n, m;
int w[N];
int f[M][2];
// f[i][j][0/1]代表只在前i天中选择,且已经完成j笔交易，且1代表在第i天手中有股票，0代表第i天手中没有股票的最大收益

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> w[i];
    memset(f, -0x3f, sizeof f);
    f[0][0] = 0;
    for (int i = 1; i <= n; ++i)
        for (int j = m; j >= 0; --j)
        {
            f[j][1] = max(f[j][1], f[j][0] - w[i]);
            if (j >= 1)
                f[j][0] = max(f[j][0], f[j - 1][1] + w[i]);
        }
    int ans = -INF;
    for (int j = 0; j <= m; ++j)
        ans = max({ans, f[j][0], f[j][1]});
    cout << ans << endl;
}
```



## 股票买卖Ⅴ

>给定一个长度为 $n$ 的数组，数组中的第 $i$ 个数字表示一个给定股票在第 $i$ 天的价格。
>
>设计一个算法计算出最大利润。在满足以下约束条件下，你可以尽可能地完成更多的交易（多次买卖一支股票）:
>
>- 你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
>- 卖出股票后，你无法在第二天买入股票 (即**冷冻期**为 $1$ 天)。
>
>$1 \leq n \leq 10^5$

### 题解：线性$dp$——状态机模型

>* 状态表示：
>
>  $f[i][0/1/2]$:代表只在前$i$天中选，且$0$代表第$i$天手中有股票，1代表第$i$天是卖出股票后的第一天，2代表第$i$天卖出股票后的第$k$天（$k>=2$）能够获得的最大利润
>
>* 状态属性：$MAX$
>
>* 状态计算：
>
>  ![image-20230522212131316](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230522212131316.png)
>
>  $f[i][0] = max(f[i-1][0],f[i-1][2] - w[i])$
>  $f[i][1] = f[i-1][0] + w[i]$
>  $f[i][2] = max(f[i-1][1],f[i-1][2])$
>
>* 状态机出口：$1/2$
>
>* 状态机入口：$2$
>
>* 状态初始：$f[0][2] = 0,f[i][j] = -INF$
>
>* 答案呈现：$max(f[n][1],f[n][2])$

```cpp
const int N = 2e5 + 10, M = 1e2 + 10;

int n;
int w[N];
int f[N][3];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> w[i];
    for (int i = 0; i <= n; ++i)
        f[i][1] = f[i][0] = -INF;
    f[0][2] = 0;
    for (int i = 1; i <= n; ++i)
    {
        f[i][0] = max(f[i - 1][0], f[i - 1][2] - w[i]);
        f[i][1] = f[i - 1][0] + w[i];
        f[i][2] = max(f[i - 1][1], f[i - 1][2]);
    }
    cout << max(f[n][1], f[n][2]) << endl;
}
```



## [uvenile Galant](https://vjudge.net/problem/Gym-103061J)

>询问将两种给定形状拼接成一个指定长度的直角梯形的方案数。
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230524140640537.png" alt="image-20230524140640537" style="zoom:50%;" />
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230524140701188.png" alt="image-20230524140701188" style="zoom:50%;" />

### 题解：$DP$ + 简单状态机模型

>容易发现是简单$dp$，并且是状态机模型
>
>* 状态表示：
>  $f[i][0/1/2]$代表**较短**的边长度为$i$的时，$0$代表$i$右端是平的，$1$代表$i$右端尖角朝下，$2$代表$i$右端尖角朝上的方案数
>
>* 状态属性：数量
>
>* 状态转移：状态机模型如下
>
>  <img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230524141624265.png" alt="image-20230524141624265" style="zoom: 33%;" />
>
>  状态转移方程不再赘述
>
>* 状态机入口：$1 / 2$
>
>* 状态初始：$f[0][0] = 1,f[1][1] = 1,f[1][2] = 1$
>
>* 状态机出口：$2$
>
>* 答案呈现：$f[n-1][2]$

```cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 998244353;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int n;
int f[N][3];

void solve()
{
    cin >> n;
    f[0][0] = 1;
    f[1][1] = 1;
    f[1][2] = 1;
    for (int i = 1; i <= n; ++i)
    {
        f[i][0] = (f[i - 2][1] % mod + f[i - 2][2] % mod) % mod;
        f[i][1] = (f[i - 2][1] % mod + f[i - 1][0] % mod) % mod;
        f[i][2] = (f[i - 1][0] % mod + f[i - 2][2] % mod) % mod;
    }
    cout << f[n - 1][2] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
```



## 设计密码

>你现在需要设计一个密码 $S$，$S$ 需要满足：
>
>- $S$ 的长度是 $n$；
>- $S$ 只包含**小写英文字母**；
>- $S$ 不包含子串 $T$；
>
>例如：$abc$ 和 $abcde$ 是 $abcde$ 的子串，$abd$ 不是 $abcde$ 的子串。
>
>请问共有多少种不同的密码满足要求？
>
>由于答案会非常大，请输出答案模 $10^9+7$ 的余数。
>
>$1 \leq n \leq 50$

### 题解：$KMP$ + 状态机模型 $O(26n^3)$

>* 状态表示：
>
>  $f[i][j]$：代表已经生成了$i$位密码，且第$i$位密码已经匹配到子串中位置为$j$，即第$i + 1$位密码正在和子串中$j+1$位进行匹配的方案数
>
>  <img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230522223508487.png" alt="image-20230522223508487" style="zoom:50%;" />
>
>* 状态属性：数量
>
>* 状态转移：
>
>  因为字符串$S$中只存在小写字母，所以$S$的位置$i + 1$处的字符只有$26$种可能性
>
>  我们不妨枚举位置$i + 1$会出现的所有小写字母$k$
>
>  如果第$i+1$位的字母$k$不等于$T[j + 1]$，我们总可以利用$KMP$的$next$数组找到一个位置$u$使得$k=T[u+1]$
>
>  我们令$u:=u + 1$，字符串$T$的长度为$m$，因为$S$中不能含有$T$，所以只有$u < m$的时候才能转移
>
>  状态转移方程：$f[i+1][u] = (f[i+1][u] + f[i][j])\ \  \% \ \ mod \  \wedge(u < m)$
>
>  时间复杂度：$O(26n)$
>
>* 状态初始：$f[0][0] = 1$
>
>* 答案呈现：$\sum f[n][i]$

```cpp
const int N = 50 + 10, M = 4e5 + 10;

int n;
int ne[N];
int f[N][N];

void solve()
{
    cin >> n;
    string t;
    cin >> t;
    int m = t.length();
    t = " " + t;
    ne[1] = 0;
    for (int i = 2, j = 0; i <= m; ++i)
    {
        while (j && t[i] != t[j + 1])
            j = ne[j];
        if (t[i] == t[j + 1])
            j++;
        ne[i] = j;
    }
    f[0][0] = 1;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            for (char k = 'a'; k <= 'z'; ++k)
            {
                int u = j;
                while (u && t[u + 1] != k)
                    u = ne[u];
                if (t[u + 1] == k)
                    u++;
                if (u < m)
                    f[i + 1][u] = (f[i + 1][u] + f[i][j]) % mod;
            }
    int ans = 0;
    for (int j = 0; j < m; ++j)
        ans = (ans + f[n][j]) % mod;
    cout << ans << endl;
}
```



# 树形DP

## 选课

>在大学里每个学生，为了达到一定的学分，必须从很多课程里选择一些课程来学习，在课程里有些课程必须在某些课程之前学习，如高等数学总是在其它课程之前学习。现在有 $N$ 门功课，每门课有个学分，每门课有一门或没有直接先修课（若课程 a 是课程 b 的先修课即只有学完了课程 a，才能学习课程 b）。一个学生要从这些课程里选择 $M$ 门课程学习，问他能获得的最大学分是多少？

### 题解：树上背包—有依赖的背包问题

>* 状态表示：$f[u][i][j]$代表从以`u`为根的前`i`个子树中选，使得选出的功课数量不超过`j`能够产生的最大学分
>* 状态属性： $MAX$
>* 状态转移：按照分配给子树多少门课进行划分
>* 具体分析看背包模型中的有依赖的背包问题

```cpp
const int N = 3e2 + 10, M = 4e5 + 10;

int n, m;
int w[N];
int f[N][N];
vector<int> g[N];

void dfs(int u, int par)
{
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        for (int j = m - 1; j >= 0; j--)
            for (int k = 0; k <= j; k++)
                f[u][j] = max(f[u][j], f[u][j - k] + f[v][k]);
    }
    for (int j = m; j >= 1; j--)
        f[u][j] = f[u][j - 1] + w[u];
    f[u][0] = 0;
}

void solve()
{
    cin >> n >> m;
    for (int i = 1, u; i <= n; ++i)
    {
        cin >> u >> w[i];
        g[u].push_back(i);
        g[i].push_back(u);
    }
    m++;
    dfs(0, -1);
    cout << f[0][m] << endl;
}
```

## 皇宫看守

>![](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230625172216725.png)

### 题解:树形DP + 状态机模型

>* 容易发现一个节点存在2种情况
>
>  1. 如果当前节点上放置守卫，那么子节点可放可不放
>  2. 如果当前节点上不放置守卫，那么至少选择一个子节点放置守卫或者选择在其父节点放置守卫
>
>* 所以我们不妨将每个节点的状态分成3种
>
>  1. 被自己观察：$f[u][0]$
>  2. 被子节点观察：$f[u][1]$
>  3. 被父节点观察：$f[u][2]$
>
>* 状态表示：$f[u][0/1/2]$代表看守以$u$为根的子树中的所有宫殿，且$u$被自己/子节点/父节点观察的最小花费
>
>* 状态属性：$MIN$
>
>* 状态转移：
>
>  1. 当前节点$u$被自己观察，说明子节点$v$的状态既可以是被自己观察，也可以是被父节点观察，同样也可以被子节点观察
>     $$
>     f[u][0] += min({f[v][0], f[v][1], f[v][2]})
>     $$
>
>  2. 当前节点被子节点观察，说明当前节点$u$一定没有守卫，那么子节点$v$的状态要么是被自己观察，要么是被$v$的子节点观察，如果说我们贪心的发现**所有的子节点的状态都是被子节点观察**，那么我们需要加上**一个$f[v][0]-f[v][1]$的最小差值来保证至少有一个子节点放置了守卫**
>
>  3. 当前节点被父节点观察，说明当前节点$u$一定没有守卫，那么子节点$v$的状态要么是被自己观察，要么是被$v$的子节点观察
>     $$
>     f[u][2] += min(f[v][0], f[v][1])
>     $$
>
>* 状态初始：
> $$
>  f[u][0] = w[u]\\
>  f[u][1] = 0\\
>  f[u][2] = 0
> $$
>
>* 答案呈现：由于根节点不可能存在被父节点观察的情况，所以答案一定为$min(f[rt][0], f[rt][1])$
>* 注意只有一个节点（$n = 1$）时候的情况

```cpp
const int N = 2e3 + 10, M = 4e5 + 10;

int n;
vector<int> g[N];
int f[N][3];
int w[N];

void dfs(int u, int par)
{
    f[u][0] = w[u];
    f[u][1] = 0;
    f[u][2] = 0;
    int mi = u;
    bool flag = false;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        f[u][0] += min({f[v][0], f[v][1], f[v][2]});
        f[u][2] += min(f[v][0], f[v][1]);
        if (f[v][0] <= f[v][1])
        {
            f[u][1] += f[v][0];
            flag = true;
        }
        else
        {
            f[u][1] += f[v][1];
            if (mi == u)
                mi = v;
            else
            {
                if (f[v][0] - f[v][1] < f[mi][0] - f[mi][1])
                    mi = v;
            }
        }
    }
    if (!flag)
    {
        f[u][1] -= f[mi][1];
        f[u][1] += f[mi][0];
    }
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        int u;
        cin >> u;
        cin >> w[u];
        int k;
        cin >> k;
        for (int j = 1; j <= k; ++j)
        {
            int v;
            cin >> v;
            g[u].push_back(v);
            g[v].push_back(u);
        }
    }
    dfs(1, 0);
    cout << min(f[1][0], f[1][1]) << endl;
}
```



