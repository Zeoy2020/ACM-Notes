# 状压 DP

>枚举二进制状态
>
>```cpp
>for (int i = 1; i < (1 << n); ++i) {}
>```

>* 得到$x$二进制最后一位$1$
>
>  * $$
>    x\ \  \&\ \  -x
>    $$
>
>* 统计$x$二进制下$1$的个数
>
>  * 我们不妨一直去掉最后一个$1$：$n \ \ \ \&= n-1$
>
>  * ```cpp
>    int bit_count(int n)
>    {
>        int cnt =0;
>        while (n)
>        {
>            cnt++;
>            n &= (n - 1);
>        }
>    }
>    ```
>
>  * 或者我们可以直接利用库函数
>
>  * ```cpp
>    __builtin_popcountll()
>    ```

## 光玉小镇

>![image-20230713134257749](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230713134257749.png)
>
>![image-20230713134326443](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230713134326443.png)

### 题解：最短路 + 状压DP

>* 由于$1 \leq t \leq 15$，我们考虑状压DP
>
>* 设计状态$f[i][j]$为当前所有电线杆的状态为$(i)_2$，且当前位于第$j$个电线杠所用的最短时间
>
>* 考虑状态转移过程，类似**旅行商**问题：
>
> * ```cpp
>   枚举所有状态
>   	枚举当前位于哪个电线杆
>   		枚举从哪个电线杆过来的
>   			判断是否合法
>   				进行状态转移
>   ```
>
> * $$
>   f[i][u] = min(f[i][u],f[i - (1 << u)][v] + dis[v][u] + t)\\
>   (i << u\ \  \& \ \ 1=1 \ \and \ i << v\ \  \& \ \ 1=1)
>   $$
>
>* 对于$dis[v][u]$，我们先对所有电线杆以及起点的编号后进行至多$15$遍$BFS$即可，复杂度为$O(15\times nm)$
>
>* 最后统计答案的时候不要忘记要回到起点的时间，枚举所有终点取$min$即可
>
>* 注意$t \leq 10^9$，所以初始化的时候需要初始化成$INF\_64$

```cpp
const int N = 2e2 + 10, M = 4e5 + 10;

int n, m, t;
char g[N][N];
int f[1 << 17][17];
int dis[N][N];
map<int, pii> mp;
int idx = 0;
int dir[4][2] = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

void bfs(int id, int sx, int sy)
{
    vector<vector<int>> d(n + 10, vector<int>(m + 10, INF));
    vector<vector<int>> vis(n + 10, vector<int>(m + 10));
    d[sx][sy] = 0;
    vis[sx][sy] = 1;
    queue<pii> q;
    q.push({sx, sy});
    while (q.size())
    {
        int x = q.front().first, y = q.front().second;
        q.pop();
        for (int i = 0; i < 4; ++i)
        {
            int nx = x + dir[i][0];
            int ny = y + dir[i][1];
            if (nx >= 1 && nx <= n && ny >= 1 && ny <= m && !vis[nx][ny] && g[nx][ny] != '#')
            {
                vis[nx][ny] = 1;
                d[nx][ny] = d[x][y] + 1;
                q.push({nx, ny});
            }
        }
    }
    for (int i = 0; i <= idx; ++i)
    {
        int x = mp[i].first;
        int y = mp[i].second;
        dis[id][i] = d[x][y];
    }
}

void solve()
{
    cin >> n >> m >> t;
    int sx, sy;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
        {
            cin >> g[i][j];
            if (g[i][j] == 'S')
            {
                mp[0] = {i, j};
            }
            else if (g[i][j] == 'T')
                mp[++idx] = {i, j};
        }
    for (int i = 0; i <= idx; ++i)
        bfs(i, mp[i].first, mp[i].second);

    for (int i = 0; i < 1 << idx + 1; ++i)
        for (int j = 0; j <= idx; ++j)
            f[i][j] = INF;
    f[1][0] = 0;
    for (int i = 0; i < (1 << idx + 1); ++i)
    {
        for (int j = 0; j <= idx; ++j)
        {
            int u = j;
            if (i >> u & 1)
            {
                for (int k = 0; k <= idx; ++k)
                {
                    int v = k;
                    if (u == v)
                        continue;
                    if (i >> v & 1)
                    {
                        f[i][u] = min(f[i][u], f[i ^ (1 << u)][v] + dis[v][u] + t);
                    }
                }
            }
        }
    }
    int ans = INF;
    for (int i = 1; i <= idx; ++i)
    {
        ans = min(ans, f[(1 << idx + 1) - 1][i] + dis[i][0]);
    }
    if (ans == INF)
        cout << -1 << endl;
    else
        cout << ans << endl;
}
```

## ABC343 **G - Compress Strings**

>![image-20240303004058216](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240303004058216.png)
>
>$1 \leq N \leq 20,\sum S_i \leq 2e5$

### 题解：KMP + 状压 DP

>观察数据范围后考虑状压
>
>类似旅行商问题，定义 $dp[i][j]$ 代表当前包含字符串状态为 $i$，且当前（最后）拼接进的字符串为 $S_j$
>
>显然的转移：
>$$
>dp[i][j] = \max(dp[i][j], dp[i\oplus2^j][k] + cost[k][j]),状态\ i\ 包含 \ j\ ,k\ 
>$$
>那么 $cost[i][j]$ 为将字符串 $S_j$ 拼接到 $S_i$ 后面的最小代价，显然为 $S_j + S_i$ 的最长公共前后缀，KMP 处理可得到
>
>但是这道题还存在坑：可能存在 $S_j$ 本来已经是 $S_i$ 的子串了，所以此时转移的代价为 $0$，所以我们不妨先将已经成为别的串子串的 $S_j$ 全部去重掉，可以考虑按照长度排序后，通过 KMP 判断该串是否为其他串的子串

```cpp
vector<int> kmp(string s) {
    int n = SZ(s);
    vector<int> nxt(n + 1);
    for (int i = 1, j = 0; i < n; ++i) {
        while (j && s[i] != s[j]) j = nxt[j];
        j += (s[i] == s[j]);
        nxt[i + 1] = j;
    }
    return nxt;
}

void solve() {
    int n; cin >> n;
    vector<string> S(n);
    for (int i = 0; i < n; ++i) cin >> S[i];

    /* 去重，即去除已经是其他串子串的串 */
    sort(all(S), [&](auto a, auto b){
        return SZ(a) < SZ(b);
    });
    vector<string> tmp;
    for (int i = 0; i < n; ++i) {
        bool ok = true;
        for (int j = i + 1; j < n; ++j) {
            auto nxt = kmp(S[i] + '#' + S[j]);
            for (auto len : nxt) {
                if (len == SZ(S[i])) {
                    ok = false;
                    break;
                }
            }
        }
        if (ok) tmp.push_back(S[i]);
    }
    S = tmp;

    n = SZ(S);
    vector<vector<int>> cost(n + 1, vector<int>(n + 1));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cost[i][j] = SZ(S[j]) - kmp(S[j] + '#' + S[i]).back();
        }
    }
    vector<vector<int>> dp(1ll << n, vector<int>(n + 1, inf));
    for (int i = 0; i < n; ++i) dp[1ll << i][i] = SZ(S[i]);
    for (int i = 0; i < (1ll << n); ++i) {
        for (int j = 0; j < n; ++j) {
            if (~i >> j & 1) continue;
            for (int k = 0; k < n; ++k) {
                if (~i >> k & 1) continue;
                dp[i][j] = min(dp[i][j], dp[i ^ (1ll << j)][k] + cost[k][j]);
            }
        }
    }
    int ans = inf;
    for (int i = 0; i < n; ++i) ans = min(ans, dp[(1ll << n) - 1][i]);
    cout << ans << endl;
}
```

## F. 小红的矩阵修改

>![image-20240213185929714](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240213185929714.png)

### 题解：状态 DP

>* 考虑到只有 $3$ 种字符，且最多只有 $4$ 行，每列的状态数最多不超过 $3^4$ 种，考虑状态 dp
>* 定义 $dp[i][j]$ 代表前 $i - 1$ 列已经合法，且当前第 $i$ 列的状态为 $j$（$3$ 进制）的情况下的最小操作次数
>* 考虑转移，显然除了第一列外，每一列都会从上一列的所有合法状态转移过来，所以转移也是 $3^4$ 的
>* $dp[i][j] = \min_{k = 0}^{3^n - 1}(dp[i][j], dp[i - 1][k] + cost),i > 1$，注意必须保证 $j$ 和 $k$ 之间没有冲突，$cost = \sum_{k = 0}^n (bit[k] \neq a[k][i])$ 
>* 时间复杂度为状态数乘上转移的复杂度：$O(m3^n \times 3^n) = O(m·9^n)$

## E. Sasha and the Happy Tree Cutting

>![image-20240218163118943](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240218163118943.png)

### 题解：状压 DP + 虚树思想

>关键路径数量 $k \leq 20$ 提醒我们状压
>
>我们对于每条边 $i$ 求出有哪些关键路径经过 $i$，定义其为 $S_i$
>
>定义 $dp[i][mask]$ 代表在前 $i - 1$ 条边中涂色，使得有哪些关键路径被覆盖的状态为 $mask$
>
>那么转移很简单：$dp[i + 1][mask\ | \ S_i] = \min(dp[i + 1][mask\ | \ S_i], dp[i][mask] + 1)$
>
>$dp[i + 1][mask] = min(dp[i + 1][mask], dp[i][mask])$
>但是现在复杂度为 $O(n2^k)$，但是观察后我们发现实际上只有 $O(k)$ 种 $S_i$，因为我们对 $2k$ 个关键点建虚树，虚树上的边数就是 $S_i$ 不同的边数，即 $O(k)$
>
>所以我们直接 $O(nk)$ 处理 $S_i$ ，然后排序后去重
>
>然后 $O(k2^k)$ 状压即可
>
>注意滚动优化空间

## CF1950 G. Shuffling Songs

>![image-20240330000431846](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240330000431846.png)
>
>$1 \leq n \leq 16$

### 题解：状压 DP 解决哈密顿通路问题

>考虑将两两可以相邻的歌曲之间建无向边，然后题目就转化为：给定一个无向图，求最少删掉几个点能够使得该图存在哈密顿通路
>
>考虑状压 DP，定义 $dp[mask][i]$ 代表当前存在一条哈密顿通路，通路中存在点的状态为 $mask$，且该通路以 $i$ 结尾的可能性
>
>然后类似旅行商转移即可：$dp[mask][i] \ |=dp[mask \oplus2^i][j], mask \&j=1$ 且 $i$ 和 $j$ 之间有边相连
>
>然后直接 $O(n2^n)$ 遍历所有状态，对答案取 $min$ 即可

## CF1955 H. The Most Reckless Defense

>![image-20240410104750634](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240410104750634.png)
>
> ($1 \le x_i \le n, 1 \le y_i \le m, 1 \le p_i \le 500$)

### 题解

>对于敌人初始血量的最大值，我们可以转化为防御塔能够造成的最大伤害，即对于每个防御塔来说，有多少个敌人的方格能被攻击到
>
>我们发现，防御塔最多能够攻击到 $n + m - 1$ 个敌人方格，并且最大单次伤害为 $500$，我们发现当 $r \geq 10$ 的时候，答案已经不优了
>
>所以我们只考虑 $r \leq 10 $，考虑状压 DP
>
>定义 $dp[i][j]$ 代表只考虑前 $i$ 个防御塔，其中防御塔选定半径的状态为 $j$ 能够造成的最大伤害
>
>考虑转移：
>
>不选 $i$：$dp[i][j] = dp[i - 1][j]$
>
>如果给 $i$ 选择半径 $r$，枚举选定的半径 $r$：$dp[i][j] = \max(dp[i][j], dp[i - 1][j \oplus 2^r] + cnt[r] \times p[i] - 3^r)$
>
>其中 $cnt[r]$ 代表第 $i$ 个防御塔攻击范围为 $r$ 能够攻击到多少个敌人方格 
