# 数位 DP

>![image-20240206155603420](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240206155603420.png)

## P2657 [SCOI2009] windy 数

>![image-20240206161820420](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240206161820420.png)
>
>$1 \leq a, b \leq 2e9$

```cpp
int num[N], dp[12][12][2][2];
/* 
	pos：当前枚举到的数位
	lst：上一位数字
	lead：当前位前面是否全为 0
	limit：最高位是否有限制
*/
int dfs(int pos, int lst, bool lead, bool limit) {
	/* 如果搜完了，代表当前枚举的数字一定符合题意，对答案的贡献为 1 */
	if (pos == 0) return 1;
	if (dp[pos][lst][lead][limit] != -1) return dp[pos][lst][lead][limit];
	int res = 0;
	/* 如果最高位有限制，只能取 [0, num[pos]], 否则可以取 [0, 9] */
	int up = (limit ? num[pos] : 9);
	for (int i = 0; i <= up; ++i) {
		/* 相邻位之差小于 2，不符合题意 */
		if (abs(i - lst) < 2) continue;
		/* 如果下一位的前面全是 0，下一位可以忽略相邻位之差小于 2 的限制，所以直接赋值 -2 */
		if (i == 0 && lead) res += dfs(pos - 1, -2, true, limit && i == up);
		else res += dfs(pos - 1, i, false, limit && i == up);
	}
	return dp[pos][lst][lead][limit] = res;
}

int calc(int x) {
	memset(dp, -1, sizeof dp);
	int len = 0;
	while (x > 0) {
		num[++len] = x % 10;
		x /= 10;
	}
	return dfs(len, -2, true, true);
}
void solve() {
	int l, r; cin >> l >> r;
	cout << calc(r) - calc(l - 1) << endl;
}
```

## P2602 [ZJOI2010] 数字计数

>![image-20240206164557418](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240206164557418.png)
>
>$1 \leq a, b \leq 10^{12}$

```cpp
int num[N], dp[15][15][2][2];
/* 
	pos：当前枚举到的数位
	sum：当前枚举的数中 digit 出现的次数
	lead：当前位前面是否全为 0
	limit：最高位是否有限制
	digit：正在统计的数码
*/
int dfs(int pos, int sum, bool lead, bool limit, int digit) {
	/* 如果搜完了，代表当前枚举的数字一定符合题意，对答案的贡献为 sum */
	if (pos == 0) return sum;
	if (dp[pos][sum][lead][limit] != -1) return dp[pos][sum][lead][limit];
	int res = 0;
	/* 如果最高位有限制，只能取 [0, num[pos]], 否则可以取 [0, 9] */
	int up = (limit ? num[pos] : 9);
	for (int i = 0; i <= up; ++i) {
		if (i == 0 && lead) res += dfs(pos - 1, 0, true, limit && i == up, digit);
		else  res += dfs(pos - 1, sum + (i == digit), false, limit && i == up, digit);
	}
	return dp[pos][sum][lead][limit] = res;
}

int calc(int x, int y) {
	memset(dp, -1, sizeof dp);
	int len = 0;
	while (x > 0) {
		num[++len] = x % 10;
		x /= 10;
	}
	return dfs(len, 0, true, true, y);
}
void solve() {
	int l, r; cin >> l >> r;
	for (int i = 0; i <= 9; ++i) cout << calc(r, i) - calc(l - 1, i) << " ";
}
```

## P4124 [CQOI2016] 手机号码

>![image-20240206164529822](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240206164529822.png)

```cpp
int num[N], dp[15][15][15][2][2][2][2];
/* 
	pos：当前枚举到的数位
	pre：当前位前面数位上的数字
	lst：pre 前面数位上的数字
	exist: 是否存在至少 3 个相邻的相同数字
	n8：是否出现 8
	n4：是否出现 4
	limit：最高位是否有限制
*/
int dfs(int pos, int pre, int lst, bool exist, bool n8, bool n4, bool limit) {
	/* 如果搜完了，如果符合题意，对答案的贡献为 1，否则为 0 */
	if (n8 && n4) return 0;
	if (pos == 0 && exist) return 1;
	else if (pos == 0) return 0;
	if (dp[pos][pre][lst][exist][n8][n4][limit] != -1) return dp[pos][pre][lst][exist][n8][n4][limit];
	int res = 0;
	/* 如果最高位有限制，只能取 [0, num[pos]], 否则可以取 [0, 9] */
	int up = (limit ? num[pos] : 9);
	for (int i = 0; i <= up; ++i) res += dfs(pos - 1, i, pre, exist || (i == pre && i == lst), n8 || (i == 8), n4 || (i == 4), limit && i == up);
	return dp[pos][pre][lst][exist][n8][n4][limit] = res;
}

int calc(int x) {
	memset(dp, -1, sizeof dp);
	int len = 0;
	while (x > 0) {
		num[++len] = x % 10;
		x /= 10;
	}
	if (len < 11) return 0;
	int ans = 0;
	/* 不允许有前导 0，所以直接枚举第一位 */
	for (int i = 1; i <= num[len]; ++i) ans += dfs(len - 1, i, -1, false, i == 8, i == 4, i == num[len]);
	return ans;
}
void solve() {
	int l, r; cin >> l >> r;
	cout << calc(r) - calc(l - 1) << " ";
}
```

