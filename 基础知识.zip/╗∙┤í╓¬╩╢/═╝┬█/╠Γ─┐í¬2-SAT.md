## E. 帮麻衣学姐分类

>麻衣学姐手上突然有了 $n$ 个**不同的数字**: $p_1,p_2,\cdots,p_n$. 她想把这些数字分成两个集合 $A$ 和 $B$。但是你必须满足下面的条件： -   如果 $x$ 在集合 $A$, 数字 $a-x$ 也必须在集合 $A$. -   如果 $x$ 在集合 $B$, 数字 $b-x$ 也必须在集合 $B$. 请你帮帮麻衣学姐，或者说明这是不可能的。
>
>$n,a,b$ $(1\leq n\leq 10^5;~1\leq a,b\leq 10^9)$
>
>$p_1,p_2,\cdots,p_n~(1\leq p_i\leq 10^9)$

### 题解：2-SAT

>* 我们定义$i$代表$a_i$在集合A，$i + n$代表$a_i$在集合B
>* 如果对于$x$来说，没有$a - x$和$b - x$存在，输出`NO`
>* 如果对于$x$来说，只有$a - x$存在，说明$x$和$a - x$一定在集合A，两者是与关系
>* 如果对于$x$来说，只有$b - x$存在，说明$x$和$b - x$一定在集合B，两者是与关系
>* 如果对于$x$来说，$a - x$和$b - x$同时存在：
> * 如果$x$在集合A，那么$a-x$和$b-x$一定也在集合A
> * 如果$x$在集合B，那么$a-x$和$b-x$一定也在集合B
>* 明确逻辑关系后之间建图后跑2-SAT即可
>* 最后对于任意一个数字，该数字一定在$scc$编号小的集合中

```cpp
const int N = 2e5 + 10, M = 4e5 + 10;

int n, a, b;
map<int, int> mp;
vector<int> g[N];
int idx, sccnt, dfn[N], low[N], scc[N];
int stk[N], top;
int p[N], ans[N];

void tarjan(int u)
{
    dfn[u] = low[u] = ++idx;
    stk[++top] = u;
    for (auto v : g[u])
    {
        if (!dfn[v])
        {
            tarjan(v);
            low[u] = min(low[u], low[v]);
        }
        else if (!scc[v])
            low[u] = min(low[u], low[v]);
    }
    if (dfn[u] == low[u])
    {
        sccnt++;
        while (stk[top] != u)
        {
            scc[stk[top]] = sccnt;
            top--;
        }
        scc[stk[top]] = sccnt;
        top--;
    }
}

void solve()
{
    cin >> n >> a >> b;
    for (int i = 1; i <= n; ++i)
    {
        cin >> p[i];
        mp[p[i]] = i;
    }
    for (int i = 1; i <= n; ++i)
    {
        if (!mp[a - p[i]] && !mp[b - p[i]])
        {
            cout << "NO" << endl;
            return;
        }
        else if (mp[a - p[i]] && !mp[b - p[i]])
        {
            g[i + n].push_back(i);
            g[mp[a - p[i]] + n].push_back(mp[a - p[i]]);
        }
        else if (!mp[a - p[i]] && mp[b - p[i]])
        {
            g[i].push_back(i + n);
            g[mp[b - p[i]]].push_back(mp[b - p[i]] + n);
        }
        else
        {
            g[i].push_back(mp[a - p[i]]);
            g[i].push_back(mp[b - p[i]]);
            g[i + n].push_back(mp[a - p[i]] + n);
            g[i + n].push_back(mp[b - p[i]] + n);
        }
    }
    for (int i = 1; i <= 2 * n; ++i)
        if (!dfn[i])
            tarjan(i);
    for (int i = 1; i <= n; ++i)
    {
        if (scc[i] == scc[i + n])
        {
            cout << "NO" << endl;
            return;
        }
        else if (scc[i] > scc[i + n])
            ans[i] = ans[mp[a - p[i]]] = 1;
        else
            ans[i] = ans[mp[b - p[i]]] = 0;
    }
    cout << "YES" << endl;
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << "\n "[i < n];
}
```

## 