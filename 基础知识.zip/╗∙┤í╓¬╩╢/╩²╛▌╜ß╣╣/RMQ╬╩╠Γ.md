# $RMQ$问题

## $ST$表

ST表用来实现***可重复贡献问题***的数据结构，什么叫做可重复贡献问题？比如***$max(x,x)=x,gcd(x,x)=x$***,所以RMQ问题和区间GCD就是一个可重复贡献问题，但是像区间和就不是了，因为会有重叠部分加到结果中，这部分结果是我们不愿意看到的，当然***操作$opt$必须具有结合律，或者说自反性***

> 给定$n$个数，有$q$个询问，对于每个询问，你需要回答区间$[l,r]$中的最大值
>
> 考虑暴力做法。每次都对区间扫描一遍，求出最大值。
>
> 显然，这个算法会超时。

ST表基于倍增思想，预处理 $O (nlogn)$, 询问 $O(1)$,但是不支持修改

我们令 $st[i][j]$ 代表区间 $[i,i+2^j-1]$ 中的最大值

显然 $st[i][0]=a[i]$ 

根据定义式，一步可以跳$2^j-1$步，我们可以知道一个区间$[i,i+2^j-1] $

可以二分为两个区间$[i,i+2^{j-1}-1]$和$[i+2^{j-1},i+2^{j}-1]$

所以一个状态可以有前一个状态推出，我们直接列出状态转移方程：
$$
st[i][j]=max(st[i][j-1],st[i+2^{j-1}][j-1])
$$
以上就是预处理部分，复杂度$O (nlogn)$

对于询问：

回答区间$[l,r]$中的最大值，因为是可重复贡献问题，所以我们只要用两个区间覆盖需要查询的区间即可，假设区间长度$len=log_2(r-l+1)$即把区间$[l,r]$分为$[l,l+2^{len}-1]$和$[r-2^{len}+1,r]$

 这两个区间一定能把$[l,r]$覆盖，保证答案的正确性，我们直接列出回答
$$
ans = max(st[l][len],st[r-(1 \ll len)+1][len])
$$

### 模板

```cpp
// [l, r]中的最值
int n, a[N];
int st[N][22], lg2[N];
void build() {
    for (int i = 1; i <= n; ++i) st[i][0] = a[i];
    for (int i = 2; i <= n; ++i) lg2[i] = lg2[i >> 1] + 1;
    for (int j = 1; j <= 20; ++j)
        for (int i = 1; i + (1ll << j) - 1 <= n; ++i)
            st[i][j] = max(st[i][j - 1], st[i + (1ll << (j - 1))][j - 1]);
}
int query(int l, int r) {
    int len = lg2[r - l + 1];
    return max(st[l][len], st[r - (1ll << len) + 1][len]);
}
```

```cpp
// [l, r]中最值的位置
int n, a[N];
int st[N][22], lg2[N];
void build() {
    for (int i = 1; i <= n; ++i) st[i][0] = i;
    for (int i = 2; i <= n; ++i) lg2[i] = lg2[i >> 1] + 1;
    for (int j = 1; j <= 20; ++j)
        for (int i = 1; i + (1ll << j) - 1 <= n; ++i)
            st[i][j] = (a[st[i][j - 1]] < a[st[i + (1ll << (j - 1))][j - 1]] ? st[i][j - 1] : st[i + (1ll << (j - 1))][j - 1]);
}
int query(int l, int r) {
    int len = lg2[r - l + 1];
    return (a[st[l][len]] < a[st[r - (1ll << len) + 1][len]] ? st[l][len] : st[r - (1ll << len) + 1][len]);
}
```

## 求所有子区间取模相同的区间

>* 取模存在一个不错的性质：$x\  \%\ p$ 要么 $x$ 不变，要么$x$至少整除 $2$
>
>* 所以我们考虑固定左端点$l$，存在 $log\ a_l$ 段区间，使得右端点$r$在每段区间 $[p,q]$ 内 $ a_l\ mod\ a_{l + 1}...mod\ a_r,r\in[p,q]$ 不变
>
>* 我们可以通过$ST$表+二分来预处理所有固定左端点和固定右端点的区间，并将所有模数相同的区间放入同一个
>
>  $vector$中，预处理复杂度 $O(nlog^2n)$

```cpp
int n, a[N], st[N][22], lg2[N];
vector<array<int, 4>> vec[N];

void build() {
    for (int i = 1; i <= n; ++i)
        st[i][0] = a[i];
    for (int i = 2; i <= n; ++i)
        lg2[i] = lg2[i >> 1] + 1;
    for (int j = 1; j <= 20; ++j)
        for (int i = 1; i + (1ll << j) - 1 <= n; ++i)
            st[i][j] = min(st[i][j - 1], st[i + (1ll << (j - 1))][j - 1]);
}
int query(int l, int r) {
    if (l > r)
        return INF;
    int len = lg2[r - l + 1];
    return min(st[l][len], st[r - (1ll << len) + 1][len]);
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i) cin >> a[i];
    build();
    for (int i = 1; i <= n; ++i) {
        int now = a[i];
        for (int j = i, l, r; j <= n; j = r + 1) {
            l = j, r = n;
            while (l <= r) {
                int mid = l + r >> 1;
                if (query(j + 1, mid) > now)
                    l = mid + 1;
                else
                    r = mid - 1;
            }
            vec[now].push_back({0, i, j, r}); // 固定区间左端点 l 为 i，则区间右端点 r 在 [j, r] 范围时，[l, r] 取模不变 
            if (r + 1 <= n)
                now %= a[r + 1];
        }
    }
    for (int i = n; i >= 1; --i) {
        int now = a[i];
        for (int j = i, l, r; j >= 1; j = l - 1) {
            l = 1, r = j;
            while (l <= r) {
                int mid = l + r >> 1;
                if (query(mid, j - 1) > now)
                    r = mid - 1;
                else
                    l = mid + 1;
            }
            vec[now].push_back({1, i, l, j}); // 固定区间右端点 r 为 i，则区间左端点 l 在 [l, j] 范围时，[l, r] 取模不变
            if (l - 1 >= 1)
                now %= a[l - 1];
        }
    }
}
```

## 求所有子区间 $gcd$ 相同的区间

```cpp
int now = a[i];
for (int j = i, l, r; j >= 1; j = l - 1) { // 固定右端点
    l = 1, r = j;
    while (l <= r) {
        int mid = l + r >> 1;
        if (st1.query(mid, i) == now)
            r = mid - 1;
        else
            l = mid + 1;
    }
    if (l - 1 >= 1)
        now = query(l - 1, i);
}
```

# 二维$RMQ$问题

## P2216 [HAOI2007] 理想的正方形

![image-20231008010241278](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231008010241278.png)

>* 我们定义$X[i][j]$为位于第$i$行的第$[j, j + n - 1]$列中的最大值，相当于一个$1 \times n$矩阵中的最大值；$x[i][j]$为位于第$i$行的第$[j, j + n - 1]$列中的最小
>
>* 那么对于$X[i][j]$和$x[i][j]$的预处理，我们对于每一行用单调队列做一个窗口大小为$n$的滑动窗口即可得到，复杂度$O(a\times b)$
>
>* 那么我们在$X[i][j]$和$x[i][j]$的基础上，定义$Y[i][j]$为在$X[][]$中第$[i, i + n - 1]$行的第$j$列中的最大值；$y[i][j]$为在$x[][]$中第$[i, i + n - 1]$行的第$j$列中的最小值
>
>* 也就是说：$Y[i][j]$代表以$(i,j)$为左上角的正方形中的最大值，$y[i][j]$代表以$(i,j)$为左上角的正方形中的最小值
>
>* 复杂度：$O(nm)$
>
>  ![image-20231008134219504](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231008134219504.png)

```cpp
int n, m, k, a[N][N], X[N][N], x[N][N], Y[N][N], y[N][N], q[N], head, tail;

void solve()
{
    cin >> n >> m >> k;
    for (int i=1;i<=n;++i) {
        for (int j=1;j<=m;++j) {
            cin >> a[i][j];
        }
    }
    // 对 row 做滑动窗口
    for (int i=1;i<=n;++i) {
        head = 0, tail = -1;
        for (int j=1;j<=m;++j) {
            if (head <= tail && q[head] < j - k + 1)
                ++head;
            while (head <= tail && a[i][q[tail]] <= a[i][j]) 
                --tail;
            q[++tail] = j;
            if (j >= k)
                X[i][j - k + 1] = a[i][q[head]];
        }   
        head = 0, tail = -1;
        for (int j=1;j<=m;++j) {
            if (head <= tail && q[head] < j - k + 1) 
                ++head;
            while (head <= tail && a[i][q[tail]] >= a[i][j]) 
                --tail;
            q[++tail] = j;
            if (j >= k) 
                x[i][j - k + 1] = a[i][q[head]];
        }
    }
    // 对 column 做滑动窗口
    for (int i=1;i<=m-k+1;++i) {
        head = 0, tail = -1;
        for (int j=1;j<=n;++j) {
            if (head <= tail && q[head] < j - k + 1)
                ++head;
            while (head <= tail && X[q[tail]][i] <= X[j][i])
                --tail;
            q[++tail] = j;
            if (j >= k) 
                Y[j - k + 1][i] = X[q[head]][i];
        }
        head = 0, tail = -1;
        for (int j=1;j<=n;++j) {
            if (head <= tail && q[head] < j - k + 1) 
                ++head;
            while (head <= tail && x[q[tail]][i] >= x[j][i]) 
                --tail;
            q[++tail] = j;
            if (j >= k) 
                y[j - k + 1][i] = x[q[head]][i];
        }
    }
    int ans = INF;
    for (int i=1;i<=n-k+1;++i) {
        for (int j=1;j<=m-k+1;++j) {
            ans = min(ans, Y[i][j] - y[i][j]);
        }
    }
    cout << ans << endl;
}
```

## 二维$ST$表

> * 我们定义$st[i][j][k][l]$为左上角坐标为$(i,j)$，右下角坐标为$(i + 2^k - 1, j + 2^l - 1)$的矩阵中的最大值
>
> * 对于该矩阵我们可以通过两种类型的矩阵转移过来
>
>   ![image-20231008144453790](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231008144453790.png)
>   $$
>   st[i][j][k][l] = max
>   \begin{equation}
>   	\left\{
>   		\begin{array}{lr}
>   		max(st[i][j][k - 1][l], st[i + 2^{k - 1}][j][k - 1][l]), k > 0 \\
>   		max(st[i][j][k][l - 1], st[i][j + 2^{l - 1}][k][l - 1]), l > 0
>   		\end{array}
>   	\right. 
>   \end{equation}
>   $$
>
> * 预处理时间复杂度：$O(nmlognlogm)$
>
> * 对于一个询问来说，设其询问左上角为$(x_1, y_1)$，右下角为$(x_2, y_2)$，那么我们可以将其转化为询问四个子矩阵的最大值
>
>   ![image-20231008145030033](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231008145030033.png)
>
>   ![image-20231008145144606](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231008145144606.png)

```cpp
int n, m, a[N][N], st[N][N][12][12], lg2[N];

void build() {
    for (int i=1;i<=n;++i) 
        for (int j=1;j<=m;++j) 
            st[i][j][0][0] = a[i][j];
    for (int i=2;i<=max(n, m);++i) 
        lg2[i] = lg2[i >> 2] + 1;
    for (int k = 0; k <= 11; ++k) {
        for (int l = 0; l <= 11; ++l) {
            if (k == 0 && l == 0 )
                continue;
            for (int i = 1; i + (1ll << k) - 1 <= n; ++i) {
                for (int j = 1; j + (1ll << l) - 1 <= m; ++j) {
                    if (k) {
                        st[i][j][k][l] = max(st[i][j][k - 1][l], st[i + (1ll << (k - 1))][j][k - 1][l]);
                    } else {
                        st[i][j][k][l] = max(st[i][j][k][l - 1], st[i][j + (1ll << (l - 1))][k][l - 1]);
                    }
                }
            }
        }
    }
}
int query(int x1, int y1, int x2, int y2) {
    int len1 = lg2[x2 - x2 + 1], len2 = lg2[y2 - y1 + 1];
    return max({st[x1][y1][len1][len2], 
                st[x2 - (1ll << len1) + 1][y1][len1][len2], 
                st[x1][y2 - (1ll << len2) + 1][len1][len2], 
                st[x2 - (1ll << len1) + 1][y2 - (1ll << len2) + 1][len1][len2]});
}
```

