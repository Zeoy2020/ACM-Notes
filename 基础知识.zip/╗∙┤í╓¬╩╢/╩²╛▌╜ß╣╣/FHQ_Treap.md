# FHQ-Treap

>有旋 Treap 依靠旋转操作来维护树的平衡。FHQ Treap 又称无旋 Treap，通过使用**分裂**与**合并**两个操作来代替旋转，使得保持树的平衡。
>
>这种操作方式支持维护序列、区间操作、可持久化等特性。
>
>先了解一下 Treap 的原理，Treap = Tree + Heap，平衡树上的每个节点放两个值：树的权值 $val$ 和堆的随机值 $key$，对于 $val$ 值，维护查找树的性质，对于 $key$ 值，维护堆的性质。
>这样，即使顺序插入一个有序序列，也不会退化为一条链，堆的随机值等价于随机打乱了有序序列插入的顺序。
>
>如图，顺序插入 1 2 3 4 5 6 等价于按照 4 2 5 1 3 6 的顺序插入，并且发现仍然符合二叉查找树的性质，即**中序遍历有序**。
>
>![image-20240422210540986](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240422210540986.png)

## 分裂

### 按值分裂

>根据给定的 $v$ 将一棵树分裂成两棵树 $T1,T2$，$T1$ 的值 $val \leq v$，$T2$ 的值 $val > v$

如果当前节点 $id$ 的 $val≤v$，说明 $id$ 以及其左子树都属于分裂后的 左 Treap。但是 $id$ 的右子树也可能部分 $≤v$，因此需要继续递归分裂右子树，把$≤v$ 的那部分作为 $id$ 的右子树。把 $x$ 指向 左 Treap 的根。

如果当前节点 $id$ 的 $val>v$，说明 $id$ 以及其右子树都属于分裂后的 右 Treap。$id$ 的左子树也可能部分 $>v$，因此需要继续递归分裂左子树，把 $>v$ 的那部分作为 $id$ 的左子树。把 $y$ 指向 右 Treap 的根。

例如：$v = 3$ 时，分裂情况如下：

<img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240422213257669.png" alt="image-20240422213257669" style="zoom:50%;" />

### 按排名分裂

>根据给定的 $v$ 将一棵树分裂成两棵树 $T1,T2$，$T1$ 的排名 $rnk \leq v$，$T2$ 的 排名 $rnk > v$
>
>一般通常在维护序列问题上使用

## 合并

>合并 $x$ 和 $y$ 两颗树，合并的前提必须保证 $x$ 中 $val$ 最大的点必须小于等于 $y$ 中 $val$ 最小的点
>同时必须保证具有堆的性质，即 $key$ 大的往上放，以及树的性质，即左子树小于等于根，根小于等于右子树

因为两个 Treap 已经有序，所以在合并的时候只需要考虑把哪个树放在上面，把哪个树放在下面，也就是需要判断将哪个一个树作为子树。根据堆的性质，我们把 $key$ 值 大的放在上面。

可以模拟下图合并的过程理解，下图是小根堆，$key$ 值小的在上面

<img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240422214329372.png" alt="image-20240422214329372" style="zoom: 33%;" />

## 插入

假设插入的元素值为 $x$，考虑三步走：

1. 先将 $rt$ 分裂成 $T1:val\leq x$ 和 $T2:val > x$ 两棵树
2. 然后新建一个节点 $u = node(x)$，将 $T1$ 和 $u$ 合并到 $T1$ 中
3. 合并 $T1$ 和 $T2$ 形成一颗新的树，将其根赋值给 $rt$

## 删除

假设删除的元素值为 $x$，考虑四步走：

1. 先将 $rt$ 分裂成 $T1:val\leq x$ 和 $T2:val > x$ 两棵树
2. 然后再将 $T1$ 分裂成 $T1:val\leq x - 1$ 和 $T3:val = x$
3. 然后考虑删除 $T3$ 的根，即合并 $T3.ls$ 和 $T3.rs$
4. 最后按照分裂顺序倒序合并，形成一颗新的树，将其根赋值给 $rt$

## 区间反转

FHQ-Treap 维护序列，所以我们需要**按照排名分裂**

假设反转区间为 $[l, r]$：

* 考虑先将 $rt$ 分裂成 $T1:rnk\leq r,T2:rnk > r$
* 然后将 $T1$ 分裂成 $T1:rnk \leq l - 1,T3\geq l$
* 因为是区间反转，我们需要反转 $T3$ 上的所有节点的左右儿子，直接暴力反转复杂度太高，考虑打懒标记优化，所以每个节点还需要再维护个懒标记 $tag$
* 接下来我们不管什么操作，只要到了某个节点，就下放标记，类似线段树
* 最后我们只需要中序遍历输出序列即可，注意**中序遍历的时候也需要下放标记**

## 模板

```cpp
mt19937 rnd(time(0));
struct FHQ_Treap {
    int ls, rs, key, sz, val;
    #define ls(x) fhq[x].ls
    #define rs(x) fhq[x].rs
    #define key(x) fhq[x].key
    /*
        ls: 左儿子
        rs: 右儿子
        key：使得树有着堆的性质，默认大根堆，即 key 越大的点越往上放
        sz：子树大小
        val：集合中的元素值
    */
} fhq[N];
int rt, tot, T1, T2, T3;
// 构造新节点
int newNode(int v) {
    fhq[++tot] = {0, 0, (int)rnd(), 1, v};
    return tot;
}
void up(int id) {
    fhq[id].sz = fhq[ls(id)].sz + fhq[rs(id)].sz + 1;
}
// 按值分裂，分裂成 val <= v 和 val > v 的两颗平衡树
void split(int id, int v, int &x, int &y) {
    if (!id) {
        x = y = 0;
        return;
    }
    if (fhq[id].val > v) {
        y = id;
        split(ls(id), v, x, ls(id));
    } else {
        x = id;
        split(rs(id), v, rs(id), y);
    }
    up(id);
}
// 按排名分裂，分裂成 rank <= k 和 rank > k 两颗平衡树
void split_rank(int id, int k, int &x, int &y) {
    if (id == 0) {
        x = y = 0;
        return;
    }
    int tmp = fhq[ls(id)].sz + 1;
    if (k == tmp) {
        x = id;
        y = rs(id);
        rs(id) = 0;
    } else if (k < tmp) {
        y = id;
        split_rank(ls(id), k, x, ls(id));
    } else {
        x = id;
        split_rank(rs(id), k - tmp, rs(id), y);
    }
    up(id);
}
/*
    合并 x 和 y 两颗平衡树，合并的前提必须保证 x 中 val 最大的点必须小于等于 y 中 val 最小的点
    既保证具有堆的性质，即 key 大的往上放，同时又保证了树的性质，即左子树小于等于根，根小于等于右子树
*/
int merge(int x, int y) {
    if (!x || !y) return x + y;
    if (key(x) > key(y)) {
        rs(x) = merge(rs(x), y);
        up(x);
        return x;
    } else {
        ls(y) = merge(x, ls(y));
        up(y);
        return y;
    }
}
void insert(int v) {
    split(rt, v, T1, T2);
    rt = merge(merge(T1, newNode(v)), T2);
}
void erase(int v) {
    // 先将 rt 分裂成 T1: val <= v, T2: val > v 两棵树
    split(rt, v, T1, T2);
    // 再将 T1 分裂成 T1: val <= v - 1, T3: val = v 两棵树
    split(T1, v - 1, T1, T3);
    // 不妨直接删除 T3 的根节点，因为根节点的值也是 v，所以直接合并根节点左右儿子即可
    T3 = merge(ls(T3), rs(T3));
    rt = merge(merge(T1, T3), T2);
}
// 查询 x 的排名，即比 x 小的数的个数 + 1
int find_rank(int x) {
    split(rt, x - 1, T1, T2);
    int rnk = fhq[T1].sz + 1;
    rt = merge(T1, T2);
    return rnk;
}
// 查询集合中第 k 小（排名为 k）的数
int find_kth(int k) {
    int u = rt;
    while (u) {
        int tmp = fhq[ls(u)].sz + 1;
        if (tmp == k) break;
        else if (k < tmp) u = ls(u);
        else k -= tmp, u = rs(u);
    }
    return fhq[u].val;
}
// 查询 x 的前驱，即小于等于 x 的最大的数
int find_pre(int u, int x) {
    if (u == 0) return -inf;
    if (fhq[u].val < x) {
        int res = find_pre(rs(u), x);
        return res == -inf ? fhq[u].val : res;
    } else {
        return find_pre(ls(u), x);
    }
}
// 查询 x 的后继，即大于等于 x 的最小的数
int find_nxt(int u, int x) {
    if (u == 0) return inf;
    if (fhq[u].val > x) {
        int res = find_nxt(ls(u), x);
        return res == inf ? fhq[u].val : res;
    } else {
        return find_nxt(rs(u), x);
    }
}
```

## P3391 文艺平衡树

>![image-20240422233647291](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240422233647291.png)

### 题解：FHQ-Treap 维护序列上区间反转操作

```cpp
int n, m;
mt19937 rnd(time(0));
struct FHQ_Treap {
    int ls, rs, key, sz, val;
    bool lazy;
    #define ls(x) fhq[x].ls
    #define rs(x) fhq[x].rs
    #define key(x) fhq[x].key
} fhq[N];
int rt, tot, T1, T2, T3;
int newNode(int v) {
    fhq[++tot] = {0, 0, (int)rnd(), 1, v, false};
    return tot;
}
void up(int id) {
    fhq[id].sz = fhq[ls(id)].sz + fhq[rs(id)].sz + 1;
}
void settag(int id, int tag) {
    swap(ls(id), rs(id));
    fhq[id].lazy ^= tag;
}
void down(int id) {
    if (!fhq[id].lazy) return;
    settag(ls(id), fhq[id].lazy);
    settag(rs(id), fhq[id].lazy);
    fhq[id].lazy = false;
}
void split_rank(int id, int k, int &x, int &y) {
    if (id == 0) {
        x = y = 0;
        return;
    }
    down(id);
    int tmp = fhq[ls(id)].sz + 1;
    if (k == tmp) {
        x = id;
        y = rs(id);
        rs(id) = 0;
    } else if (k < tmp) {
        y = id;
        split_rank(ls(id), k, x, ls(id));
    } else {
        x = id;
        split_rank(rs(id), k - tmp, rs(id), y);
    }
    up(id);
}
int merge(int x, int y) {
    if (!x || !y) return x + y;
    if (key(x) > key(y)) {
        down(x);
        rs(x) = merge(rs(x), y);
        up(x);
        return x;
    } else {
        down(y);
        ls(y) = merge(x, ls(y));
        up(y);
        return y;
    }
}
void insert(int v) {
    split_rank(rt, v, T1, T2);
    rt = merge(merge(T1, newNode(v)), T2);
}
void erase(int v) {
    split_rank(rt, v, T1, T2);
    split_rank(T1, v - 1, T1, T3);
    T3 = merge(ls(T3), rs(T3));
    rt = merge(merge(T1, T3), T2);
}
void reverse(int l, int r) {
    split_rank(rt, r, T1, T2);
    split_rank(T1, l - 1, T1, T3);
    settag(T3, 1);
    rt = merge(merge(T1, T3), T2);
}
void dfs(int u) {
    if (!u) return;
    down(u);
    dfs(ls(u));
    cout << fhq[u].val << " ";
    dfs(rs(u));
}
void solve() {
    cin >> n >> m;
    for (int i = 1; i <= n; ++i) rt = merge(rt, newNode(i));
    while (m--) {
        int l, r; cin >> l >> r;
        reverse(l, r);
    }
    dfs(rt);
}
```

## P3988 [SHOI2013] 发牌

>给定 $1,2,3...n$ 的序列，然后 $n$ 次操作，每次操作给出一个 $k$，即循环 $k$ 次一下操作：将序列最左边的数放到序列最右边，每次操作后弹出序列最左边的数，即每次操作使得序列长度减少 $1$，请你求出每次弹出的数

### 题解：FHQ-Treap 维护序列上区间移动操作

>显然我们发现就是把前 $k$ 个数搬到序列后面
>
>考虑 FHQ-Treap 维护序列，所以我们需要按排名分裂，每次操作只需要将序列分裂成 $T1:[1,k],T2:[k+1,n]$，然后合并 $merge(T2, T1)$ 即可，然后对于合并出来的新序列，我们分裂出 $[1, 1]$ 并输出其元素值即可

```cpp
mt19937 rnd(time(0));
struct FHQ_Treap {
    int ls, rs, key, sz, val;
    #define ls(x) fhq[x].ls
    #define rs(x) fhq[x].rs
    #define key(x) fhq[x].key
} fhq[N];
int rt, tot, T1, T2, T3;
int newNode(int v) {
    fhq[++tot] = {0, 0, (int)rnd(), 1, v};
    return tot;
}
void up(int id) {
    fhq[id].sz = fhq[ls(id)].sz + fhq[rs(id)].sz + 1;
}
void split_rank(int id, int k, int &x, int &y) {
    if (id == 0) {
        x = y = 0;
        return;
    }
    int tmp = fhq[ls(id)].sz + 1;
    if (k == tmp) {
        x = id;
        y = rs(id);
        rs(id) = 0;
    } else if (k < tmp) {
        y = id;
        split_rank(ls(id), k, x, ls(id));
    } else {
        x = id;
        split_rank(rs(id), k - tmp, rs(id), y);
    }
    up(id);
}
int merge(int x, int y) {
    if (!x || !y) return x + y;
    if (key(x) > key(y)) {
        rs(x) = merge(rs(x), y);
        up(x);
        return x;
    } else {
        ls(y) = merge(x, ls(y));
        up(y);
        return y;
    }
}
void solve() {
    int n; cin >> n;
    for (int i = 1; i <= n; ++i) rt = merge(rt, newNode(i));
    for (int i = 1; i <= n; ++i) {
        int k; cin >> k;
        k %= fhq[rt].sz;
        split_rank(rt, k, T1, T2);
        rt = merge(T2, T1);
        split_rank(rt, 1, T1, rt);
        cout << fhq[T1].val << endl;
    }
}
```

## [TJOI2013] 最长上升子序列

>![image-20240423111638207](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240423111638207.png)
>
>$1 \leq n \leq 10^5$

### 题解：FHQ-Treap 维护区间最大值

>考虑 LIS 的转移方程：$dp[i] = \max(dp[i],dp[j] + 1), a[i] > a[j] \and j < i$
>
>并且我们发现题目保证插入的数是升序的，所以加入当前插入的位置为 $k$，则不会对 $dp[k + 1, n]$  产生影响，所以我们只需要知道 $mx = \max_{i = 1}^{k - 1} dp[i]$ 即可，然后令 $dp[k] = mx + 1$ 即可，然后将 $dp[k]$ 插入到 $k - 1$ 的后面
>
>考虑 FHQ-Treap，每个节点 $i$ 维护 $dp[i]$，以及子树中 $\max dp[j]$ ，即区间最大值
>
>那么对于插入操作来说，我们不妨先分裂成 $T1:rnk\leq k - 1, T2:rnk\geq k$，然后新建一个值为 $T1.mx + 1$ 的节点 $k$，然后 $merge(merge(T1, k), T2)$ 即可
>
>本题重点考虑：平衡树维护区间最大值，注意 $up$ 的时候不要忘记比较当前节点的值

```cpp
mt19937 rnd(time(0));
struct FHQ_Treap {
    int ls, rs, key, sz, val, mx;
    #define ls(x) fhq[x].ls
    #define rs(x) fhq[x].rs
    #define key(x) fhq[x].key
} fhq[N];
int rt, tot, T1, T2, T3;
int newNode(int v) {
    fhq[++tot] = {0, 0, (int)rnd(), 1, v, v};
    return tot;
}
void up(int id) {
    fhq[id].sz = fhq[ls(id)].sz + fhq[rs(id)].sz + 1;
    fhq[id].mx = max({fhq[ls(id)].mx, fhq[rs(id)].mx, fhq[id].val});
}
void split_rank(int id, int k, int &x, int &y) {
    if (id == 0) {
        x = y = 0;
        return;
    }
    int tmp = fhq[ls(id)].sz + 1;
    if (k == tmp) {
        x = id;
        y = rs(id);
        rs(id) = 0;
    } else if (k < tmp) {
        y = id;
        split_rank(ls(id), k, x, ls(id));
    } else {
        x = id;
        split_rank(rs(id), k - tmp, rs(id), y);
    }
    up(id);
}
int merge(int x, int y) {
    if (!x || !y) return x + y;
    if (key(x) > key(y)) {
        rs(x) = merge(rs(x), y);
        up(x);
        return x;
    } else {
        ls(y) = merge(x, ls(y));
        up(y);
        return y;
    }
}
void solve() {
    int n; cin >> n;
    for (int i = 1; i <= n; ++i) {
        int pos; cin >> pos;
        split_rank(rt, pos, T1, T2);
        T1 = merge(T1, newNode(fhq[T1].mx + 1));
        rt = merge(T1, T2);
        cout << fhq[rt].mx << endl;
    }
}
```

