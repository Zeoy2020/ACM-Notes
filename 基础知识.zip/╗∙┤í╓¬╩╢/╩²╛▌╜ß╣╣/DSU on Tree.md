# DSU on Tree

>* 一般用来维护子树信息
>
>* 本质仍然是启发式合并
>
>* 但是在树上存在一些常数不错的技巧
> * 对于每个点$u$，我们找节点个数最多的儿子（重儿子）
> * 我们先将根节点继承重儿子，然后将所有轻儿子合并到重儿子去
> * 或者更过分的我们可以怎么干？
> * 我们可以直接遍历轻儿子子树中的所有节点，然后将这些节点合并到重儿子中去
> * 因为最坏的情况下我们本来就是需要遍历轻儿子中的所有点
> * ![image-20230726213627261](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230726213627261.png)

>* 时间复杂度：$O(nlog\ n)$
>* 空间复杂度：$O(n)$，只维护了一个集合
>* 对于信息来说，支持加入和清空，不像线段树需要信息的合并
>* 可以在子树问题上解决一些树上莫队$O(n\sqrt{n})$的问题

##  模板

```cpp
int n;
vector<int> adj[N];
int l[N], r[N], id[N], sz[N], hson[N], tot;
int ans[N];

// DFS序作用是为了减少遍历子树的常数
// 预处理重儿子和 DFS 序
void dfs1(int u, int par) {
    l[u] = ++tot;
    id[tot] = u;
    sz[u] = 1;
    hson[u] = -1;
    for (auto v : adj[u]) {
        if (v == par) continue;
        dfs1(v, u);
        sz[u] += sz[v];
        if (hson[u] == -1 || sz[v] > sz[hson[u]]) hson[u] = v;
    }
    r[u] = tot;
}
void dfs2(int u, int par, bool keep) {
    /* 递归解决所有轻儿子, 且轻儿子的信息不需要保留 */
    for (auto [v, w] : adj[u]) {
        if (v != par && v != hson[u])
            dfs2(v, u, false);
    }
    /* 如果有重儿子，求重儿子，并且保留重儿子的信息 */
    if (hson[u] != -1) dfs2(hson[u], u, true);
    
    auto add = [&](int x) {

    };

    auto del = [&](int x) {
    };

    auto query = [&](int x) {
    };

    for (auto v : adj[u]) {
        if (v != par && v != hson[u]) { // v 是轻儿子
            /* 如果需要查询的话，考虑在合并该子树前查询，还是合并后查询 */
            for (int x = l[v]; x <= r[v]; ++x) query(id[x]);
            /* 把 v 子树中的所有点加入到重儿子的集合中去 */
            for (int x = l[v]; x <= r[v]; ++x) add(id[x]);
        }
    }
    /* 将 u 本身加入重儿子集合 */
    query(u);
    add(u);

    /* 更新答案 */
    // ans[u] = ...
    
    /* 如果信息不需要保留，直接清空 */
    if (!keep) {
        /* 
            如果有其他容器之类的，也在这里清空
            eg: map.clear();
        */
        
        for (int x = l[u]; x <= r[u]; ++x) del(id[x]);
    }
}
```



## 解决子树问题

### CF600 E. Lomsat gelral

>给定一颗 $n$ 个节点的有根树，根为 $1$，每个节点都有颜色，请你求出其以每个节点为根的子树中颜色的众数（出现次数最多的颜色）

```cpp
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
vector<int> g[N];
int c[N];
int l[N], r[N], idx, id[N], hson[N], sz[N];
int cnt[N], max_cnt, sum_cnt;
int ans[N];

void dfs_init(int u, int par)
{
    l[u] = ++idx;
    id[idx] = u;
    sz[u] = 1;
    hson[u] = -1;
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs_init(v, u);
        sz[u] += sz[v];
        if (hson[u] == -1 || sz[v] > sz[hson[u]])
            hson[u] = v;
    }
    r[u] = idx;
}

void dfs_solve(int u, int par, bool keep)
{
    for (auto v : g[u])
    {
        if (v != par && v != hson[u])
            dfs_solve(v, u, false);
    }
    if (hson[u] != -1)
        dfs_solve(hson[u], u, true);

    auto add = [&](int u)
    {
        int col = c[u];
        cnt[col]++;
        if (cnt[col] > max_cnt)
        {
            max_cnt = cnt[col];
            sum_cnt = 0;
        }
        if (cnt[col] == max_cnt)
            sum_cnt += col;
    };

    auto del = [&](int u)
    {
        int col = c[u];
        cnt[col]--;
    };

    for (auto v : g[u])
    {
        if (v != par && v != hson[u])
        {
            for (int x = l[v]; x <= r[v]; ++x)
                add(id[x]);
        }
    }
    add(u);
    ans[u] = sum_cnt;
    if (!keep)
    {
        sum_cnt = 0;
        max_cnt = 0;
        for (int x = l[u]; x <= r[u]; ++x)
            del(id[x]);
    }
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> c[i];
    for (int i = 1; i < n; ++i)
    {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs_init(1, 0);
    dfs_solve(1, 0, false);
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << " ";
}
```

## 解决路径问题

### IOI2011 Race

>给一颗 $n$ 个点的树，每条边有权，求一条简单路径，权值和等于 $k$，且边的数量最小

>显然点分治可以解决，这里考虑树上启发式合并解决
>
>对于树上路径，我们显然考虑每个顶点作为路径端点 $lca$ 的情况
>
>对于一条树上路径，其权值显然为 $dis[u] + dis[v] - 2dis[lca(u,v)]$
>
>那么对于一颗子树 $u$ 来说，即只考虑 $lca=u$ 的路径，我们完全可以维护 $val[dis]$ 代表到根节点路径权值和为 $dis$ 的路径上的最少边数，那么我们在将所有轻儿子的子树合并进重儿子的前，我们完全可以先查询 $val[k + 2dis[u] - dis[v]]$ ，然后再将轻儿子的子树加入进去，感觉和点分治很像，不同的是 $val[dis]$ 在点分治中维护的是到 $u$ 的路径权值和为 $dis$ 的最少边数

```cpp
int n, k;
vector<array<int, 2>> adj[N];
int l[N], r[N], id[N], sz[N], hson[N], tot, dep[N], dis[N];
int ans = inf;
map<int, int> val;
void dfs1(int u, int par) {
    l[u] = ++tot;
    id[tot] = u;
    sz[u] = 1;
    hson[u] = -1;
    for (auto [v, w] : adj[u]) {
        if (v == par) continue;
        dep[v] = dep[u] + 1;
        dis[v] = dis[u] + w;
        dfs1(v, u);
        sz[u] += sz[v];
        if (hson[u] == -1 || sz[v] > sz[hson[u]]) hson[u] = v;
    }
    r[u] = tot;
}
void dfs2(int u, int par, bool keep) {
    /* 递归解决所有轻儿子, 且轻儿子的信息不需要保留 */
    for (auto [v, w] : adj[u]) {
        if (v != par && v != hson[u])
            dfs2(v, u, false);
    }
    /* 如果有重儿子，求重儿子，并且保留重儿子的信息 */
    if (hson[u] != -1) dfs2(hson[u], u, true);
    auto add = [&](int x) {
        if (val.count(dis[x])) val[dis[x]] = min(val[dis[x]], dep[x]);
        else val[dis[x]] = dep[x];
    };
    auto query = [&](int x) {
        int d2 = k + 2 * dis[u] - dis[x];
        if (val.count(d2)) ans = min(ans, val[d2] + dep[x] - 2 * dep[u]);
    };
    for (auto [v, w] : adj[u]) {
        if (v != par && v != hson[u]) { // v 是轻儿子
            /* 如果需要查询的话，考虑在合并该子树前查询，还是合并后查询 */
            for (int x = l[v]; x <= r[v]; ++x) query(id[x]);
            /* 把 v 子树中的所有点加入到重儿子的集合中去 */
            for (int x = l[v]; x <= r[v]; ++x) add(id[x]);
        }
    }
    /* 将 u 本身加入重儿子集合 */
    query(u);
    add(u);
    /* 如果信息不需要保留，直接清空 */
    if (!keep) val.clear();
}

void solve() {
    cin >> n >> k;
    for (int i = 1; i < n; ++i) {
        int u, v, w; cin >> u >> v >> w;
        ++u, ++v;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }
    dfs1(1, 0);
    dfs2(1, 0, 0);
    if (ans > n + 1) ans = -1;
    cout << ans << endl;
}
```

