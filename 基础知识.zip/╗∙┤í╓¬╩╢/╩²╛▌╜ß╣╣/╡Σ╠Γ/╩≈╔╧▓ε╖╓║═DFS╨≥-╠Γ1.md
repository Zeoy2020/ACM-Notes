##  [USACO - 576](https://vjudge.net/problem/USACO-576/origin) 

>树上所有点初始点权为0，每次操作给定树上的两个点，对其两点之间所有点的权值+1,求K次操作后树上最大的点的点权是多少？

### 题解：点差分

 >板子题，不解释

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e4 + 10, M = 4e5 + 10;

int n, q;
vector<int> g[N];
int dif[N], pre[N];
int fa[N][22], dep[N];

void DFS(int u, int par)
{
    dep[u] = dep[par] + 1;
    fa[u][0] = par;
    for (int i = 1; i <= 20; ++i)
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        DFS(v, u);
    }
}

int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);
    for (int i = 20; i >= 0; i--)
    {
        if (dep[fa[u][i]] >= dep[v])
            u = fa[u][i];
    }
    if (u == v)
        return u;
    for (int i = 20; i >= 0; i--)
    {
        if (fa[u][i] != fa[v][i])
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0];
}

void dfs(int u, int par)
{
    pre[u] += dif[u];
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        pre[u] += pre[v];
    }
}

void solve()
{
    cin >> n >> q;
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    DFS(1, 0);
    while (q--)
    {
        int u, v;
        cin >> u >> v;
        int rt = lca(u, v);
        dif[u]++;
        dif[v]++;
        dif[rt]--;
        dif[fa[rt][0]]--;
    }
    dfs(1, 0);
    int ans = 0;
    for (int i = 1; i <= n; ++i)
        ans = max(pre[i], ans);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [CodeForces - 191C ](https://vjudge.net/problem/CodeForces-191C/origin) 

>每次操作给定树上的两个点，使得这两个点之间的所有路径的边权都加1，最后按照顺序输出所有路径的边权

### 题解：边差分

>板子题，不再赘述

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e5 + 10, M = 4e5 + 10;

int n, q;
vector<int> g[N];
int dif[N], pre[N];
int fa[N][22], dep[N];
pii ed[N];
int qid[N], ans[N];

void DFS(int u, int par)
{
    dep[u] = dep[par] + 1;
    fa[u][0] = par;
    for (int i = 1; i <= 20; ++i)
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        DFS(v, u);
    }
}

int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);
    for (int i = 20; i >= 0; i--)
    {
        if (dep[fa[u][i]] >= dep[v])
            u = fa[u][i];
    }
    if (u == v)
        return u;
    for (int i = 20; i >= 0; i--)
    {
        if (fa[u][i] != fa[v][i])
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0];
}

void dfs(int u, int par)
{
    pre[u] += dif[u];
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        pre[u] += pre[v];
    }
    ans[qid[u]] = pre[u];
}

void solve()
{
    cin >> n;
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
        ed[i] = {u, v};
    }
    DFS(1, 0);
    for (int i = 1; i <= n; ++i)
    {
        auto &[u, v] = ed[i];
        if (dep[u] < dep[v])
            swap(u, v);
        qid[u] = i;
    }
    cin >> q;
    while (q--)
    {
        int u, v;
        cin >> u >> v;
        dif[u]++;
        dif[v]++;
        dif[lca(u, v)] -= 2;
    }
    dfs(1, 0);
    for (int i = 1; i <= n - 1; ++i)
        cout << ans[i] << " ";
    cout << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [LibreOJ - 144 ](https://vjudge.net/problem/LibreOJ-144/origin) 

>给定一颗有n个节点组成的有根树，每个节点都有权值，现在有M组操作，每组操作分为两种：
>
>1.单点修改，将节点a的值权值增加x
>
>2.区间查询，表示求节点a子树上所有节点的权值之和

### 题解：DFS序和树状数组

>树状数组维护DFS序数组即可

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int n, m, rt;
int ul[N], ur[N];
vector<int> g[N];
int a[N];
int dfn[N], cnt;
int c[N];

int lowbit(int x)
{
    return x & -x;
}

void add(int x, int val)
{
    while (x <= n)
    {
        c[x] += val;
        x += lowbit(x);
    }
}

int getsum(int x)
{
    int sum = 0;
    while (x > 0)
    {
        sum += c[x];
        x -= lowbit(x);
    }
    return sum;
}

void dfs(int u, int par)
{
    dfn[u] = ++cnt;
    ul[u] = cnt;
    add(cnt, a[u]);
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
    }
    ur[u] = cnt;
}

void solve()
{
    cin >> n >> m >> rt;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1, u, v; i <= n - 1; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(rt, 0);

    while (m--)
    {
        int op, u, x;
        cin >> op;
        if (op == 1)
        {
            cin >> u >> x;
            add(dfn[u], x);
        }
        else
        {
            cin >> u;
            cout << getsum(ur[u]) - getsum(ul[u] - 1) << endl;
        }
    }
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [LibreOJ - 10131](https://vjudge.net/problem/LibreOJ-10131/origin) 

>Dark 是一张无向图，图中有 N 个节点和两类边，一类边被称为主要边，而另一类被称为附加边。Dark 有 N−1条主要边，并且 Dark 的任意两个节点之间都存在一条只由主要边构成的路径。另外，Dark 还有 M条附加边。
>
>你的任务是把 Dark 斩为不连通的两部分。一开始 Dark 的附加边都处于无敌状态，你只能选择一条主要边切断。一旦你切断了一条主要边，Dark 就会进入防御模式，主要边会变为无敌的而附加边可以被切断。但是你的能力只能再切断 Dark 的一条附加边。
>
>现在你想要知道，一共有多少种方案可以击败 Dark。注意，就算你第一步切断主要边之后就已经把 Dark 斩为两截，你也需要切断一条附加边才算击败了 Dark。

### 题解：边差分

>如果主要边没有被附加边访问过，那么切断这条主要边之后可以切割任意一条附加边
>
>如果主要边只被附加边访问过一次，那么切掉这条主要边之后只能切割覆盖它的附加边
>
>如果主要边被附加边访问过多次，那么切掉这条主要边之后，无论切割哪条附加边都不能使这张图变成两个连通块

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define int long long
#define mp make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e5 + 10;

int n, m;
vector<int> g[N];
int fa[N][22]; // fa[u][i]代表从u节点往上跳2^i步到达的节点
int dep[N];    // dep[u]代表u节点在树上的深度
int dif[N], pre[N];

void dfs(int u, int par) // 遍历树进行预处理，u代表当前节点，par代表当前节点u的父节点
{
    dep[u] = dep[par] + 1;
    fa[u][0] = par; // u节点往上跳1步就是他的父节点
    for (int i = 1; i <= 20; ++i)
    {
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    }
    for (auto &v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
    }
}
int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);               // 始终保证u的深度最深
    for (int i = 20; i >= 0; --i) // 先将u和v保证在同一深度
    {
        if (dep[fa[u][i]] >= dep[v]) // u往上跳2^i步，如果深度比v大，我们就跳，如果深度比v小，我们就不跳
            u = fa[u][i];
    }
    if (u == v) // lca(u,v)=v的情况
        return u;
    for (int i = 20; i >= 0; --i)
    {
        if (fa[u][i] != fa[v][i]) // 如果往上跳的节点不一样直接跳，如果一样就不跳
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0]; // 最后肯定是在他们的lca的子节点处，所以lca就是他们的父节点
}

void dfs1(int u, int par)
{
    pre[u] += dif[u];
    for (auto &v : g[u])
    {
        if (v == par)
            continue;
        dfs1(v, u);
        pre[u] += pre[v];
    }
}

void slove()
{
    cin >> n >> m;
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);

    int num = m;
    while (m--)
    {
        int u, v;
        cin >> u >> v;
        int rt = lca(u, v);
        dif[u]++;
        dif[v]++;
        dif[rt] -= 2;
    }
    dfs1(1, 0);
    int ans = 0;
    for (int i = 2; i <= n; ++i)
    {
        if (pre[i] == 0)
            ans += num;
        else if (pre[i] == 1)
            ans++;
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~



##  [Gym - 101807J](https://vjudge.net/problem/Gym-101807J/origin) 

>给定一棵树，每条边都存在边权，现在存在两种操作：
>
>1.单点修改，将u，v之间的边权改为x
>
>2.查询两个点之间的最短路径

### 题解：树状数组DFS序上维护差分

>要求树上两点之间的距离，只需要求出两点到根节点的距离和lca到根节点的距离即可，但因为存在单点修改一条边权，会影响到它的子树的所有点到根节点的距离，所以存在区间修改，所以我们需要动态维护单个节点到根节点的距离的差分

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10, M = 4e5 + 10;

int n, m, rt;
int ul[N], ur[N];
vector<pii> g[N];
int dfn[N], cnt;
int dis[N], dep[N];
int a[N];
int c[N];
int fa[N][22];
pii ed[N];

int lowbit(int x)
{
    return x & -x;
}

void add(int x, int val)
{
    while (x <= n)
    {
        c[x] += val;
        x += lowbit(x);
    }
}

int getsum(int x)
{
    int sum = 0;
    while (x > 0)
    {
        sum += c[x];
        x -= lowbit(x);
    }
    return sum;
}

void dfs(int u, int par, int w)
{
    dfn[u] = ++cnt;
    ul[u] = cnt;
    dis[u] = dis[par] + w;
    dep[u] = dep[par] + 1;
    a[cnt] = dis[u];
    fa[u][0] = par;
    for (int i = 1; i <= 20; ++i)
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    for (auto [v, w] : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u, w);
    }
    ur[u] = cnt;
}

int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);
    for (int i = 20; i >= 0; i--)
    {
        if (dep[fa[u][i]] >= dep[v])
            u = fa[u][i];
    }
    if (u == v)
        return u;
    for (int i = 20; i >= 0; i--)
    {
        if (fa[u][i] != fa[v][i])
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0];
}

void solve()
{
    cin >> n;
    for (int i = 1, u, v, w; i <= n - 1; ++i)
    {
        cin >> u >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
        ed[i] = {u, v};
    }
    dfs(1, 0, 0);
    for (int i = 1; i <= cnt; ++i)
        add(i, a[i] - a[i - 1]);
    cin >> m;
    while (m--)
    {
        int op, u, v, id, len;
        cin >> op;
        if (op == 1)
        {
            cin >> u >> v;
            int d = getsum(dfn[u]) + getsum(dfn[v]) - 2 * getsum(dfn[lca(u, v)]);
            if (d % 2 == 0)
                cout << "JAKANDA FOREVER" << endl;
            else
                cout << "WE NEED BLACK PANDA" << endl;
        }
        else
        {
            cin >> id >> len;
            auto [u, v] = ed[id];
            if (dep[u] < dep[v])
                swap(u, v);
            int d = getsum(dfn[u]) - getsum(dfn[v]);
            add(ul[u], -d);
            add(ur[u] + 1, d);
            add(ul[u], len);
            add(ur[u] + 1, -len);
        }
    }
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [CodeForces - 383C ](https://vjudge.net/problem/CodeForces-383C/origin) 

>给定一颗树，每个点都有点权，存在两种操作：
>
>1.单点修改，将val加到节点u上，然后对u节点的所有儿子节点加上-val，再对儿子的节点的儿子节点加上val，一次类推
>
>2.单点查询，查询节点u的点权

### 题解：两个树状数组DFS序上维护差分

>操作1看似单点修改实则区间修改，所以肯定需要维护差分，那么假如现在u是偶数层，那么它所有偶数层的子节点都会加上val，奇数层的子节点都会减去val；如果现在u是奇数层，那么所有奇数层的子节点都会加上val，偶数层的子节点都会减去val；
>
>所以我们只需要维护两个树状数组，一个维护偶数层dfs序上的点权的差分，另一个维护奇数层上dfs序上的点权的差分，我们能够保证偶数层树状数组对于偶数层的点权正确性和奇数层树状数组对于奇数层点权的正确性

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int a[N], b[N];
int n, m;
vector<int> g[N];
int c[2][N];
int dep[N];
int ul[N], ur[N], dfn[N], cnt;

int lowbit(int x) { return x & -x; }
void update(int x, int val)
{
    while (x <= n)
    {
        c[0][x] += val;
        c[1][x] += val;
        x += lowbit(x);
    }
}
void add(int x, int val)
{
    while (x <= n)
    {
        c[0][x] += val;
        c[1][x] -= val;
        x += lowbit(x);
    }
}

int getsum(int x, int op)
{
    int sum0 = 0, sum1 = 0;
    while (x > 0)
    {
        sum0 += c[0][x];
        sum1 += c[1][x];
        x -= lowbit(x);
    }
    if (op == 0)
        return sum0;
    else
        return sum1;
}

void dfs(int u, int par)
{
    dfn[u] = ++cnt;
    ul[u] = cnt;
    dep[u] = dep[par] + 1;
    b[cnt] = a[u];
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
    }
    ur[u] = cnt;
}

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1, u, v; i < n; ++i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, 0);
    for (int i = 1; i <= cnt; ++i)
        update(i, b[i] - b[i - 1]);

    while (m--)
    {
        int op, u, val;
        cin >> op;
        if (op == 1)
        {
            cin >> u >> val;
            if (dep[u] % 2 == 0)
            {
                add(ul[u], val);
                add(ur[u] + 1, -val);
            }
            else
            {
                add(ul[u], -val);
                add(ur[u] + 1, val);
            }
        }
        else
        {
            cin >> u;
            if (dep[u] % 2 == 0)
                cout << getsum(dfn[u], 0) << endl;
            else
                cout << getsum(dfn[u], 1) << endl;
        }
    }
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [CodeForces - 1110F](https://vjudge.net/problem/CodeForces-1110F/origin) 

>现在给定一颗树上节点编号和DFS序相同的树，给定$q$次询问，每次询问节点$u$到区间$[l,r]$中叶子节点的最短距离

### 题解：离线查询+线段树维护DFS序+换根思想

>对于离线查询：我们只需要将询问的区间和询问的编号记录在qid即可，即我们需要记录节点u的询问，所以建议使用vector容器
>
>线段树维护一段区间中的叶子节点到根节点的距离的最小值
>
>如何实现换根？因为这道题在线做一定会超时，所以我们采用离线的做法，我们可以知道在DFS的过程中，我们可以把被遍历到的点当作根，那么自上而下递归时就相当于节点u距离子树内所有叶子节点距离减少了w，距离子树外所有叶子节点距离增加了w，这里我们可以利用线段树打$lazy$实现，同时我们又维护的是叶子节点到根节点的距离的最小值，其实就相当于我们进行了换根操作，那么注意我们在自下而上回溯的时候需要还原成原来的根；这样的话我们在每次换完根后立刻检查当前节点u是否存在查询，如果存在，利用线段树查询区间最小值即可。

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define int long long
#define mp make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10;

int n, q;
vector<pii> g[N];
vector<array<int, 3>> qid[N];
int ans[N];
int ul[N], ur[N], cnt;
int dis[N];

struct info
{
    int minn;
};
struct node
{
    int l, r, lazy;
    info val;
} seg[N << 2];
info operator+(const info &a, const info &b)
{
    info c;
    c.minn = min(a.minn, b.minn);
    return c;
}

void settag(int id, int tag)
{
    seg[id].val.minn += tag;
    seg[id].lazy += tag;
}

void up(int id)
{
    seg[id].val = seg[id << 1].val + seg[id << 1 | 1].val;
}

void down(int id)
{
    if (seg[id].lazy == 0)
        return;
    settag(id << 1, seg[id].lazy);
    settag(id << 1 | 1, seg[id].lazy);
    seg[id].lazy = 0;
}

void build(int id, int l, int r)
{
    seg[id].l = l, seg[id].r = r;
    if (l == r)
    {
        seg[id].val.minn = INF;
        return;
    }
    int mid = l + r >> 1;
    build(id << 1, l, mid);
    build(id << 1 | 1, mid + 1, r);
    up(id);
}

void change(int id, int x, int v)
{
    int l = seg[id].l, r = seg[id].r;
    if (l == r)
    {
        seg[id].val.minn = v;
        return;
    }
    int mid = (l + r) >> 1;
    down(id);
    if (x <= mid)
        change(id << 1, x, v);
    else
        change(id << 1 | 1, x, v);
    up(id);
}

void modify(int id, int ql, int qr, int v)
{
    int l = seg[id].l, r = seg[id].r;
    if (ql <= l && r <= qr)
    {
        settag(id, v);
        return;
    }
    down(id);
    int mid = (l + r) >> 1;
    if (qr <= mid)
        modify(id << 1, ql, qr, v);
    else if (ql > mid)
        modify(id << 1 | 1, ql, qr, v);
    else
    {
        modify(id << 1, ql, qr, v);
        modify(id << 1 | 1, ql, qr, v);
    }
    up(id);
}

info query(int id, int ql, int qr)
{
    int l = seg[id].l, r = seg[id].r;
    if (ql <= l && r <= qr)
    {
        return seg[id].val;
    }
    down(id);
    int mid = (l + r) >> 1;
    if (qr <= mid)
        return query(id << 1, ql, qr);
    else if (ql > mid)
        return query(id << 1 | 1, ql, qr);
    else
        return query(id << 1, ql, qr) + query(id << 1 | 1, ql, qr);
}

void dfs(int u, int par, int w)
{
    ul[u] = ++cnt;
    dis[u] = dis[par] + w;
    for (auto &[v, w] : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u, w);
    }
    ur[u] = cnt;
}

void dfs1(int u, int par)
{
    for (auto &[l, r, id] : qid[u])
    {
        ans[id] = query(1, l, r).minn;
    }
    for (auto &[v, w] : g[u])
    {
        if (v == par)
            continue;
        modify(1, ul[v], ur[v], -w);
        if (ul[v] - 1 >= 1)
            modify(1, 1, ul[v] - 1, w);
        if (ur[v] + 1 <= n)
            modify(1, ur[v] + 1, n, w);
        dfs1(v, u);
        modify(1, ul[v], ur[v], w);
        if (ul[v] - 1 >= 1)
            modify(1, 1, ul[v] - 1, -w);
        if (ur[v] + 1 <= n)
            modify(1, ur[v] + 1, n, -w);
    }
}
void solve()
{
    cin >> n >> q;
    for (int u = 2, v, w; u <= n; ++u)
    {
        cin >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
    }
    build(1, 1, n);
    dfs(1, 0, 0);
    for (int i = 1, u, l, r; i <= q; ++i)
    {
        cin >> u >> l >> r;
        qid[u].push_back({l, r, i});
    }
    for (int i = 1; i <= n; ++i)
    {
        if (g[i].size() == 1)
            change(1, i, dis[i]);
    }
    dfs1(1, 0);
    for (int i = 1; i <= q; ++i)
        cout << ans[i] << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

## [LibreOJ - 146](https://vjudge.csgrandeur.cn/problem/LibreOJ-146/origin)

>![image-20230709132918477](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230709132918477.png)

### 题解：DFS序 + 树上差分 + LCA + 树状数组

>* 对于第一个修改操作我们只需要树状数组维护DFS序上点差分即可
>
>* 对于第二个询问某个节点的权值，我们只需要求该点在DFS差分上的子树和即可
>
>* 对于第三个操作实际上可以用树链剖分解决，这里我们考虑另一种方法
>
>* 对于以$u$为根的子树和，我们发现它的子树中任意一点$v$在差分数组上对子树和的贡献为$w_v\times (dep[v] - dep[u] + 1)$
>
>* 所以子树和为：
>
>* $$
>  \sum_{v \in u的子树}w[v]\times (dep[v] - dep[u] + 1)
>  $$
>
>* 我们不妨对其展开后，观察规律：
>
>* $$
>  \sum w[v]\times (dep[v] - dep[u] + 1)\\
>  = \sum w[v]\times dep[v] - \sum w[v]\times (dep[u] - 1)\\
>  = \sum w[v] \times dep[v] - (dep[u] - 1) \times \sum w[v]
>  $$
>
>* 容易发现，$dep[u] - 1$是固定的，而$\sum w[v]$ 实际上就是$u$的点权
>
>* 那么我们只要用树状数组额外维护一个$\sum w[v] \times dep[v]$即可

```cpp
const int N = 2e6 + 10, M = 4e5 + 10;

int n, m, rt;
int ul[N], ur[N];
vector<int> g[N];
int idx, dfn[N];
int fa[N][25];
int dep[N];
ll pre[N];
ll w[N];

char *p1, *p2, buf[100000];
#define nc() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 100000, stdin), p1 == p2) ? EOF : *p1++)
int read()
{
    int x = 0, f = 1;
    char ch = nc();
    while (ch < 48 || ch > 57)
    {
        if (ch == '-')
            f = -1;
        ch = nc();
    }
    while (ch >= 48 && ch <= 57)
        x = x * 10 + ch - 48, ch = nc();
    return x * f;
}

int lca(int u, int v)
{
    if (dep[u] < dep[v])
        swap(u, v);
    for (int i = 20; i >= 0; --i)
    {
        if (dep[fa[u][i]] >= dep[v])
            u = fa[u][i];
    }
    if (u == v)
        return u;
    for (int i = 20; i >= 0; --i)
    {
        if (fa[u][i] != fa[v][i])
        {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[u][0];
}

struct BIT
{
    ll c[N];
    ll lowbit(ll x)
    {
        return x & -x;
    }

    void add(int x, ll val)
    {
        while (x <= n)
        {
            c[x] += val;
            x += lowbit(x);
        }
    }

    ll get_sum(int x)
    {
        ll res = 0;
        while (x > 0)
        {
            res += c[x];
            x -= lowbit(x);
        }
        return res;
    }

    ll query(int l, int r)
    {
        return get_sum(r) - get_sum(l - 1);
    }
} c1, c2;

void dfs(int u, int par)
{
    ++idx;
    dfn[u] = idx;
    ul[u] = idx;
    pre[u] = w[u];

    dep[u] = dep[par] + 1;
    fa[u][0] = par;
    for (int i = 1; i <= 20; ++i)
    {
        fa[u][i] = fa[fa[u][i - 1]][i - 1];
    }
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        pre[u] += pre[v];
    }
    ur[u] = idx;
}

void solve()
{
    n = read(), m = read(), rt = read();
    for (int i = 1; i <= n; ++i)
    {
        w[i] = read();
    }
    for (int i = 1; i <= n - 1; ++i)
    {
        int u, v;
        u = read();
        v = read();
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(rt, 0);
    while (m--)
    {
        ll op, u, v, x;
        op = read();
        if (op == 1)
        {
            u = read();
            v = read();
            x = read();
            c1.add(dfn[u], x);
            c1.add(dfn[v], x);
            int LCA = lca(u, v);
            c1.add(dfn[LCA], -x);
            if (fa[LCA][0])
                c1.add(dfn[fa[LCA][0]], -x);

            c2.add(dfn[u], x * dep[u]);
            c2.add(dfn[v], x * dep[v]);
            c2.add(dfn[LCA], -x * dep[LCA]);
            if (fa[LCA][0])
                c2.add(dfn[fa[LCA][0]], -x * dep[fa[LCA][0]]);
        }
        else if (op == 2)
        {
            u = read();
            cout << c1.query(ul[u], ur[u]) + w[u] << endl;
        }
        else
        {
            u = read();
            cout << c2.query(ul[u], ur[u]) - (dep[u] - 1) * c1.query(ul[u], ur[u]) + pre[u] << endl;
        }
    }
}
```

