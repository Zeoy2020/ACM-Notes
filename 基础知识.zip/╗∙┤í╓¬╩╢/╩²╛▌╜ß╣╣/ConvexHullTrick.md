# 动态凸壳

>* 用来维护一次函数集合 $f|f(x)=kx+b$ 的凸包，询问 $\max f(x)$
>
>* 当然如果想要询问 $\min f(x)$，只需在添加函数时取反即可，即 $Insert(kx + b) \rightarrow Insert(-kx - b)$
>
>* 同样查询出的答案实际上为 $-\min f(x)$，再取负即为 $\min f(x)$。

```cpp
using i64 = long long;
struct Line {
	mutable i64 k, b, p;
	bool operator<(const Line &o) const { return k < o.k; }
	bool operator<(i64 x) const { return p < x; }
};
struct LineContainer : multiset<Line, less<>> {
	static constexpr i64 INF = numeric_limits<i64>::max();
	i64 div(i64 a, i64 b) {
		return a / b - ((a ^ b) < 0 && a % b);
	}
	bool isect(iterator x, iterator y) {
		if (y == end()) return x->p = INF, 0;
		if (x->k == y->k) x->p = x->b > y->b ? INF : -INF;
		else x->p = div(y->b - x->b, x->k - y->k);
		return x->p >= y->p;
	}
    // Insert f(x) = kx + b
	void add(i64 k, i64 b) {
		auto z = insert({k, b, 0}), y = z++, x = y;
		while (isect(y, z)) z = erase(z);
		if (x != begin() && isect(--x, y)) isect(x, y = erase(y));
		while ((y = x) != begin() && (--x)->p >= y->p)
			isect(x, erase(y));
	}
    // Query max(f(x))
	i64 query(i64 x) {
		if (empty()) return -INF;
		auto l = *lower_bound(x);
		return l.k * x + l.b;
	}
} lc;
```

## [YATP](https://codeforces.com/group/T43EBH4GgO/contest/494339/problem/A)

>给定一棵树，既有点权 $a$，又有边权 $w$，求所有路径的代价的最小值；
>
>对于一条路径来说，我们定义其代价 $cost(u,v) = a[u] \times a[v] + dis(u,v)$，$dis(u, v)$ 代表 $u$ 和 $v$ 之间的简单路径权值和

### 题解：点分治 + 动态凸包斜率优化

>* 考虑点分治，假设当前分治中心为 $u$，即统计所有经过 $u$ 点的路径的答案，定义 $dep[i]$ 为 $i$ 到 $u$ 的路径和，保证 $u$ 是 $i$ 的祖先；
>* 将原式转化成 $cost(u, v) = a[u] \times a[v] + dep[u] + dep[v]$
>* 然后发现如果 $a[v]$ 作为斜率，$dep[v]$ 作为截距的话，可以通过动态凸包进行斜率优化
>* 那么现在我们只需要先预处理出动态凸包，然后枚举所有 $a_u$，然后在凸包上查询最小值即可

```cpp
int n, a[N], sz[N], maxs[N], del[N], ans[N];
vector<pair<int, int>> adj[N];

struct Line {
	mutable i64 k, b, p;
	bool operator<(const Line &o) const { return k < o.k; }
	bool operator<(i64 x) const { return p < x; }
};
struct LineContainer : multiset<Line, less<>> {
	static constexpr i64 INF = numeric_limits<i64>::max();
	i64 div(i64 a, i64 b) {
		return a / b - ((a ^ b) < 0 && a % b);
	}
	bool isect(iterator x, iterator y) {
		if (y == end()) return x->p = INF, 0;
		if (x->k == y->k) x->p = x->b > y->b ? INF : -INF;
		else x->p = div(y->b - x->b, x->k - y->k);
		return x->p >= y->p;
	}
	void add(i64 k, i64 b) {
		auto z = insert({k, b, 0}), y = z++, x = y;
		while (isect(y, z)) z = erase(z);
		if (x != begin() && isect(--x, y)) isect(x, y = erase(y));
		while ((y = x) != begin() && (--x)->p >= y->p)
			isect(x, erase(y));
	}
	i64 query(i64 x) {
		if (empty()) return -INF;
		auto l = *lower_bound(x);
		return l.k * x + l.b;
	}
} lc;

void solve(int u, int s) {
    int ms = s + 1, root = -1;
    auto dfs1 = [&](auto self, int u, int par) -> void {
        sz[u] = 1, maxs[u] = 0;
        for (auto [v, w] : adj[u]) {
            if (del[v] || v == par) continue;
            self(self, v, u);
            sz[u] += sz[v];
            maxs[u] = max(maxs[u], sz[v]);
        }
        maxs[u] = max(maxs[u], s - sz[u]);
        if (maxs[u] < ms) ms = maxs[u], root = u;
    };
    dfs1(dfs1, u, -1);

    /*统计答案*/ 
    lc.clear();
    lc.add(-a[root], 0);
    for (auto [v, w] : adj[root]) {
        if (del[v]) continue;
        auto dfs2 = [&](auto self, int u, int par, int dep) -> void {
            lc.add(-a[u], -dep);
            for (auto [v, w] : adj[u]) {
                if (del[v] || v == par) continue;
                self(self, v, u, dep + w);
            }
        };
        dfs2(dfs2, v, root, w);
    }
    ans[root] = min(ans[root], -lc.query(a[root]));
    for (auto [v, w] : adj[root]) {
        if (del[v]) continue;
        auto dfs3 = [&](auto self, int u, int par, int dep) -> void {
            ans[u] = min(ans[u], -lc.query(a[u]) + dep);
            for (auto [v, w] : adj[u]) {
                if (del[v] || v == par) continue;
                self(self, v, u, dep + w);
            }
        };
        dfs3(dfs3, v, root, w);
    }

    del[root] = true;               
    for (auto [v, w] : adj[root])
        if (!del[v]) solve(v, sz[v]);
}

void solve() {
    cin >> n;
    for (int i = 1; i <= n; ++i) cin >> a[i];
    for (int i = 1; i < n; ++i) {
        int u, v, w; cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }
    for (int i = 1; i <= n; ++i) ans[i] = INF;
    solve(1, n);
    cout << accumulate(ans + 1, ans + n + 1, 0ll) << endl;
}
```

