# $xor-hashing$

>* $xor-hasing$ 是哈希算法的一大应用，大多数情况下我们使用随机权值用于 $xor-hashing$，出于这种随机性，与其它的多项式哈希而言它更不容易被卡，且其本身的冲突概率就相当小。
>
>* 为了解决冲突，我们可以利用**哈希**将异或的结果集扩大：将数字 $i$ 哈希成 $32$ 位整数 / $64$ 位整数，那么异或的结果集就被扩大成了 $2^{32}$ / $2^{64}$，那么冲突的概率极低。
>
>* 即先将 $a_i$ 离散化后对下标做随机映射（哈希）：$a_i \rightarrow i \rightarrow h_i$
>
>* 随机映射（哈希）我们考虑使用 $mt19937$ / $mt19937\_64$ 随机生成 $32$ 位 / $64$ 位整数。
>
>* 该算法应用于判断某个**无序**的序列是否满足某种条件（如是否为**排列，连续段，等差数列**等），且这种条件具有可哈希性。
>
>* **异或操作**和**加减操作**区别不大，但在特殊题目中（e.g. 统计元素的出现次数的相关性质）时需要斟酌。
>

# 排列问题

>给定一个长度为 $n$ 的数组 $a\ (a_i \leq n)$， $q$ 次询问，每次询问 $[l, r]$ 的子数组是否是一个排列

### 题解

>* 我们考虑将数字 $i$ 哈希成 $32$ 位整数，即 $h[i] = rnd()$
>* 我们定义 $sum[i] = \oplus_{k = 1}^i h[i]$， $xor[i] = \oplus_{k = 1}^i h[a[k]]$
>* 对于每个询问：
> * 如果 $xor[r] \oplus xor[l - 1]=sum[r - l + 1]$，则代表该子数组是一个排列

## CF1175 F. The Number of Subpermutations

>求一个序列 $a$ 中子数组为排列的数量。
>
>$1 \leq n \leq 3\times 10^5$

### 题解

>* 我们考虑先将 $i \in [1, n]$ 随机映射为 $h[i]$，定义 $pre1[i] = \oplus_{k = 1}^i h[i]$，$pre2[i] = \oplus_{k = 1}^i h[a[i]]$
>* 那么如果 $a[l,r]$ 是一个排列的话，则 $pre2[r] \oplus pre2[l - 1] = pre1[r - l + 1]$
>* 因为一个排列中一定存在 $1$，所以我们考虑枚举所有 $a_i = 1$ 作为起点，从该点出发遇到下一个 $1$ 之前的所有 $a_j$ 作为区间的右端点，我们定义 $mx = max\{a_i...a_j\}$ ，那么如果是一个排列，区间左端点一定在 $j - mx + 1$处，所以我们只需要判断区间 $[j - mx + 1, j]$ 是否为一个排列即可
>* 当然这种情况是排列中的最大值在 $1$ 右边的时候，同样存在排列中的最大值在 $1$ 左边的情况，例如：$[4,1,3,2]$
>* 我们只需要反转 $a$ 后在跑一遍刚才的算法即可
>* 复杂度：$O(n)$

```cpp
mt19937 rnd(time(0));
int n, a[N], h[N], pre1[N], pre2[N];
void solve() {
	cin >> n;
	for (int i=1;i<=n;++i)
		h[i] = rnd();
	for (int i=1;i<=n;++i)
		pre1[i] = pre1[i - 1] ^ h[i];
	for (int i=1;i<=n;++i)
		cin >> a[i];
	int ans = 0;
	auto calc = [&]() {
		for (int i=1;i<=n;++i)
			pre2[i] = pre2[i - 1] ^ h[a[i]];
		for (int i = 1, mx = 0; i <= n; ++i) {
			if (a[i] == 1)
				mx = 1;
			else
				mx = max(mx, a[i]);
			if (i - mx >= 0 && (pre2[i] ^ pre2[i - mx]) == pre1[mx]) 
				ans++;
		}
	}; 
	calc();
	reverse(a + 1, a + n + 1);
	calc();
	for (int i=1;i<=n;++i)	// 减去 [1] 排列的重复贡献
		ans -= (a[i] == 1);
	cout << ans << endl;
}
```

# 出现次数倍数问题

>* 二进制的异或的本质是对每一位进行不进位的加法，也就是每一位相加对 $2$ 取模。
>
><img src="C:\Users\ThinkBooK\AppData\Roaming\Typora\typora-user-images\image-20231123222937824.png" alt="image-20231123222937824" style="zoom:50%;" />
>
>- 如果我们想知道对于一个序列来说，是不是所有的元素都出现偶数次？
>  - 显然我们可以利用异或解决该问题，但是存在这种情况：$4 \oplus 8 \oplus 12 = 0$
>  - 所以我们需要通过 $xor-hasing$ 解决该冲突
>- 我们接下来将问题升级一下

## CF1746 F. Kazaee

>![image-20231123235733189](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231123235733189.png)

### 题解

>* 若 $k = 3$，我们发现：
>* ![image-20231123233155500](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231123233155500.png)
>* 也就是说，如果一个数转化为 $3$ 进制的形式，如果该数出现的次数为 $3$ 的倍数，那么其 “异或（不进位加法）” 后一定为 $0$。 
>* 同样可以推演至 $k$ 进制。
>* 但是显然这种 "异或" 会增加 $log_k C$ 的常数 
>* 我们考虑优化：
>* ![image-20231123235930564](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231123235930564.png)
>* 即使 $k = 2$，那么我们随机映射 $30$ 次后，其冲突的概率为 $\frac{1}{2^{30}}$

```cpp
mt19937 rnd(time(0));

int n, q, a[N], h[N], tr[N], tmp[N];

int lowbit(int x) {
	return x & -x;
}
void init(int n) {
	for (int i = 0; i <= n; ++i)
		tr[i] = 0;
}
void add(int x, int v) {
	while (x < N) {
		tr[x] += v;
		x += lowbit(x);
	}
}
int get_sum(int x) {
	int res = 0;
	while (x > 0) {
		res += tr[x];
		x -= lowbit(x);
	}
	return res;
}
int query(int l, int r) {
	return get_sum(r) - get_sum(l - 1);
}

void solve() {
	cin >> n >> q;
	vector<int> nums, vis(q + 10), ans(q + 10);
	vector<array<int, 5>> Q;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
		nums.push_back(a[i]);
	}
	for (int i = 1; i <= q; ++i) {
		int op, k, x, l, r;
		cin >> op;
		if (op == 1) {
			cin >> k >> x;
			nums.push_back(x);		// 注意要将询问中修改的值一起离散化
			Q.push_back({op, k, x, 0, i});
		} else {
			vis[i] = true;
			cin >> l >> r >> k;
			if ((r - l + 1) % k) {	// 如果区间长度不是 k 的倍数，显然一定不行
				ans[i] = -1;
			}
			Q.push_back({op, l, r, k, i});
		}
	}
	sort(all(nums));
	nums.erase(unique(all(nums)), nums.end());
	auto find = [&](int x) {
		return lower_bound(all(nums), x) - nums.begin() + 1;	
	};
	for (int i = 1; i <= n; ++i) {
		a[i] = find(a[i]);
		tmp[i] = a[i];
	}
	for (auto &[op, a, b, c, id] : Q)
		if (op == 1) b = find(b);
	auto solve = [&]() {
		init(n);
		for (int i = 1; i <= (int)nums.size(); ++i)
			h[i] = rnd();
		for (int i = 1; i <= n; ++i) {
			a[i] = tmp[i];		// 因为数组 a 被修改了，所以需要还原一下
			add(i, h[a[i]]);
		}
		for (auto [op, x, y, k, id] : Q) {
			if (op == 1) {
				add(x, h[y] - h[a[x]]);
				a[x] = y;
			} else {
				int S = query(x, y);
				if (S % k) {
					ans[id] = -1;
				}
			}
		}
	};
	for (int T = 1; T <= 30; ++T) {
		solve();
	}
	for (int i = 1; i <= q; ++i) {
		if (vis[i])
			cout << (ans[i] ? "NO" : "YES") << endl;
	}
}

```

## [Candy Rush](https://codeforces.com/group/T43EBH4GgO/contest/488848/problem/C)

>给定一个长度为 $n$ 的序列 $a\ (1 \leq a_i \leq k)$，给定 $k$，求一个最长的区间包含 $k$ 种数，并且每种数出现的次数相同

### 题解

>* 考虑 $xor-hasing$，我们对 $i \in [1,k - 1]$ 随机映射一个值 $h[i]$，$k$ 映射的值为 $-\sum_{i = 1}^{k - 1} h[i]$
>* 那么一个最长的区间包含 $k$ 种数，并且每种数出现的次数相同等价于 $sum[l,r] = 0$
>* 我们定义 $pre[i] = \sum_{k = 1}^ih[a[i]]$
>* 枚举右端点 $r$，$map$ 查询有无左端点 $l$ 使得 $pre_r = pre_{l - 1}$ 即可

```cpp
mt19937 rnd(time(0));

int n, k, a[N], h[N];

void solve() {
    cin >> n >> k;
    int sum = 0;
    for (int i=1;i<k;++i) {
        h[i] = rnd();
        sum += h[i];
    }
    h[k] = -sum;
    vector<int> pre(n + 10);
    for (int i=1;i<=n;++i)
        cin >> a[i];
    for (int i=1;i<=n;++i) {
        pre[i] = pre[i - 1] + h[a[i]];
    }
    map<int, int> mp;
    mp[0] = 0;
    int ans = -INF;
    for (int i=1;i<=n;++i) {
        if (mp.count(pre[i])) {
            ans = max(ans, i - mp[pre[i]]);
        } else {
            mp[pre[i]] = i;
        }
    }
    if (ans == -INF)
        cout << 0 << endl;
    else 
        cout << ans << endl;
}   
```

## 牛客周赛32 E.小红的回文数

>![image-20240213185303519](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240213185303519.png)

### 题解：异或哈希

>* 某个子段形成回文有两种情况：
>  * 该子段中每种数出现次数都是偶数次
>  * 该子段中有且仅有一种数出现次数是奇数次，其余的数出现次数都是偶数次
>* 看到出现次数的奇偶性，直接想到异或
>* 定义 $pre[i]$ 为前缀异或和，$cnt[i]$ 为前缀异或和中 $i$ 出现的次数，那么题目就转化为：
>* 枚举右端点 $r$，对于情况 $1$ 对答案的贡献为 $cnt[pre[r]]$，对于情况 $2$ 对答案的贡献为 $\sum_{i = 0}^9 cnt[i]$
>* 有可能会形成冲突，所以对每个数异或哈希避免冲突即可

# 例题

## CF1830 C. Hyperregular Bracket Strings

>![image-20231130222809190](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231130222809190.png)

### 题解

>* 对于区间之间，存在 $3$ 种关系：
>
>  * 区间之间不相交，即 $[l_1,r_1]$ 和 $[l_2, r_2]$ 不相交，则两个区间之间各自独立，对答案的贡献就是两个区间卡特兰数的乘积
>
>  * 区间之间相交： 
>
>    ![image-20231130223332366](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231130223332366.png)
>
>    那么中间重叠的部分必须是合法括号序列，左右两边的部分也必须是合法括号序列
>
>  * 区间之间包含：
>
>    ![image-20231130223500746](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231130223500746.png)
>
>    重叠部分必须是合法括号序列，不重叠的部分拼接起来后必须是合法括号序列
>
>* 那么现在问题转化为：设 $S_i$ 表示 $i$ 位置被哪些线段覆盖，所有 $S_i$ 相同的可以一起计算贡献，最后所有 $S_i$ 不同的方案数相乘就是答案
>
>* 所以我们只需要对每个区间随机映射一个值 $val$，然后对该区间做异或操作，最后异或值相同的点 $S_i$ 一定相同，利用 $map$ 统计相同 $S_i$  的数量即可，然后每种 $S_i$ 的方案数就是其卡特兰数

```cpp
mt19937_64 rnd(time(0));
int n, k, fac[N], inv[N];
int qpow(int a, int b, int p) {
	int res = 1;
	while (b) {
		if (b & 1)
			res = res * a % p;
		b >>= 1;
		a = a * a % p;
	}
	return res;
}
void init() {
	fac[0] = 1;
    for (int i = 1; i < N; ++i)
        fac[i] = fac[i - 1] * i % mod;
    inv[N - 1] = qpow(fac[N - 1], mod - 2, mod);
    for (int i = N - 2; i >= 0; --i)
        inv[i] = inv[i + 1] * (i + 1) % mod;
}
int C(int a, int b) {
	if (a < b || a < 0 || b < 0)
		return 0;
	return fac[a] * inv[b] % mod * inv[a - b] % mod;
}
int sub(int a, int b) {
	return ((a - b) % mod + mod) % mod;
}
int Catalan(int n) {
	if (n & 1)
		return 0;
	return sub(C(n, n / 2), C(n, n / 2 - 1));
}

void solve() {
	cin >> n >> k;
	vector<int> pre(n + 10);
	for (int i = 1; i <= k; ++i) {
		int l, r;
		int val = rnd();
		cin >> l >> r;
		pre[l] ^= val;
		pre[r + 1] ^= val;
	}
	map<int, int> mp;
	for (int i = 1; i <= n; ++i) {
		pre[i] ^= pre[i - 1];
		mp[pre[i]]++;
	}
	int ans = 1;
	for (auto [x, y] : mp) {
		ans = ans * Catalan(y) % mod;
	}
	cout << ans << endl;
}
```

## CERC22 F. Differences

>给定 $n$ 个字符串，每个字符串长度为 $m$，且只有 $A,B,C,D$组成，我们定义两个字符串 $X$ 和  $Y$ 之间的距离为 $\sum_{i = 1}^m X_i \neq Y_i $，现在 $n$ 个字符串中有且仅有一个特殊字符串，它与其他所有字符串的距离都为 $k$，请你找到该字符串，输出其编号
>
>$1 \leq n, m\leq 10^5,n·m \leq 2e7$

### 题解

>* 我们对于每一个位置 $j \in[1, m]$，预处理出 $A,B,C,D$ 每个字母分别出现在哪些编号中
>* 然后我们枚举每个字符串作为答案串，遍历该串的每个字母，假设当前位置 $j$ 字母为 $A$ ，我们定义数组 $d$，$d_i$ 代表当前的枚举的答案串与第 $i$ 个字符串之间的距离，然后将 $B,C,D$ 在第 $j$ 个位置会出现的编号在 $d$ 上对应位置加上其贡献
>* 然后如果当前字符串为答案串，则其最终 $d$ 数组一定是这个样子：$[k,k,k,0,k,k,k]$
>
><img src="https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231203104455646.png" alt="image-20231203104455646" style="zoom: 50%;" />
>
>* 所以我们只需要对每个编号 $i$ 随机映射一个值 $h_i$，然后通过异或哈希中的加减就能实现
>* 复杂度：$O(nm)$

```cpp
mt19937 rnd(time(0));
int n, m, k, h[N], val[N][4];
string s[N];
void solve() {
    cin >> n >> m >> k;
    int sum = 0;
    for (int i = 1; i <= n; ++i)
        h[i] = rnd();
    for (int i = 1; i <= n; ++i)
        sum += h[i] * k;
    for (int i = 1; i <= n; ++i) {
        cin >> s[i];
        s[i] = " " + s[i];
        for (int j = 1; j <= m; ++j) {
            int ty = s[i][j] - 'A';
            val[j][ty] += h[i];
        }
    }
    for (int i = 1; i <= n; ++i) {
        int S = sum - h[i] * k;
        int T = 0;
        for (int j = 1; j <= m; ++j) {
            int ty = s[i][j] - 'A';
            if (ty == 0) {
                T += val[j][1] + val[j][2] + val[j][3];
            } else if (ty == 1) {
                T += val[j][0] + val[j][2] + val[j][3];
            } else if (ty == 2) {
                T += val[j][0] + val[j][1] + val[j][3];
            } else {
                T += val[j][0] + val[j][1] + val[j][2];
            }
        }
        if (T == S) {
            cout << i << endl;
            return;
        }
    }
}
```

## CF869E. The Untended Antiquity

>![image-20231215164401300](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231215164401300.png)

### 题解

>* 假设我们建了一堵矩形墙 $i$，定义被墙 $i$ 包含的方格中出现了墙 $i$
>* 我们可以发现，如果两个点之间存在一条不经过任何墙的路径，那么这两个点包含的墙的种类一定相同
>* 所以只要对每种墙类型 $i$ 随机映射一个值 $h_i$，然后现在只需要一种数据结构支持矩形加 和 单点查即可
>* 所以使用二维树状数组即可实现

```cpp
mt19937 rnd(time(0));

struct Two_Bit {
    vector<vector<int>> c;
	Two_Bit(int n = 0, int m = 0) {
		c = vector<vector<int>>(n + 10, vector<int>(m + 10, 0));
	}
	int lowbit(int x) { return x & -x; }
	void add(int x, int y, int v) {
		for (int i = x; i < N; i += lowbit(i))
			for (int j = y; j < N; j += lowbit(j))
				c[i][j] += v;
	}
    void add(int x1_, int y1_, int x2_, int y2_, int v) {  // 矩形加
        add(x1_, y1_, v), add(x1_, y2_ + 1, -v), add(x2_ + 1, y1_, -v), add(x2_ + 1, y2_ + 1, v);
    }
	int query(int x, int y) {   // 单点查询
		int res = 0;
		for (int i = x; i > 0; i -= lowbit(i))
			for (int j = y; j > 0; j -= lowbit(j))
				res += c[i][j];
		return res;
	}
} bt(N, N);
int h[M];
array<int, 6> Q[M];

void solve() {
    int n, m, q; cin >> n >> m >> q;
    int tot = 0;
    map<array<int, 4>, int> mp;
    for (int i = 1; i <= q; ++i) {
        int op, a, b, c, d;
        cin >> op >> a >> b >> c >> d;
        if (op == 1) {
            ++tot; 
            mp[{a, b, c, d}] = tot;
            Q[i] = {op, a, b, c, d, tot};
        } else if (op == 2) {
            Q[i] = {op, a, b, c, d, mp[{a, b, c, d}]};
        } else {
            Q[i] = {op, a, b, c, d, 0};
        }
    }
    for (int i = 1; i <= tot; ++i) h[i] = rnd();
    for (int i = 1; i <= q; ++i) {
        auto [op, a, b, c, d, id] = Q[i];
        if (op == 1) {
            bt.add(a, b, c, d, h[id]);
        } else if (op == 2) {
            bt.add(a, b, c, d, -h[id]);
        } else {
            cout << ((bt.query(a, b) == bt.query(c, d)) ? "Yes" : "No") << endl;
        }
    }
}
```

