# 位运算

>$$
>a + b = (a | b) + (a \& b)\\
>a \oplus b = (a|b) \oplus (a \&b)\\
>a + b = (a \oplus b) + 2 \times (a \& b) \\
>a - b \leq a \oplus b \leq a + b
>$$
>

1. 取第 $k$ 位，$x\&(1<<(k-1))$

2. ~$x\Leftrightarrow x \neq -1$

>```cpp
>// 计算 x 二进制中1的个数(x为非负数)
>__builtin_popcount(x) 
>__builtin_popcountll(x)
>```
>
>```cpp
>// x 二进制中1的个数的奇偶性(x为非负数)
>// 返回1 代表1的个数有奇数个，返回0 代表1的个数有偶数个
>__builtin_parity(x)
>__builtin_parityll(x)
>```
>
>```cpp
>// x 二进制末尾0的个数
>__builtin_ctz(x)
>__builtin_ctzll(x)
>```
>
>```cpp
>// x 二进制开头的 0 的个数
>__builtin_clz(x)
>__builtin_clzll(x)
>```
>
>```cpp
>// x 对2取对数向下取整的结果
>log2(x) <==> 31 - __builtin_clz(x)
>log2(x) <==> 63 - __builtin_clzll(x)
>```



# Bitset

>* $bitset$是标准库中的一个存储 `0/1` 的大小不可变容器
>* 但是如果你开辟一个$bool$数组，一个 `bool` 类型的变量，虽然只能表示 `0/1`, 但是也占了 $1$ 个字节 的内存
>* `bitset` 就是通过固定的优化，使得一个字节的$8$个比特能分别储存 $8$ 位的 `0/1`。
>* 也就是说用**一个$64$位的无符号整型来代表一个长度为$64$的$bool$数组**，这就是**压位**
>* 注意$bitset$中下标**从右往左**递增，类似二进制
>* 所以说一个长度为$1280$位的$bitset$就代表了$20$个无符号数整型，`0 - 63` 代表了第一个$ull$，`64 - 127` 代表了第二个$ull$
>* 所以说$Bitset$**通过压位节省了空间**
>*  更重要的是$bitset$优化了效率
>* 在某些情况下通过 `bitset` 可以优化程序的运行效率。至于其优化的是复杂度还是常数，要看计算复杂度的角度，一般我们认为$bitset$的复杂度为$O(\frac{n}{w}),w = 64(计算机的位数)$



```cpp
bitset<N> a; // 有着N个二进制的定长的bitset

cout << (int)a[i] << endl; // 访问第i位二进制

a.any() // 判断a中是否至少存在一位二进制为1  O(n / w)
    
a.none() // 判断a中是否全是0  O(n / w)
    
a.count() // 统计a中有多少位二进制为1  O(n / w)
```

```cpp
bitset<1280> a, b;
a = a | b;
a = a & b;
a = a ^ b;
a = a << 1;
a = a >> 1;
```

```cpp
a.set(x)   // 把下标为x的二进制变为1
a.set()    // 把a中所有的二进制都变为1
a.set(pos, 0 / 1); // 将下标为 pos 的二进制位变为 0 或 1
    
a.reset(x) // 把下标为x的二进制变为0
a.reset()  // 把a中所有的二进制都变为0
    
a.flip(x)  // 反转下标为x的二进制
a.flip()   // 反转a中所有二进制
    
a.to_string()  // bitset转字符串
    
a.test(x)	// 检查第x个二进制位上是不是1
```

```cpp
a._Find_first() // 找到a中二进制为1的第一个位置
a._Find_next(i) // 找到位于位置i之后第一个二进制为 1 的位置
    
// O(n / w) + (1 的位数)
for (int i = a._Find_first(); i != a.size(); i = a._Find_next(i)) {
    cout << i << endl;
}
```

```cpp
bitset<1280> a;
auto p = (unsigned long long *)&a;
a[0] = 1, a[1] = 1, a[80] = 1;
cout << p[0] << " " << p[1] << endl;
//输出 3 65536
```

## PermuTree (easy version)

>![image-20230806170457839](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230806170457839.png)
>
>$1 \leq n \leq 5000$

### 题解：树形$DP$ + $bitset$优化

>* 显然对于$u$来说，它的子节点的子树中的所有节点的点权一定$>a_u$或者$< a_u$
>
>* 所以我们需要将这些子树分成两个集合$S,T$，集合$S$中的子树全部$>a_u$，集合$T$中的子树全部$<a_u$
>
>* 那么$u$能够对答案做出的最大贡献为
> $$
>  \sum_{v \in S}sz[v] \times \sum_{w \in T} sz[w]
> $$
>
>* 显然我们可以考虑枚举哪颗子节点的子树在集合$S$中，但是显然复杂度过高
>
>* 我们可以考虑类似硬币问题进行$dp$，定义$dp_i = true / false$为集合$S$中存在$i$个节点是否合法
> $$
>  dp[i]\ \ |= dp[i - sz_v],sz_v代表子树v中节点数
> $$
>
>* 如果$dp_i = true$，那么对答案的贡献为$i \times (sz_u - 1 - i)$
>
>* 那么$u$能够对答案做出的最大贡献为
> $$
>  max\sum_{i = 1}^{sz_u - 1}i \times (sz_u - 1 - i), dp_i = true
> $$
>
>* 当前复杂度为$O(n ^ 2)$，已经可以通过
>
>* 我们还可以通过$bitset$优化至$O(\frac{n^2}{w}),w = 64$

```cpp
const int N = 5e3 + 10, M = 4e5 + 10;

int n;
int sz[N], ans;
vector<int> g[N];

void dfs(int u, int par)
{
    sz[u] = 1;
    bitset<N> dp;
    dp.set(0); // f[0] = 1
    for (auto v : g[u])
    {
        if (v == par)
            continue;
        dfs(v, u);
        sz[u] += sz[v];
        dp |= (dp << sz[v]);
    }
    int mx = 0;
    for (int i = 1; i <= sz[u] - 1; ++i)
    {
        if (dp.test(i)) //  f[i] = 1 
            mx = max(mx, i * (sz[u] - 1 - i));
    }
    ans += mx;
}

void solve()
{
    cin >> n;
    for (int i = 2; i <= n; ++i)
    {
        int u;
        cin >> u;
        g[i].push_back(u);
        g[u].push_back(i);
    }
    dfs(1, 0);
    cout << ans << endl;
}
```

