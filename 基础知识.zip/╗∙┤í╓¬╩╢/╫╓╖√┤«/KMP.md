# $KMP$

>* **周期**：对于字符串$s$和正整数$p$，如果有$s[i]=s[i-p]$,对于$p<i<|s|$成立，则称 $p$ 为字符串 $s$ 的一个周期
>* 周期和**循环节**的关系：如果 $p\ |\ |S|$ 则 $p$ 是 $S$ 的**循环节**，特殊的$p=|S|$ 一定是 $S$ 的循环节
>* $Border$ 代表**公共前后缀**的长度
>* $Border$ 和周期的关系： $p$ 是 $S$ 的周期 ⇔ $|S| − p$ 是 *S* 的 $Border$
>* **因此，字符串的周期性质等价于** $Border$ **的性质，** **求周期也等价于求** $Border$ ，即：
>* 我们求出所有的 $Border$ 也就求出了所有的周期 $p$，我们只要检查是否 $p\  |\  |S|$，就能得到字符串 $S$ 的循环节
>* $Border$的性质：$S$ 的 $Border$ 的 $Border$ 也是 $S$ 的 $Border$ 
>* 注意：我们还可以利用 $KMP$ 找到**最短公共前后缀**（不是空串）
>* $Border$ **不具有二分性**
>* $KMP$ 主要用于**单模式串**与文本串的匹配
>
>![image-20230623204400102](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20230623204400102.png)

~~~cpp
int n, k, nxt[N];
/* 
	n 代表文本串的长度
	k 代表模式串的长度
	nxt[i] 代表前缀 s[1, i] 的最长公共前后缀的长度 len，即 s[1, len] = s[i - len + 1, i]
*/
void slove() {	
    string p, s;
    cin >> k >> p; p = " " + p;
    cin >> n >> s; s = " " + s;
    nxt[1] = 0;
	/* 预处理 nxt 数组 */
    for (int i = 2, j = 0; i <= k; ++i) {
		/* 如果匹配不成功，j 反复退步，利用 border 的传递性，实际上是遍历 p[1, i - 1] 的所有 border */
        while (j && p[i] != p[j + 1]) j = nxt[j];
		/* 如果匹配成功，最长公共前后缀长度增加 */
        if (p[i] == p[j + 1]) j++;
        nxt[i] = j;
    }
	/* 字符串匹配过程 */
    for (int i = 1, j = 0; i <= n; ++i) {
        while (j && s[i] != p[j + 1]) j = nxt[j];
        if (s[i] == p[j + 1]) j++;
		/* 匹配成功 */
        if (j == k) {
            cout << i - k + 1 << " ";
			/* 注意需要将 j 退一步回到 nxt[j] */
            j = nxt[j];
        }
    }
}
~~~

```cpp
/*
    nxt 下标从 1 开始
    nxt.back() 代表 nxt[|s|]
*/
vector<int> kmp(string s) {
    int n = SZ(s);
    vector<int> nxt(n + 1);
    for (int i = 1, j = 0; i < n; ++i) {
        while (j && s[i] != s[j]) j = nxt[j];
        j += (s[i] == s[j]);
        nxt[i + 1] = j;
    }
    return nxt;
}
```

