# AC自动机

>* $n$ 个模式串 $S_i$，一个文本串 $T$
>
>![image-20231024002628896](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231024002628896.png)
>
>![image-20231024003216165](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231024003216165.png)
>
>* 我们定义失配指针 $fail[u] = ne[u]$，转移数组 $tr[u][i] = ch[u][i]$
>* 转移边 $tr[u][i]$ 的作用和 KMP 中的 $nxt$ 相同，快速到达当前主串上该位置的最长后缀串在 Trie 上所在节点，并且利用了类似并查集的路径压缩，避免了回到根节点多走一段路的时间，保证一定是最短路
> * 失配指针的重要性质：AC 自动机的失配指针指向当前状态的**最长后缀**状态，并且同样也是**字典树上的前缀**
>* 实际上，所谓的 $fail$ 指针其实是一个**后缀集合**
>* 建立 AC 自动机的复杂度为$O(26\sum|S_i|)$
>
>![image-20231024004323260](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20231024004323260.png)
>
>* 时间复杂度：$O(\sum|S_i| + |T|)$
>* 当然这是查询出现模式串种类数的复杂度，如果我们要求每个模式串出现的次数，我们还需要进行优化
>* 因为我们的 AC 自动机中，每次匹配，会一直沿着回跳边(fail 边)来找到所有的匹配，但是这样的效率较低，在某些题目中会被卡 T
>* 首先我们需要了解 fail 指针的一个性质：**一个 AC 自动机中，如果只保留 fail 边，那么剩余的图一定是一棵树，称其为AC 自动机 fail 树**
>* 所以我们完全可以做个 **树上差分**，最后 **子树求和** 即可

```cpp
int idx, tr[N][26], fail[N], cnt[N], nxt[N], fa[N], idn[N], mp[N];
/* 
    fail[u] 代表以 u 结尾的字符串的最长后缀所在节点，也是回跳边
    tr[u][i] 代表树边 和 转移边
    cnt[u] 代表有几个模式串是以 u 结尾的字符串
    nxt[u] 代表 u 的后缀中第一个模式串所在节点，通过路径压缩方式得到
    fa[u] 代表包含 u 的后缀中第一个模式串所在节点，nxt 的辅助数组
    idn[u] 代表以 u 结尾的字符串在给定模式串中的下标
*/
string S[N], T;

/* Trie树 --> Build 树边 */
void insert(string s, int id) {
    int u = 0;
    for (auto ch : s) {
        int v = ch - 'a';
        if (!tr[u][v])
            tr[u][v] = ++tot;
        u = tr[u][v];
    } 
    ++cnt[u];
    idn[u] = id;
}
/* Build AC自动机 */
void buildAC() {
    queue<int> q;
    for (int i = 0; i <= tot; ++i) fa[i] = i;
    for (int i = 0; i < 26; ++i) if (tr[0][i]) q.push(tr[0][i]);
    while (q.size()) {
        int u = q.front(); q.pop();
        nxt[u] = fa[fail[u]];
        if (!cnt[u]) fa[u] = nxt[u];
        for (int i = 0; i < 26; ++i) {
            int v = tr[u][i];
            /* 建回跳边 */
            if (v) {
                fail[v] = tr[fail[u]][i];
                q.push(v);
            /* 建转移边 */
            } else {
                tr[u][i] = tr[fail[u]][i];
            }
        }
    }
}
// 建 fail 树, 然后在 fail 树上进行操作
void buildFailTree() {
    vector<vector<int>> g(idx + 5);
    for (int i = 1; i <= idx; ++i)
        g[fail[i]].push_back(i);
    auto dfs = [&](auto self, int u) -> void {
        for (auto v : g[u]) {
            // to do sth...
            self(self, v);
        }
    };
    dfs(dfs, 0);
}
// 询问在文本串中出现过的模式串的种类数
int query_kind(string T) {
    int u = 0, res = 0;
    for (auto ch : T) {
        int v = ch - 'a';
        u = tr[u][v];  // 走 树边 或者 转移边
        for (int j = u; j && cnt[j] != -1; j = nxt[j]) { // 走已经被路径压缩过的 回跳边 来匹配后缀
            res += cnt[j];
            cnt[j] = -1;
        }
    }
    return res;
}
// 询问在文本串中所有模式串的出现次数, sum[i]：代表第 i 个模式串出现次数
void query_cnt(string T) {
    int u = 0;
    for (auto ch : T) {
        int v = ch - 'a';
        u = tr[u][v];  // 走 树边 或者 转移边
        sum[u]++;
    }
    // 建 fail 树，在 fail 树上子树求和
    vector<vector<int>> g(idx + 5);
    for (int i = 1; i <= idx; ++i)
        g[fail[i]].push_back(i);
    auto dfs = [&](auto self, int u) -> void {
        for (auto v : g[u]) {
            self(self, v);
            sum[u] += sum[v];
        }
    };
    dfs(dfs, 0);
}

void solve() {   
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> S[i];
        insert(S[i], i);
    }
    build();
    cin >> T;
    query_cnt(T);
    for (int i = 1; i <= n; ++i)
        cout << sum[mp[i]] << endl;
}
```

