##  [POJ - 3461](https://vjudge.net/problem/POJ-3461/origin) 

>给定一个模式串和匹配串，让你求出该模式串在匹配串中出现的次数

### 题解：

>该题两种解法：
>
>1.字符串哈希，求出模式串的哈希值和匹配串的哈希值，然后遍历一遍匹配串按照字符串前缀哈希法匹配即可；
>
>2.KMP，直接套板子

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef pair<int, int> pii;
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

ULL h[N], p[N], base = 131;

ULL gethash(int l, int r) { return h[r] - h[l - 1] * p[r - l + 1]; }

void solve()
{
    string s, cmp;
    cin >> cmp >> s;
    int len = cmp.length();
    int n = s.length();
    cmp = " " + cmp;
    s = " " + s;
    p[0] = 1;
    for (int i = 1; i <= n; i++)
        p[i] = p[i - 1] * base;
    for (int i = 1; i <= n; ++i)
        h[i] = h[i - 1] * base + s[i];
    ULL num = 0;
    for (int i = 1; i <= len; ++i)
        num = num * base + cmp[i];
    int ans = 0;
    for (int i = len; i <= n; i++)
    {
        if (gethash(i - len + 1, i) == num)
            ans++;
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define endl '\n'
#define mp make_pair
using namespace std;
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e4 + 10;

int ne[N];

void slove()
{
    string s, s1;
    cin >> s;
    int len = s.length();
    s = " " + s;
    for (int i = 1; i <= len; ++i)
        ne[i] = 0;
    for (int i = 2, j = 0; i <= len; ++i)
    {
        while (j && s[j + 1] != s[i])
            j = ne[j];
        if (s[i] == s[j + 1])
            j++;
        ne[i] = j;
    }

    int ans = 0;
    cin >> s1;
    int n = s1.length();
    s1 = " " + s1;
    for (int i = 1, j = 0; i <= n; ++i)
    {
        while (j && s[j + 1] != s1[i])
            j = ne[j];
        if (s1[i] == s[j + 1])
            j++;
        if (j == len)
        {
            ans++;
            j = ne[j];
        }
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~



##   [黑暗爆炸 - 1511](https://vjudge.net/problem/黑暗爆炸-1511/origin) 

>给定一个字符串，让你求出所有前缀字符串的最大周期之和

### 题解：最小公共前后缀

>我们知道$boder$和周期之间存在关系：$boder = |s|-p$,那么求最大周期也就是求最小公共前后缀，所以我们只要先预处理$next$数组，得到最大公共前后缀，然后再遍历一遍该字符串，将最大公共前后缀变为最小即可，那么对于每一个前缀字符串，只有最小公共前后缀不为0才会对答案有贡献

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10, M = 4e5 + 10;

int ne[N];
int n;

void solve()
{
    cin >> n;
    string s;
    cin >> s;
    s = " " + s;
    ne[1] = 0;
    int boder = 0;
    for (int i = 2, j = 0; i <= n; ++i)
    {
        while (j && s[j + 1] != s[i])
            j = ne[j];
        if (s[j + 1] == s[i])
            j++;
        ne[i] = j;
    }
    int ans = 0;
    for (int i = 1; i <= n; ++i)
    {
        int p = ne[i];
        while (p)
        {
            ne[i] = p;
            p = ne[p];
        }
        if (ne[i])
            ans += i - ne[i];
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

##  [CodeForces - 1137B ](https://vjudge.net/problem/CodeForces-1137B/origin) 

>给定一个$01$字符串和模式串，让你改动01串使得模式串在01串中出现的次数最多，但是改动时不得改变01串中0和1的数量，只能改变位置

### 题解：贪心+最长公共前后缀

>记录字符串中0和1出现的次数，我们需要贪心的将模式串在01字符串中从头到尾复制出来，但是我们怎么样才能更好的贪心：我们只需要在复制第二个模式串的时候，在第一个模式串最长公共前后缀的地方开始连接即可，这样能省去不必要的花费，贪心直到0或1用完后0和1随便放即可

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10, M = 4e5 + 10;

int ne[N];

void solve()
{
    string s, str;
    cin >> s >> str;
    int len1 = s.length();
    int len2 = str.length();
    s = " " + s;
    str = " " + str;
    int cnt0 = 0, cnt1 = 0;
    for (int i = 1; i <= len1; ++i)
    {
        if (s[i] == '0')
            cnt0++;
        else
            cnt1++;
    }
    for (int i = 2, j = 0; i <= len2; ++i)
    {
        while (j && str[j + 1] != str[i])
            j = ne[j];
        if (str[j + 1] == str[i])
            j++;
        ne[i] = j;
    }
    string ans;
    for (int i = 1, j = 0; i <= len1; ++i)
    {
        if (cnt0 && str[j + 1] == '0')
        {
            cnt0--;
            ans += str[j + 1];
            j++;
        }
        else if (cnt1 && str[j + 1] == '1')
        {
            cnt1--;
            ans += str[j + 1];
            j++;
        }
        else
            break;
        if (j == len2)
            j = ne[j];
    }
    while (cnt0--)
        ans += '0';
    while (cnt1--)
        ans += '1';
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##  [CodeForces - 126B](https://vjudge.net/problem/CodeForces-126B/origin) 

>给定一个只含小写字母的字符串，如果一个子字符串既是前缀又是后缀，并且又在中间出现过的最长子字符串，那么这个字符串就是一个好字符串，现在让你判断该字符串是否为好字符串

### 题解：KMP最长公共前后缀

>结论：因为$ne[n]$已经是最长的公共前后缀子字符串，那么我们只要遍历一遍字符串，检查中间有没有出现$ne[j]==ne[n]$,如果出现了，说明是个好字符串如果没有出现，我们再检查一下$ne[ne[n]]是否为0$，如果不为0，说明肯定是个好字符串，否则不是个好字符串

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define int long long
#define mp make_pair
#define endl '\n'
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10;

int ne[N];

void slove()
{
    string s;
    cin >> s;
    int n = s.length();
    s = " " + s;
    for (int i = 2, j = 0; i <= n; ++i)
    {
        while (j && s[i] != s[j + 1])
            j = ne[j];
        if (s[i] == s[j + 1])
            j++;
        ne[i] = j;
    }
    if (ne[n] == 0)
    {
        cout << "Just a legend" << endl;
        return;
    }
    for (int i = 2; i < n; ++i)
    {
        if (ne[i] == ne[n])
        {
            cout << s.substr(1, ne[n]) << endl;
            return;
        }
    }
    if (ne[ne[n]])
    {
        cout << s.substr(1, ne[ne[n]]) << endl;
        return;
    }
    cout << "Just a legend" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~



##  [CodeForces - 1200E](https://vjudge.net/problem/CodeForces-1200E/origin) 

>给定一组字符串，根据最长公共前后缀合并，例如：sample please ->samplease；现在让你输出所有字符串合并后的字符串

### 题解：KMP 或 字符串哈希

>方法一：KMP
>
>我们可以把待连接的串放在答案串前面，求他们的最长公共前后缀即可，但是这一定会超时，所以我们需要优化算法：我们观察得知，待连接的串对答案串的贡献最多只有$min(答案串的长度，待连接串的长度)$，所以我们这要对这个串进行$KMP$即可，但是我们注意一些特例：9999  9999，那么如果我们对他求KMP，得到最长公共前后缀长度为7，但是我们只想得到4，否则如果是7的话在$substr$时会越界，为了解决这个问题，我们只需要在两个字符串中间加一个对答案不会产生影响的字符即可，例如“#”

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define int long long
#define mp make_pair
#define endl '\n'
using namespace std;
typedef long long ll;
#define mp make_pair
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e5 + 10;
const int maxn = 1e7 + 10;

int n;
string str[N];
int ne[maxn];

void slove()
{
    cin >> n;
    string ans;
    for (int i = 1; i <= n; ++i)
        cin >> str[i];
    ans += str[1];
    for (int i = 2; i <= n; ++i)
    {
        int m = str[i].length();
        int L = ans.length();
        string s;
        s = str[i].substr(0, min(m, L)) + "#" + ans.substr(max(L - m - 1, 0ll));
        int len = s.length();
        s = " " + s;
        for (int k = 2, j = 0; k <= len; ++k)
        {
            while (j && s[k] != s[j + 1])
                j = ne[j];
            if (s[k] == s[j + 1])
                j++;
            ne[k] = j;
        }
        if (ne[len] < m)
            ans += str[i].substr(ne[len]);
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~

>方法二：字符串哈希（双模）
>
>我们举个例子来模拟一下在这里字符串哈希前缀法是如何来实现检查前后缀是否相等的：
>
>$h1:SAMPLE$   $h2:PLEASE$我们检查$h1$的后缀和$h2$的前缀的最长公共子串
>
>$初始化p=1,h1=h2=0$
>
>$h1 =  E*base^0<=>h1=h1+E*p,h2 = P*base^0<=>h2*base+P,p=p*base$
>
>$h1 = L*base^1+E*base^0<=>h1=h1+L*p,h2=P*base^1+L*base^0<=>h2*base+L,p=p*base$
>
>.....
>
>以此类推，如果是后缀，我们只要$h1=h1+s[i]*p$如果是前缀$h2=h2*base+s[i]$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(x) (x).begin(), (x).end()
#define int long long
#define mp make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 1e6 + 10;

const int mod1 = 1e9 + 7;
const int mod2 = 1e9 + 9;

pii operator+(pii a, pii b)
{
    int c1 = a.first + b.first, c2 = a.second + b.second;
    if (c1 >= mod1)
        c1 -= mod1;
    if (c2 >= mod2)
        c2 -= mod2;
    return mp(c1, c2);
}
pii operator-(pii a, pii b)
{
    int c1 = a.first - b.first, c2 = a.second - b.second;
    if (c1 < 0)
        c1 += mod1;
    if (c2 < 0)
        c2 += mod2;
    return mp(c1, c2);
}
pii operator*(pii a, pii b)
{
    return mp(1ll * a.first * b.first % mod1, 1ll * a.second * b.second % mod2);
}

pii h1, h2;
pii base = mp(131, 33);

void slove()
{
    int n;
    cin >> n;
    string ans;
    cin >> ans;
    ans = " " + ans;
    for (int i = 1; i < n; ++i)
    {
        string s;
        cin >> s;
        h1 = h2 = mp(0, 0);
        int res = 0;
        int len1 = ans.size() - 1, len2 = s.length();
        s = " " + s;
        pii p = mp(1, 1);
        for (int i = 1; i <= min(len1, len2); ++i)
        {
            h1 = h1 * base + mp(ans[len1 - i + 1], ans[len1 - i + 1]);
            h2 = mp(s[i], s[i]) * p + h2;
            p = p * base;
            if (h1 == h2)
                res = i;
        }
        if (res + 1 <= len2)
            ans += s.substr(res + 1);
    }
    cout << ans.substr(1) << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        slove();
    }
    return 0;
}
~~~



##  Problem K. 子串翻转回文串

>给定字符串$s$，选择其任意子串，然后将该子串翻转，询问能否使得翻转后的字符串$s$是回文串

### 题解：字符串哈希

>首先我们知道如果$s$两端已经相同的部分不必注意，直接忽略即可，所以我们先找到两端第一个不相同的点$pos$和$n-pos+1$，然后翻转的子串要么以$pos$为左端点，即$[pos,i]$,要么以$n-pos+1$为右端点,即$[i,n-pos+1]$
>
>所以我们可以直接遍历$[pos,n-pos+1]$,利用字符串哈希判断翻转后是否为回文串即可
>
>我们来说说怎么用字符串哈希判断：假设需要翻转的子串为$[l,r]$
>
>方法1.我们可以删去 $[l,r]$处的正向哈希值，然后加上 $[l,r]$处的反向哈希值，这代表翻转后的正向遍历的哈希值，我们删去 $[l,r]$处的反向哈希值，然后加上 $[l,r]$处的正向哈希值，这代表翻转后的反向遍历的哈希值，比较两个哈希值是否相等即可
>
>方法2：翻转$[l,r]$后的哈希值加上$[r+1,n-pos+1]$的哈希值得到正向遍历的哈希值，同理得到反向遍历的哈希值，比较两者即可，不再赘述

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10, M = 4e5 + 10;

int base = 131;
int h1[N], h2[N], p[N];

int get_hash1(int l, int r)
{
    return (h1[r] - h1[l - 1] * p[r - l + 1] % mod + mod) % mod;
}
int get_hash2(int l, int r)
{
    return (h2[l] - h2[r + 1] * p[r - l + 1] % mod + mod) % mod;
}

bool check(int l, int r, int n)
{
    int sum1 = (h1[n] - get_hash1(l, r) * p[n - r] % mod + get_hash2(l, r) * p[n - r] % mod + mod) % mod;
    int sum2 = (h2[1] - get_hash2(l, r) * p[l - 1] % mod + get_hash1(l, r) * p[l - 1] % mod + mod) % mod;
    return sum1 == sum2;
}

void solve()
{
    string s;
    cin >> s;
    int n = s.length();
    s = " " + s;
    bool flag = true;
    int pos = 0;
    for (int i = 1; i <= n / 2; ++i)
    {
        if (s[i] != s[n - i + 1])
        {
            pos = i;
            flag = false;
            break;
        }
    }
    if (flag)
    {
        cout << "Yes" << endl;
        return;
    }
    h1[0] = 0;
    p[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        h1[i] = (h1[i - 1] * base % mod + s[i]) % mod;
        p[i] = p[i - 1] * base % mod;
    }
    h2[n + 1] = 0;
    for (int i = n; i >= 1; i--)
        h2[i] = (h2[i + 1] * base % mod + s[i]) % mod;
    flag = false;
    for (int i = pos; i <= n - pos + 1; i++)
    {
        int l1 = pos, r1 = i;
        int l2 = i, r2 = n - pos + 1;
        if (check(l1, r1, n) || check(l2, r2, n))
        {
            flag = true;
            break;
        }
    }
    if (flag)
        cout << "Yes" << endl;
    else
        cout << "No" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10, M = 4e5 + 10;

int base = 131;
int h1[N], h2[N], p[N];

int get_hash1(int l, int r)
{
    return (h1[r] - h1[l - 1] * p[r - l + 1] % mod + mod) % mod;
}
int get_hash2(int l, int r)
{
    return (h2[l] - h2[r + 1] * p[r - l + 1] % mod + mod) % mod;
}

bool check1(int l, int r, int n, int pos)
{
    int sum1 = (get_hash2(l, r) * p[n - pos + 1 - r] % mod + get_hash1(r + 1, n - pos + 1)) % mod;
    int sum2 = (get_hash2(r + 1, n - pos + 1) * p[r - l + 1] % mod + get_hash1(l, r)) % mod;
    return sum1 == sum2;
}

bool check2(int l, int r, int n, int pos)
{
    int sum1 = (get_hash1(l, r) * p[l - pos] % mod + get_hash2(pos, l - 1)) % mod;
    int sum2 = (get_hash1(pos, l - 1) * p[r - l + 1] % mod + get_hash2(l, r)) % mod;
    return sum1 == sum2;
}

void solve()
{
    string s;
    cin >> s;
    int n = s.length();
    s = " " + s;
    bool flag = true;
    int pos = -1;
    for (int i = 1; i <= n / 2; ++i)
    {
        if (s[i] != s[n - i + 1])
        {
            pos = i;
            flag = false;
            break;
        }
    }
    if (flag)
    {
        cout << "YES" << endl;
        return;
    }
    h1[0] = 0;
    p[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        h1[i] = (h1[i - 1] * base % mod + s[i]) % mod;
        p[i] = p[i - 1] * base % mod;
    }
    h2[n + 1] = 0;
    for (int i = n; i >= 1; i--)
        h2[i] = (h2[i + 1] * base % mod + s[i]) % mod;
    flag = false;
    for (int i = pos; i <= n - pos + 1; i++)
    {
        int l1 = pos, r1 = i;
        int l2 = i, r2 = n - pos + 1;
        if (check1(l1, r1, n, pos) || check2(l2, r2, n, pos))
        {
            flag = true;
            break;
        }
    }
    if (flag)
        cout << "YES" << endl;
    else
        cout << "NO" << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



##   [Shifting String](https://vjudge.net/problem/CodeForces-1690F) 

>给定字符串$s$和排列$p$，每次操作将$s$按照$p$重新排列，即$new_i = s_{p_i}$,询问需要操作几次才能使$s$变回原样

### 题解：思维+循环节+$kmp$  ：好题目

>~~~cpp
>10
>codeforces
>8 6 1 7 5 2 9 3 10 4
>1 2 3 4 5 6 7 8 9  10
>~~~
>
>观察样例我们得到，实际上在转换过程中该字符串由三个环构成：$（1，8，3），（2，6），（4，7，9，10）$
>
>那么操作的总次数，我们只需要求出每个环的最小循环节的长度即可，然后其所有环的最小循环节的长度的$lcm$就是答案
>
>那么如何求出最小循环节的长度：
>
>我们只要利用$kmp$求出最大的$Border$也就求出了最小的周期$p$，我们只要检查是否$p\  |\  |s|$,如果能够整数就说明字符串$s$的最小循环节为$p = |s| - Border$，否则其最小循环节为$|s|$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define rson id << 1 | 1
#define lson id << 1
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];

void solve()
{
    cin >> n;
    string s;
    cin >> s;
    s = " " + s;
    vector<bool> vis(n + 10);
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    int ans = 1;
    for (int i = 1; i <= n; ++i)
    {
        if (vis[i])
            continue;
        int u = a[i];
        string t;
        while (u != i)
        {
            vis[u] = true;
            t += s[u];
            u = a[u];
        }
        t += s[i];
        int m = t.length();
        t = " " + t;
        vector<int> ne(m + 10, 0);
        for (int i = 2, j = 0; i <= m; ++i)	//kmp求border
        {
            while (j && t[i] != t[j + 1])
                j = ne[j];
            if (t[i] == t[j + 1])
                j++;
            ne[i] = j;
        }
        if (m % (m - ne[m]) == 0)		//判断最小周期p是否为循环节
            ans = lcm(ans, m - ne[m]);
        else
            ans = lcm(ans, m);
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~



## [LibreOJ - 2452](https://vjudge.csgrandeur.cn/problem/LibreOJ-2452/origin) 

>给定长度为$n$字符串$s$，该字符串由$0/1$组成，我们定义：将该字符串中0和1取反后，再将整个串翻转后与原来的串一样，我们称这个字符串是个好字符串，例如:$1100$；现在让你求出该字符串有多少个非空子串（连续子序列）是好的

### 题解：二分答案 + 字符串哈希

>首先对于一个反对称串来说，有以下几个结论：
>
>1.长度一定是偶数；
>
>2.和反对称串共对称轴的字串一定也是反对称串，也就是说一个反对称串长度的一半是这个反对称串中子串也是反对称串的数量
>
>3.在对一个反对称串对称轴左边进行取反反转后一定和对称轴右边相同
>
>有了以上结论，我们可以直接从$[1,n-1]$枚举对称轴的位置，然后对反对称串的长度的一半进行二分答案，然后$check$我们可以利用字符串哈希$O(1)$得出
>
>所以时间复杂度为:$O(nlogn)$

~~~cpp
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 5e5 + 10;

int n;
ULL h1[N], h2[N], p[N];
int base = 131;

ULL get_h1(int l, int r)
{
    return h1[r] - h1[l - 1] * p[r - l + 1];
}
ULL get_h2(int l, int r)
{
    return h2[l] - h2[r + 1] * p[r - l + 1];
}

int check(int x)
{
    int l = 1, r = min(x, n - x);		//二分反对称串长度的一半
    while (l <= r)		
    {
        int mid = l + r >> 1;
        if (get_h1(x + 1, x + mid) == get_h2(x - mid + 1, x))
            l = mid + 1;
        else
            r = mid - 1;
    }
    return r;
}

void solve()
{
    cin >> n;
    string s;
    cin >> s;
    s = " " + s;
    int ans = 0;
    p[0] = 1;
    for (int i = 1; i <= n; ++i)
        p[i] = p[i - 1] * base;
    for (int i = 1; i <= n; ++i)
        h1[i] = h1[i - 1] * base + s[i] - '0';
    for (int i = n; i >= 1; --i)			//相当于对原来的字符串进行取反后反转的操作
        h2[i] = h2[i + 1] * base + ((s[i] - '0') ^ 1);
    for (int i = 1; i < n; ++i)
        ans += check(i);
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
~~~

