# 博弈DP

>一般根据必胜态、必败态，P/N分析来转移

## ABC349 **E - Weighted Tic-Tac-Toe**

>![image-20240418001357832](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240418001357832.png)

### 题解：记忆化搜索 + 博弈 DP

>考虑到状态数不超过 $3^9$，考虑 dp
>
>我们定义 $0$ 代表高桥， $1$ 代表青木
>
>考虑对 $3 \times 3$ 的网格进行状态压缩，例如二进制第 $0$ 位代表 $a[0][0]$ 有没有被涂色
>
>并且这是一个不平等博弈，所以两个人都需要开一个状态：
>
>$state[0]$ 代表高桥此时涂色的状态， $state[1]$ 代表青木此时涂色的状态
>
>定义 $dp[i] = 0/ 1$ 代表当局面为 $i$ 时胜者是高桥 / 青木
>
>显然状态图是个 DAG，所以考虑记忆化搜索，定义 $dfs(now, (state[0], state[1]))$  代表当前局面的先手为 $now$，且两人涂色的状态分别为 $state[0]$ 和 $state[1]$ 时，当前局面的胜利者
>
>递归出口：1. 高桥或者青木是否有人已经连成一条线了；2. 如果格子全被涂满了，容易判断获胜者是谁
>
>对于其他状态来说：如果存在可以走到某个局面，其赢家不是先手，说明可以走到先手必败，那么此时先手必胜，则返回 $now$
>
>否则返回 $now \oplus 1$

```cpp
int dp[1 << 18]; // dp[i] = 0 / 1，1 代表当处于局面 i 时，必胜者是先手 0 / 后手 1
int a[10];
int line[8] = {0b111, 0b111000, 0b111000000, 0b001001001, 0b010010010, 0b100100100, 0b100010001, 0b001010100};

/*
    state : 代表当前局面， state[0] 代表先手涂的格子， state[1] 代表后手涂的格子
    now : 代表当前局面的该谁操作
    return 0 代表先手胜，return 1 代表后手胜
*/
int dfs(int now, array<int, 2> state) {
    for (auto x : line) {
        if ((state[0] & x) == x) return 0;
        if ((state[1] & x) == x) return 1;
    }
    // 如果格子全部被填满了颜色
    if ((state[0] | state[1]) == 511) {
        int v0 = 0, v1 = 0;
        for (int i = 0; i < 9; ++i) {
            if (state[0] >> i & 1) v0 += a[i];
            else v1 += a[i];
        }
        if (v0 > v1) return 0;
        else return 1;
    }
    if (dp[state[0] | (state[1] << 9)] != -1) return dp[state[0] | (state[1] << 9)];
    for (int i = 0; i < 9; ++i) {
        if ((state[0] >> i & 1) || (state[1] >> i & 1)) continue;
        array<int, 2> nxt = state;
        nxt[now] |= 1 << i;
        // 根据P/N分析，如果存在某个对手的状态为先手必败，那么此时now作为先手一定必胜，所以必胜者为 now
        if (dfs(now ^ 1, nxt) == now) return dp[state[0] | (state[1] << 9)] = now;        
    }
    // 如果所有能够到达的局面都是先手必胜，则此时一定先手必败，所以必胜者是 now ^ 1
    return dp[state[0] | (state[1] << 9)] = now ^ 1;
}

void solve() {
    for (int i = 0; i < 9; ++i) cin >> a[i];
    memset(dp, -1, sizeof dp);
    if (!dfs(0, {0, 0})) {
        cout << "Takahashi" << endl;
    } else {
        cout << "Aoki" << endl;
    }
}
```

## 取石子游戏

>有一堆石子，大小为 $x$ ，Alice 和 Bob 轮流操作，Alice 先手，Alice 每次可以取 $a_1,a_2,...a_{n1}$ 个石子，Bob 每次可以取 $b_1,b_2,...,b_{n2}$ 个石子，谁不能操作就输
>
>问谁能获胜，对于 $x = 1...m$ 都输出答案
>
>$n1 ,n2, m \leq 2000$

### 题解

>发现对于同一个局面，Alice 和 Bob 能够执行的操作并不一样，说明这是不平等博弈，考虑博弈 DP
>
>定义 $A[i]$ 代表当石子数量为 $i$ 时 Alice 为先手时能否获胜，$B[i]$ 代表当石子数量为 $i$ 时 Bob 为先手能否获胜
>
>考虑 $O(n)$ 转移：
>
>即对于 $A[i]$ 来说，直接枚举 $a[j]$，如果存在 $B[i - a[j]] = 0$，即能够走到一个先手必败的局面，则 $A[i] = 1$，否则 $A[i] = 0$
>
>对于 $B[i]$ 来说，转移是相似的

```cpp
int n1, n2, m, A[N], B[N], a[N], b[N];
void solve() {
    cin >> n1 >> n2 >> m;
    for (int i = 1; i <= n1; ++i) cin >> a[i];
    for (int i = 1; i <= n2; ++i) cin >> b[i];
    for (int i = 1; i <= m; ++i) A[i] = B[i] = 0;
    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n1; ++j) {
            if (i - a[j] >= 0 && B[i - a[j]] == 0) {
                A[i] = 1;
                break;
            }
        }
        for (int j = 1; j <= n2; ++j) {
            if (i - b[j] >= 0 && A[i - b[j]] == 0) {
                B[i] = 1;
                break;
            }
        }
        cout << (A[i] ? "Alice" : "Bob") << endl;
    }
}
```

