# Lucas 定理（模质数）

>Lucas 定理用于求解大组合数取模的问题，其中模数必须为素数；
>
>当问题规模很大，而模数是一个不大的质数的时候，就不能简单地通过递推求解来得到答案，需要用到 
>
>Lucas 定理。
>
>即求 $\binom{n}{m} \bmod p$，$p$ 是质数，$1\leq n, m \leq 10^{18}, p\leq 10^6$
>
>Lucas 定理的内容如下：对于质数 $p$，有：
>$$
>n = n_0p^0 + n_1p^1 + ... + n_kp^k \\
>m = m_0p^0 + m_1p^1 + ... + m_kp^k \\
>0 \leq n_i, m_i < p
>$$
>则
>$$
>\binom{n}{m} \equiv \binom{n_0}{m_0}\binom{n_1}{m_1}...\binom{n_k}{m_k} (\bmod p) \\
>or\\
>\binom{n}{m} \equiv \binom{\lfloor\frac{n}{p}\rfloor}{\lfloor\frac{m}{p}\rfloor}\times \binom{n \bmod p}{m \bmod p} (\bmod\ p)
>$$
>时间复杂度：$O(p + \log_p\max(n, m))$

## 模板

```cpp
ll fac[N], inv[N];
ll qpow(ll a, ll b, ll p) {
	ll res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		a = a * a % p;
		b >>= 1;
	}
	return res;
}
void Comb_init(ll p) {
    fac[0] = 1;
    for (int i = 1; i <= p - 1; ++i) fac[i] = fac[i - 1] * i % p;
    inv[p - 1] = qpow(fac[p - 1], p - 2, p);
    for (int i = p - 2; i >= 0; --i) inv[i] = inv[i + 1] * (i + 1) % p;
	assert(inv[0] == 1);
}
ll C(ll a, ll b, ll p) {
	if (a < b || a < 0 || b < 0) return 0;
	return fac[a] * inv[b] % p * inv[a - b] % p;
}
// C(n, m) mod p, p 是质数
ll lucas(ll n, ll m, ll p) {
	ll res = 1;
	while (n > 0 || m > 0) {
		res = res * C(n % p, m % p, p) % p;
		n /= p, m /= p;
	}
	return res;
}
void solve() {
	ll n, m, p; cin >> n >> m >> p;
	Comb_init(p);
	cout << lucas(n, m, p) << endl;
}
```

## 组合数与进制之间的联系

>$$
>\binom{n}{m} \equiv 1(\bmod 2) \Leftrightarrow n \& m = m
>$$

证明：

因为 $\binom{n}{m} \equiv \binom{n_0}{m_0}\binom{n_1}{m_1}...\binom{n_k}{m_k} (\bmod p)$

所以只有满足 $n_i \geq m_i$ 对于所有 $i$ 都成立时，$\binom{n}{m} \equiv 1(\bmod 2)$ 才成立

那么每一位二进制只会有 $3$ 种情况：

* $n_i = 1, m_i = 1$
* $n_i = 1, m_i = 0$
* $n_i = 0, m_i = 0$

所以 $m$ 在二进制下每一位都是 $n$ 的子集，所以 $m$ 是 $n$ 的子集 

>如果 $\binom{n}{m} \neq 0 (\bmod p)$，对于任意 $p$，都有 $n_i \geq m_i$
>
>引申：如果 $\binom{a + b}{a} \neq 0(\bmod p)$，则代表 $a + b$ 在 $p$ 进制加法下不进位

## 数位 DP 与 Lucas 定理

# 扩展 Lucas 定理（模合数）

>求 $\binom{n}{m} \bmod q$，$q$ 是任意正整数且 $1\leq n, m \leq 10^{18}, q\leq 10^6$

$q$ 是合数，模合数比较困难，根据中国剩余定理我们知道，模合数的结果实际上是由模素数幂决定的，所以不妨考虑将其拆解成 **模素数幂** 的形式，然后再通过中国剩余定理合并；

不妨设 $q = p_1^{e_1}p_2^{e_2}...p_k^{e_k}$，则拆解成：
$$
\binom{n}{m} \bmod q = \begin{equation}
	\left\{
		\begin{array}{lr}
		\binom{n}{m} \bmod p_1^{e_1} \\
		\binom{n}{m} \bmod p_2^{e_2} \\
		... \\
		\binom{n}{m} \bmod p_k^{e_k} \\
		\end{array}
	\right. 
\end{equation}
$$
那我们现在的问题转化为求 $\binom{n}{m} \bmod p^e$

因为 $\binom{n}{m} = \frac{n!}{m!(n - m)!}$，令 $n! = p^{a_n}b_n,p\nmid b_n$，即 $p^{a_n}$ 是 $p$ 在 $n!$ 中的最高素数幂；

同理，令 $m! = p^{a_m}b_m,p \nmid b_m$，$(n - m) ! = p^{a_{n - m}}b_{n-m},p \nmid b_{n - m}$

则：
$$
\binom{n}{m} \bmod p^e \\
=\frac{n!}{m!(n - m)!} \bmod p^e \\
=\frac{p^{a_n}b_n}{p^{a_m}b_m\times p^{a_{n - m}}b_{n-m}} \bmod p^e \\
= p^{a_n - a_m - a_{n - m}}b_n\times(b_mb_{n - m})^{-1} \bmod p^e
$$
因为 $(b_mb_{n - m}, p^e) = 1$，所以 $b_mb_{n - m}$ 在模 $p^e$ 下的逆元存在

所以我们现在只需要将 $n!$ 变成 $p^{a_n}b_n$ 即可

设 $fac[i]$ 代表 $[1, i]$ 中不被 $i$ 整除的数在模 $p^e$ 下的乘积

我们不妨举个例子观察一下，例如 $n = 23, p = 3, e = 2, p^e = 9$

<img src="C:\Users\ThinkBooK\AppData\Roaming\Typora\typora-user-images\image-20240505170537637.png" alt="image-20240505170537637" style="zoom:50%;" />

不难发现，如果我们按照 $p^e$ 进行分块，则每个块中不被 $p$ 整除的数的乘积在模 $p^e$ 在是一样的，例如：$1*2*4*4*7*8 \equiv 10 * 11 * 13 * 14 * 16 * 17 (\bmod  9)$

所以根据阶乘分解质因子，我们可以得到：
$$
n! \bmod p^e \\
= p^{\lfloor\frac{n}{p}\rfloor} fac^{\lfloor\frac{n}{p}\rfloor}_{p^e}fac_{n \bmod p^e} \times \lfloor\frac{n}{p}\rfloor! \\
= p^{\lfloor\frac{n}{p}\rfloor + \lfloor\frac{n}{p^2}\rfloor} fac^{\lfloor\frac{n}{p}\rfloor + \lfloor\frac{n}{p^2}\rfloor}_{p^e}fac_{n \bmod p^e}fac_{\lfloor\frac{n}{p}\rfloor \bmod p^e} \times \lfloor\frac{n}{p^2}\rfloor! \\
递归直到 n = 0
$$
所以 $a_n = p^{\lfloor\frac{n}{p}\rfloor + \lfloor\frac{n}{p^2}\rfloor...},b_n = fac^{\lfloor\frac{n}{p}\rfloor + \lfloor\frac{n}{p^2}\rfloor...}_{p^e}fac_{n \bmod p^e}fac_{\lfloor\frac{n}{p}\rfloor \bmod p^e}...$

那么现在，对于所有素数幂我们已经得到了 $\binom{n}{m} \bmod p^e = a$，即 $\binom{n}{m} \equiv a_i (\bmod p_i^{e_i})$

然后我们只需要通过 **中国剩余定理** 构造得到 $\binom{n}{m} \bmod q$，甚至不需要使用扩展中国剩余定理，因为每个质因子幂次之间都两两互质，天然满足了中国剩余定理的构造解法的前提条件

时间复杂度：$O(w(q)(\max(p^e) + \log(q)))$，$w(i)$ 代表 $[1, i]$ 中一个数最多的质因子种类

```cpp
ll qpow(ll a, ll b, ll p) {
	ll res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		b >>= 1;
		a = a * a % p;
	}
	return res;
}
ll exgcd(ll a, ll b, ll &x, ll &y) {
    if (b == 0) {
        x = 1, y = 0;
        return a;
    }
	ll d = exgcd(b, a % b, y, x);
    y -= (a / b) * x;
    return d;
}
// gcd(z, p) = 1, z * x = 1 (mod p)
ll inv(ll z, ll p) {
	ll a = z, b = p, x, y;
	exgcd(a, b, x, y);
	x %= b;
	if (x < 0) x += b;
	return x;
}
/*
	   C(a, b) mod p^e
	 = a! / (b! * (a - b)!) mod p^e
*/
ll binom(ll a, ll b, int p, int pe, vector<int> &fac) {
    int cntp = 0, cnts = 0;
	auto calc = [&](ll x, int w) -> ll {
		ll val = 1;
		while (x) {
			cntp += (x / p) * w;
			cnts += (x / pe) * w;
			val = val * fac[x % pe] % pe;
			x /= p;
		}
		return val;
	};
    ll f1 = calc(a, 1); // a! mod p^e
    ll f2 = calc(b, -1); // b! mod p^e
    ll f3 = calc(a - b, -1); // (a - b)! mod p^e
	ll phi_pe = pe / p * (p - 1); // phi[pe]
    ll v1 = f1 * qpow(f2 * f3 % pe, phi_pe - 1, pe) % pe;
    ll v2 = qpow(p, cntp, pe); // p^cntp
    ll v3 = qpow(fac[pe], cnts, pe); // fac[pe]^cnts
    return v1 * v2 % pe * v3 % pe;
}
/*
	求 C(n, m) mod q
	q = p1^e1 * p2^e2 * ... * pk^ek
	其中 n, m <= 10^18, 2 <= pi^ei <= 10^6
*/
ll exLucas(ll n, ll m, ll q) {
	ll M = q;
	vector<pair<int, int>> factors;
	for (int i = 2; i * i <= q; ++i) {
		if (q % i == 0) {
			int p = i, pe = 1;
			while (q % i == 0) q /= i, pe *= i;
			factors.pb({p, pe});
		}
	}
	if (q > 1) factors.pb({q, q});
	vector<int> fac;
	ll res = 0;
	for (auto [p, pe] : factors) {
		fac.resize(pe + 5);
		fac[0] = 1;
		for (int i = 1; i <= pe; ++i) {
			if (i % p == 0) fac[i] = fac[i - 1];
			else fac[i] = fac[i - 1] * i % pe;
		}
		// 中国剩余定理
		ll Mi = M / pe;
		ll Xi = Mi * inv(Mi, pe);
		res = (res + binom(n, m, p, pe, fac) * Xi % M) % M;
	}
	return res;
}
/*
	多个询问，Q 是询问集合，存放二元组 (n, m, qid)，询问 C(n, m) mod q
	q = p1^e1 * p2^e2 * ... * pk^ek
	其中 n, m <= 10^18, 2 <= pi^ei <= 10^6
*/
ll ans[N];
void exLucas(ll q, vector<array<int, 3>> &Q) {
	ll M = q;
	vector<pair<int, int>> factors;
	for (int i = 2; i * i <= q; ++i) {
		if (q % i == 0) {
			int p = i, pe = 1;
			while (q % i == 0) q /= i, pe *= i;
			factors.pb({p, pe});
		}
	}
	if (q > 1) factors.pb({q, q});
	vector<int> fac;
	ll res = 0;
	for (auto [p, pe] : factors) {
		fac.resize(pe + 5);
		fac[0] = 1;
		for (int i = 1; i <= pe; ++i) {
			if (i % p == 0) fac[i] = fac[i - 1];
			else fac[i] = fac[i - 1] * i % pe;
		}
		ll Mi = M / pe;
		ll Xi = Mi * inv(Mi, pe);
		for (auto [n, m, qid] : Q) ans[qid] = (ans[qid] + binom(n, m, p, pe, fac) * Xi % M) % M;
	}
}
/*
	(a1! * a2! * ... * ak!) / (b1! * b2! * ... bk!) mod p^e
	denom 中存放分母，即 a_i
	number 中存放分子，即 b_i
*/
ll binom1(int p, int pe, vector<int> &fac, vector<int> &denom, vector<int> &number) {
	int cntp = 0, cnts = 0;
	auto calc = [&](ll x, int w) -> ll {
		ll val = 1;
		while (x) {
			cntp += (x / p) * w;
			cnts += (x / pe) * w;
			val = val * fac[x % pe] % pe;
			x /= p;
		}
		return val;
	};
	ll f1 = 1, f2 = 1;
	for (auto x : denom) f1 = f1 * calc(x, 1) % pe;
	for (auto x : number) f2 = f2 * calc(x, -1) % pe;
	ll phi_pe = pe / p * (p - 1);
	ll v1 = f1 * qpow(f2, phi_pe - 1, pe) % pe;
    ll v2 = qpow(p, cntp, pe);
    ll v3 = qpow(fac[pe], cnts, pe);
    return v1 * v2 % pe * v3 % pe;
}
/*
	求 (a1! * a2! * ... * ak!) / (b1! * b2! * ... bk!) mod q
	q = p1^e1 * p2^e2 * ... * pk^ek，2 <= pi^ei <= 10^6
	denom 中存放分母，即 a_i
	number 中存放分子，即 b_i
*/
ll exLucas(ll q, vector<int> &denom, vector<int> &number) {
	ll M = q;
	vector<pair<int, int>> factors;
	for (int i = 2; i * i <= q; ++i) {
		if (q % i == 0) {
			int p = i, pe = 1;
			while (q % i == 0) q /= i, pe *= i;
			factors.pb({p, pe});
		}
	}
	if (q > 1) factors.pb({q, q});
	vector<int> fac;
	ll res = 0;
	for (auto [p, pe] : factors) {
		fac.resize(pe + 5);
		fac[0] = 1;
		for (int i = 1; i <= pe; ++i) {
			if (i % p == 0) fac[i] = fac[i - 1];
			else fac[i] = fac[i - 1] * i % pe;
		}
		ll Mi = M / pe;
		ll Xi = Mi * inv(Mi, pe);
		res = (res + binom1(p, pe, fac, denom, number) * Xi % M) % M;
	}
	return res;
}
void solve() {
	ll q; cin >> q;
	int T; cin >> T;
	vector<array<int, 3>> Q;
	for (int i = 1; i <= T; ++i) {
		ll n, m; cin >> n >> m;
		Q.pb({n, m, i});
	}
	exLucas(q, Q);
	for (int i = 1; i <= T; ++i) cout << ans[i] << endl;
}

```

## [SDOI2010] 古代猪文

>给定 $n$，$G$ 求 $G^{\sum_{d\mid n}\binom{n}{d}} \bmod 999911659$
>
>$1 \leq n, G \leq 10^9$

### 题解：欧拉定理 + exLucas

>不妨令 $p = 999911659$
>
>我们发现指数特别大，并且很难求，考虑能不能把指数变小的同时变得好求
>
>根据欧拉定理，我们可以知道，如果 $(a, m = 1)$, 则 $a^x \bmod m = a^{x \bmod \varphi(m)} \bmod m$
>
>因为 $p$ 是质数，所以一定满足上述定理，$\varphi(p) = p - 1$，所以我们将题目转化为求：
>$$
>G^{\sum_{d\mid n}\binom{n}{d}\bmod (p - 1)}  \bmod p
>$$
>观察 $p - 1$ 后发现其最大素数幂不超过 $10^5$，并且只有 $\sqrt{n}$ 个询问
>
>直接预处理询问后扩展卢卡斯定理即可

## 国家集训队 礼物

>给定模数 $P, n$ 和 $m$ 个数 $a_i$，求 $\frac{n!}{a_1!a_2!..a_m!(n - a_1-a_2...-a_m)!} \bmod P$
>
>![image-20240506001049028](https://zeoy-typora.oss-cn-hangzhou.aliyuncs.com/image-20240506001049028.png)

### 题解：exLucas

>我们知道 exLucas 本质上是先求出 $\frac{n!}{m!(n - m)!} \bmod p^e$ 后通过中国剩余定理构造答案得到 $\frac{n!}{m!(n - m)!} \bmod P$
>
>那么对于本题来说，本质上没有变化，只是分母发生了变化，但是同样都还是阶乘，过程都是一样的，直接魔改 exLucas 即可
