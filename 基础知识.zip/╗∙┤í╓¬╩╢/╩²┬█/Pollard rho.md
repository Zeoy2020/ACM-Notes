## Pollard rho 大质数分解 $O(n^{\frac{1}{4}})$

```cpp
mt19937_64 rnd(time(0));
ll mx_fac;
vector<int> fac;
ll qpow(ll a, ll b, ll p) {
    ll res = 1;
    while (b) {
        if (b & 1) res = (__int128)res * a % p;
        a = (__int128)a * a % p;
        b >>= 1;
    }
    return res;
}
bool Miller_Rabin(ll p) { // 判断素数
    if (p < 2) return 0;
    if (p == 2) return 1;
    if (p == 3) return 1;
    ll d = p - 1, r = 0;
    while (!(d & 1)) ++r, d >>= 1; // 将d处理为奇数
    for (ll k = 0; k < 10; ++k) {
        ll a = rnd() % (p - 2) + 2;
        ll x = qpow(a, d, p);
        if (x == 1 || x == p - 1) continue;
        for (int i = 0; i < r - 1; ++i) {
            x = (__int128)x * x % p;
            if (x == p - 1) break;
        }
        if (x != p - 1) return 0;
    }
    return 1;
}
ll Pollard_Rho(ll x) {
    ll s = 0, t = 0;
    ll c = (ll)rnd() % (x - 1) + 1;
    int step = 0, goal = 1;
    ll val = 1;
    for (goal = 1;; goal *= 2, s = t, val = 1) { // 倍增优化
        for (step = 1; step <= goal; ++step) {
            t = ((__int128)t * t + c) % x;
            val = (__int128)val * abs(t - s) % x;
            if ((step % 127) == 0) {
                ll d = gcd(val, x);
                if (d > 1) return d;
            }
        }
        ll d = gcd(val, x);
        if (d > 1) return d;
    }
}
void divide_fac(ll x) {
    if (x < 2) return;
    if (Miller_Rabin(x)) { // 如果x为质数
        mx_fac = max(mx_fac, x); // 更新答案
        fac.push_back(x);
        return;
    }
    ll p = x;
    while (p >= x) p = Pollard_Rho(x);
    // 不用求质因子幂次时使用
    // while ((x % p) == 0)
    //     x /= p;
    // divide_fac(x), divide_fac(p); // 继续向下分解x和p
    divide_fac(x / p), divide_fac(p);
}
```

